// detail.js
class ProductDetailManager {
    constructor() {
        this.productData = window.productData || {};
        this.selectedColor = null;
        this.selectedPointure = null;
        
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.initializeDefaultSelection();
    }
    
    bindEvents() {
        // Gérer les clics sur les miniatures
        this.bindThumbnailEvents();
        
        // Gérer les boutons quantité
        this.bindQuantityEvents();
        
        // Gérer le bouton ajouter au panier
        this.bindAddToCartEvent();
    }
    
    bindThumbnailEvents() {
        document.querySelectorAll('.thumbnail').forEach(thumbnail => {
            thumbnail.addEventListener('click', (e) => {
                this.changeMainImage(e.target);
            });
        });
    }
    
    bindQuantityEvents() {
        const minusBtn = document.querySelector('.qty-btn.minus');
        const plusBtn = document.querySelector('.qty-btn.plus');
        const quantityInput = document.getElementById('quantity');
        
        if (minusBtn) {
            minusBtn.addEventListener('click', () => this.changeQuantity(-1));
        }
        
        if (plusBtn) {
            plusBtn.addEventListener('click', () => this.changeQuantity(1));
        }
        
        if (quantityInput) {
            quantityInput.addEventListener('change', () => this.validateQuantity());
        }
    }
    
    bindAddToCartEvent() {
        const addToCartBtn = document.getElementById('addToCartBtn');
        if (addToCartBtn) {
            addToCartBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.addToCart();
            });
        }
    }
    
    initializeDefaultSelection() {
        // Sélectionner la première couleur par défaut
        const firstColor = document.querySelector('.color-option.active');
        if (firstColor) {
            this.selectColor(firstColor);
        }
    }
    
    changeMainImage(thumbnailElement) {
        const imageSrc = thumbnailElement.getAttribute('data-image');
        const mainImage = document.getElementById('mainImage');
        
        if (mainImage && imageSrc) {
            mainImage.src = '../assets/photos/' + imageSrc;
            
            // Mettre à jour les miniatures actives
            document.querySelectorAll('.thumbnail-wrapper').forEach(wrapper => {
                wrapper.classList.remove('active');
            });
            thumbnailElement.closest('.thumbnail-wrapper').classList.add('active');
        }
    }
    
    changeQuantity(change) {
        const quantityInput = document.getElementById('quantity');
        if (!quantityInput) return;
        
        let currentValue = parseInt(quantityInput.value) || 1;
        const maxStock = this.selectedPointure?.stock || parseInt(quantityInput.max) || 10;
        
        currentValue += change;
        if (currentValue < 1) currentValue = 1;
        if (currentValue > maxStock) currentValue = maxStock;
        
        quantityInput.value = currentValue;
    }
    
    validateQuantity() {
        const quantityInput = document.getElementById('quantity');
        if (!quantityInput) return;
        
        let value = parseInt(quantityInput.value) || 1;
        const maxStock = this.selectedPointure?.stock || parseInt(quantityInput.max) || 10;
        
        if (value < 1) value = 1;
        if (value > maxStock) value = maxStock;
        
        quantityInput.value = value;
    }
    
    selectColor(element) {
        // Mettre à jour l'interface
        document.querySelectorAll('.color-option').forEach(opt => {
            opt.classList.remove('active');
        });
        element.classList.add('active');
        
        // Stocker la sélection
        this.selectedColor = {
            id: parseInt(element.getAttribute('data-color-id')),
            name: element.getAttribute('data-color-name'),
            hex: element.getAttribute('data-color-hex')
        };
        
        // Charger les pointures
        this.loadPointures(this.selectedColor.id);
    }
    
    loadPointures(colorId) {
        const sizeOptions = document.getElementById('size-options');
        
        if (!this.productData.pointuresParCouleur || 
            !this.productData.pointuresParCouleur[colorId] ||
            this.productData.pointuresParCouleur[colorId].length === 0) {
            
            this.showNoPointuresMessage();
            return;
        }
        
        const pointures = this.productData.pointuresParCouleur[colorId];
        this.displayPointures(pointures);
    }
    
    displayPointures(pointures) {
        const sizeOptions = document.getElementById('size-options');
        let html = '';
        
        // Trier les pointures par valeur numérique
        pointures.sort((a, b) => {
            const aNum = parseFloat(a.pt) || 0;
            const bNum = parseFloat(b.pt) || 0;
            return aNum - bNum;
        });
        
        // Trouver la première pointure disponible
        let firstAvailableIndex = -1;
        pointures.forEach((pointure, index) => {
            if (pointure.quantite > 0 && firstAvailableIndex === -1) {
                firstAvailableIndex = index;
            }
        });
        
        pointures.forEach((pointure, index) => {
            const isAvailable = pointure.quantite > 0;
            const isSelected = index === firstAvailableIndex;
            
            html += `
                <div class="size-option ${isSelected ? 'active' : ''} ${isAvailable ? '' : 'out-of-stock'}" 
                     data-pointure-id="${pointure.id}"
                     data-pointure="${pointure.pt}"
                     data-stock="${pointure.quantite}"
                     onclick="window.productManager.selectPointure(this)"
                     title="${isAvailable ? 'En stock: ' + pointure.quantite + ' unités' : 'Épuisé'}">
                    ${pointure.pt}
                    ${!isAvailable ? '<span class="stock-badge">Épuisé</span>' : ''}
                </div>
            `;
            
            // Stocker la première pointure disponible comme sélectionnée
            if (isSelected && isAvailable) {
                this.selectedPointure = {
                    id: pointure.id,
                    pt: pointure.pt,
                    stock: pointure.quantite
                };
            }
        });
        
        sizeOptions.innerHTML = html;
        this.updateUI();
    }
    
    selectPointure(element) {
        const stock = parseInt(element.getAttribute('data-stock'));
        
        if (stock <= 0) {
            this.showNotification('Cette pointure est épuisée', 'error');
            return;
        }
        
        // Mettre à jour l'interface
        document.querySelectorAll('.size-option').forEach(opt => {
            opt.classList.remove('active');
        });
        element.classList.add('active');
        
        // Stocker la sélection
        this.selectedPointure = {
            id: element.getAttribute('data-pointure-id'),
            pt: element.getAttribute('data-pointure'),
            stock: stock
        };
        
        this.updateUI();
    }
    
    updateUI() {
        this.updateQuantityMax();
        this.updateAddToCartButton();
    }
    
    updateQuantityMax() {
        const quantityInput = document.getElementById('quantity');
        if (quantityInput && this.selectedPointure) {
            quantityInput.max = this.selectedPointure.stock;
            
            // Ajuster la valeur si nécessaire
            const currentValue = parseInt(quantityInput.value) || 1;
            if (currentValue > this.selectedPointure.stock) {
                quantityInput.value = this.selectedPointure.stock;
            }
        }
    }
    
    updateAddToCartButton() {
        const addToCartBtn = document.getElementById('addToCartBtn');
        if (!addToCartBtn) return;
        
        if (this.selectedColor && this.selectedPointure && this.selectedPointure.stock > 0) {
            addToCartBtn.disabled = false;
            addToCartBtn.innerHTML = `
                <i class="fas fa-cart-plus"></i>
                Ajouter au panier (${this.selectedPointure.pt}, ${this.selectedColor.name})
            `;
            addToCartBtn.title = `Ajouter ${this.productData.productName} - ${this.selectedColor.name}, Pointure ${this.selectedPointure.pt}`;
        } else {
            addToCartBtn.disabled = true;
            addToCartBtn.innerHTML = `
                <i class="fas fa-shopping-cart"></i>
                Sélectionnez couleur et pointure
            `;
            addToCartBtn.title = 'Veuillez sélectionner une couleur et une pointure';
        }
    }
    
    showNoPointuresMessage() {
        const sizeOptions = document.getElementById('size-options');
        if (sizeOptions) {
            sizeOptions.innerHTML = `
                <div class="no-pointures">
                    <i class="fas fa-info-circle"></i>
                    Aucune pointure disponible pour cette couleur
                </div>
            `;
        }
        this.selectedPointure = null;
        this.updateAddToCartButton();
    }
    
    showNotification(message, type = 'info') {
        // Créer une notification temporaire
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <i class="fas fa-${type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
            <span>${message}</span>
        `;
        
        // Style de base pour la notification
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 12px 20px;
            background: ${type === 'error' ? '#f8d7da' : '#d1ecf1'};
            color: ${type === 'error' ? '#721c24' : '#0c5460'};
            border: 1px solid ${type === 'error' ? '#f5c6cb' : '#bee5eb'};
            border-radius: 4px;
            z-index: 10000;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            gap: 10px;
        `;
        
        document.body.appendChild(notification);
        
        // Supprimer après 3 secondes
        setTimeout(() => {
            notification.style.opacity = '0';
            notification.style.transition = 'opacity 0.3s';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }
    
    showSizeGuide() {
        alert('Guide des tailles - Veuillez consulter notre charte de taille');
        // Vous pourriez ouvrir une modal ici
    }
    
    addToCart() {
        if (!this.selectedColor || !this.selectedPointure) {
            this.showNotification('Veuillez sélectionner une couleur et une pointure', 'error');
            return false;
        }
        
        if (this.selectedPointure.stock <= 0) {
            this.showNotification('Cette pointure est épuisée', 'error');
            return false;
        }
        
        const quantity = document.getElementById('quantity')?.value || 1;
        
        // Ici, vous feriez l'appel AJAX pour ajouter au panier
        const cartData = {
            productId: this.productData.productId,
            colorId: this.selectedColor.id,
            colorName: this.selectedColor.name,
            pointureId: this.selectedPointure.id,
            pointure: this.selectedPointure.pt,
            quantity: quantity
        };
        
        console.log('Ajout au panier:', cartData);
        
        // Simulation d'ajout au panier
        this.showNotification(
            `Ajouté au panier: ${quantity} x ${this.productData.productName} (${this.selectedColor.name}, ${this.selectedPointure.pt})`, 
            'success'
        );
        
        // Vous pourriez faire un appel AJAX ici :
        /*
        fetch('/addToCart', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(cartData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                this.showNotification('Produit ajouté au panier', 'success');
                // Mettre à jour le compteur du panier
                if (data.cartCount !== undefined) {
                    updateCartCount(data.cartCount);
                }
            } else {
                this.showNotification(data.message || 'Erreur', 'error');
            }
        })
        .catch(error => {
            console.error('Erreur:', error);
            this.showNotification('Erreur lors de l\'ajout au panier', 'error');
        });
        */
        
        return false;
    }
}

// Initialiser quand le DOM est chargé
document.addEventListener('DOMContentLoaded', function() {
    window.productManager = new ProductDetailManager();
    
    // Exposer les fonctions globales pour les appels onclick
    window.selectColor = function(element) {
        window.productManager.selectColor(element);
    };
    
    window.selectPointure = function(element) {
        window.productManager.selectPointure(element);
    };
    
    window.changeMainImage = function(element) {
        window.productManager.changeMainImage(element);
    };
    
    window.changeQuantity = function(change) {
        window.productManager.changeQuantity(change);
    };
    
    window.showSizeGuide = function() {
        window.productManager.showSizeGuide();
    };
});


