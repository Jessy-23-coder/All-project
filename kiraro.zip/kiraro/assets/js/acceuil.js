// ==================== FICHIER UNIQUE acceuil.js ====================
// Variables globales
let allProducts = [];
let currentMarqueFilter = '';
let currentGenreFilter = '';

// Gestion du dropdown des marques et genres
document.addEventListener('DOMContentLoaded', function() {
    // --- MARQUE ---
    const marqueDropdown = document.querySelector('.marque-dropdown');
    const marqueDropdownToggle = document.querySelector('.marque-dropdown-toggle');
    const selectedMarque = document.querySelector('.selected-marque');
    const marqueItems = document.querySelectorAll('.marque-dropdown-item');

    // --- GENRE ---
    const genreDropdown = document.querySelector('.genre-dropdown');
    const genreDropdownToggle = document.querySelector('.genre-dropdown-toggle');
    const selectedGenre = document.querySelector('.selected-genre');
    const genreItems = document.querySelectorAll('.genre-dropdown-item');

    // Initialiser tous les produits
    allProducts = document.querySelectorAll('.product-card');

    // === Gestion Marque ===
    if (marqueDropdownToggle) {
        marqueDropdownToggle.addEventListener('click', function(e) {
            e.stopPropagation();
            
            // Fermer le dropdown genre si ouvert
            if (genreDropdown.classList.contains('active')) {
                genreDropdown.classList.remove('active');
            }
            
            // Toggle le dropdown marque
            marqueDropdown.classList.toggle('active');
        });
    }
    
    // === Gestion Genre ===
    if (genreDropdownToggle) {
        genreDropdownToggle.addEventListener('click', function(e) {
            e.stopPropagation();
            
            // Fermer le dropdown marque si ouvert
            if (marqueDropdown.classList.contains('active')) {
                marqueDropdown.classList.remove('active');
            }
            
            // Toggle le dropdown genre
            genreDropdown.classList.toggle('active');
        });
    }
    
    // Fermer tous les dropdowns en cliquant ailleurs
    document.addEventListener('click', function(e) {
        // Vérifier si on a cliqué en dehors des dropdowns
        const isMarqueClick = marqueDropdown && 
            (marqueDropdown.contains(e.target) || 
             e.target.closest('.marque-dropdown'));
        
        const isGenreClick = genreDropdown && 
            (genreDropdown.contains(e.target) || 
             e.target.closest('.genre-dropdown'));
        
        if (!isMarqueClick && marqueDropdown) {
            marqueDropdown.classList.remove('active');
        }
        
        if (!isGenreClick && genreDropdown) {
            genreDropdown.classList.remove('active');
        }
    });
    
    // === Sélection d'une marque ===
    marqueItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            
            const marqueText = this.textContent.trim();
            const marqueValue = this.dataset.marque;
            
            if (selectedMarque) {
                selectedMarque.textContent = marqueText;
            }
            
            // Filtrer par marque
            if (marqueValue === 'all') {
                currentMarqueFilter = '';
            } else {
                currentMarqueFilter = marqueValue.toLowerCase();
            }
            
            applyFilters();
            marqueDropdown.classList.remove('active');
        });
    });

    // === Sélection d'un genre ===
    genreItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            
            const genreText = this.textContent.trim();
            const genreValue = this.dataset.genre;
            
            if (selectedGenre) {
                selectedGenre.textContent = genreText;
            }
            
            // Filtrer par genre
            if (genreValue === 'all') {
                currentGenreFilter = '';
            } else {
                currentGenreFilter = genreValue.toLowerCase();
            }
            
            applyFilters();
            genreDropdown.classList.remove('active');
        });
    });

    // === Détection initiale depuis l'URL ===
    function detectActiveFiltersFromURL() {
        const urlParams = new URLSearchParams(window.location.search);
        
        // Marque
        const marqueFilter = urlParams.get('marque');
        if (marqueFilter && selectedMarque) {
            const decodedMarque = decodeURIComponent(marqueFilter);
            selectedMarque.textContent = decodedMarque;
            currentMarqueFilter = marqueFilter.toLowerCase();
        }
        
        // Genre
        const genreFilter = urlParams.get('genre');
        if (genreFilter && selectedGenre) {
            const decodedGenre = decodeURIComponent(genreFilter);
            selectedGenre.textContent = decodedGenre;
            currentGenreFilter = genreFilter.toLowerCase();
        }
    }
    
    // Initialiser
    detectActiveFiltersFromURL();
    applyFilters();
});

// ==================== Gestion des notifications ====================

document.addEventListener('DOMContentLoaded', function() {
    // Gestion des messages de succès/erreur
    const successMsg = document.getElementById('success-message');
    const errorMsg = document.getElementById('error-message');
    const notification = document.getElementById('notification');
    
    if (successMsg && successMsg.textContent.trim()) {
        showNotification(successMsg.textContent, 'success');
    }
    
    if (errorMsg && errorMsg.textContent.trim()) {
        showNotification(errorMsg.textContent, 'error');
    }
    
    // Fonction d'affichage des notifications
    function showNotification(message, type) {
        if (!notification) return;
        
        notification.textContent = message;
        notification.className = 'notification ' + type;
        notification.style.display = 'block';
        
        setTimeout(() => {
            notification.style.display = 'none';
        }, 3000);
    }
    
    // Animation des boutons "Ajouter au panier"
    document.querySelectorAll('.add-to-cart-form').forEach(form => {
        form.addEventListener('submit', function(e) {
            const button = this.querySelector('.add-to-cart-btn');
            if (!button) return;
            
            const originalText = button.innerHTML;
            const originalBackground = button.style.background;
            const originalColor = button.style.color;
            const originalBorder = button.style.borderColor;
            
            // Animation du bouton
            button.innerHTML = '<i class="fas fa-check"></i> Ajouté';
            button.style.background = 'linear-gradient(to right, #4CAF50, #45a049)';
            button.style.color = 'white';
            button.style.borderColor = 'transparent';
            
            setTimeout(() => {
                button.innerHTML = originalText;
                button.style.background = originalBackground;
                button.style.color = originalColor;
                button.style.borderColor = originalBorder;
            }, 2000);
        });
    });
    
    // Effet de survol sur les cartes produit
    const productCards = document.querySelectorAll('.product-card');
    productCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-8px)';
            this.style.transition = 'transform 0.3s ease';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
});

// ==================== Auto-fermer les messages ====================

document.addEventListener('DOMContentLoaded', function() {
    // Auto-fermer les messages après 5 secondes
    setTimeout(function() {
        const alerts = document.querySelectorAll('.alert-message, .alert');
        alerts.forEach(alert => {
            alert.style.opacity = '0';
            alert.style.transform = 'translateY(-20px)';
            alert.style.transition = 'all 0.3s ease';
            setTimeout(() => alert.remove(), 300);
        });
    }, 5000);
    
    // Gestion du bouton de fermeture
    document.addEventListener('click', function(e) {
        if (e.target.closest('.alert-close') || e.target.closest('.btn-close')) {
            const alert = e.target.closest('.alert-message, .alert');
            if (alert) {
                alert.style.opacity = '0';
                alert.style.transform = 'translateY(-20px)';
                setTimeout(() => alert.remove(), 300);
            }
        }
    });
});

// ==================== Recherche dynamique ====================

document.addEventListener('DOMContentLoaded', function() {
    // Gestion de la recherche en temps réel
    const searchInput = document.getElementById('live-search-input');
    if (searchInput) {
        let searchTimeout;
        
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                if (this.value.length >= 1) {
                    performSearch();
                } else if (this.value.length === 0) {
                    clearLiveSearch();
                }
            }, 300);
            
            // Afficher/masquer le bouton effacer
            const clearBtn = document.querySelector('.search-clear');
            if (clearBtn) {
                clearBtn.style.display = this.value.length > 0 ? 'block' : 'none';
            }
        });
        
        // Recherche avec Enter
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                performSearch();
            }
        });
        
        // Bouton effacer
        const clearBtn = document.querySelector('.search-clear');
        if (clearBtn) {
            clearBtn.addEventListener('click', function(e) {
                e.preventDefault();
                clearLiveSearch();
            });
        }
    }
});

// Fonction de recherche dynamique
function performSearch() {
    const searchInput = document.getElementById('live-search-input');
    const searchTerm = searchInput.value.trim().toLowerCase();
    
    if (!searchTerm) {
        clearLiveSearch();
        return;
    }
    
    applyFilters(searchTerm);
}

// Fonction pour afficher les résultats de recherche
// function showSearchResults(searchTerm, count) {
//     const resultsInfo = document.getElementById('search-results-info');
//     const infoContent = document.getElementById('search-info-content');
    
//     if (resultsInfo && infoContent) {
//         if (count === 0) {
//             infoContent.innerHTML = `<p>Aucun résultat trouvé pour "<strong>${searchTerm}</strong>"</p>`;
//         } else {
//             infoContent.innerHTML = `<p>${count} résultat(s) trouvé(s) pour "<strong>${searchTerm}</strong>"</p>`;
//         }
//         resultsInfo.classList.add('active');
//     }
// }

// Fonction pour effacer la recherche
function clearLiveSearch() {
    const searchInput = document.getElementById('live-search-input');
    if (searchInput) {
        searchInput.value = '';
    }
    
    const clearBtn = document.querySelector('.search-clear');
    if (clearBtn) {
        clearBtn.style.display = 'none';
    }
    
    const resultsInfo = document.getElementById('search-results-info');
    if (resultsInfo) {
        resultsInfo.classList.remove('active');
    }
    
    applyFilters();
}

// ==================== Fonctions de filtrage ====================

// Fonction pour filtrer par marque
function filterByMarque(marque) {
    currentMarqueFilter = marque.toLowerCase();
    
    // Mettre à jour le texte du bouton
    const selectedMarqueSpan = document.querySelector('.selected-marque');
    if (selectedMarqueSpan) {
        selectedMarqueSpan.textContent = marque || 'Marque';
    }
    
    applyFilters();
}

// Fonction pour filtrer par genre
function filterByGenre(genre) {
    currentGenreFilter = genre.toLowerCase();
    
    // Mettre à jour le texte du bouton
    const selectedGenreSpan = document.querySelector('.selected-genre');
    if (selectedGenreSpan) {
        selectedGenreSpan.textContent = genre || 'Genre';
    }
    
    applyFilters();
}

// Fonction principale d'application des filtres
function applyFilters(searchTerm = null) {
    if (allProducts.length === 0) {
        allProducts = document.querySelectorAll('.product-card');
    }
    
    // Obtenir le terme de recherche
    const searchInput = document.getElementById('live-search-input');
    const actualSearchTerm = searchTerm || (searchInput ? searchInput.value.trim().toLowerCase() : '');
    
    let visibleCount = 0;
    
    // Parcourir tous les produits
    allProducts.forEach(product => {
        const productData = {
            nom: (product.dataset.nom || '').toLowerCase(),
            marque: (product.dataset.marque || '').toLowerCase(),
            modele: (product.dataset.modele || '').toLowerCase(),
            genre: (product.dataset.genre || '').toLowerCase(),
            categorie: (product.dataset.categorie || '').toLowerCase(),
            souscategorie: (product.dataset.souscategorie || '').toLowerCase(),
            reference: (product.dataset.reference || '').toLowerCase(),
            description: (product.dataset.description || '').toLowerCase()
        };
        
        // Vérifier les filtres de marque et genre
        const matchesMarque = !currentMarqueFilter || productData.marque === currentMarqueFilter;
        const matchesGenre = !currentGenreFilter || productData.genre === currentGenreFilter;
        
        // Vérifier la recherche si présente
        let matchesSearch = true;
        if (actualSearchTerm) {
            matchesSearch = Object.values(productData).some(value => 
                value.includes(actualSearchTerm)
            );
            
            // Vérifier également les pointures
            const isPointureMatch = /^\d+(\.\d+)?$/.test(actualSearchTerm) && 
                                   (productData.description.includes('pointure ' + actualSearchTerm) || 
                                    productData.description.includes('taille ' + actualSearchTerm));
            
            matchesSearch = matchesSearch || isPointureMatch;
        }
        
        // Appliquer tous les filtres
        if (matchesMarque && matchesGenre && matchesSearch) {
            product.style.display = 'block';
            visibleCount++;
        } else {
            product.style.display = 'none';
        }
    });
    
    // Mettre à jour le compteur
    const totalProducts = document.getElementById('total-products');
    if (totalProducts) {
        totalProducts.textContent = visibleCount;
    }
    
    // Afficher les résultats de recherche si pertinent
    if (actualSearchTerm) {
        showSearchResults(actualSearchTerm, visibleCount);
    } else {
        const resultsInfo = document.getElementById('search-results-info');
        if (resultsInfo) {
            resultsInfo.classList.remove('active');
        }
    }
}