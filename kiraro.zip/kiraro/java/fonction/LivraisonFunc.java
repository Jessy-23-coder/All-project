package fonction;

import connexion.Connexion;
import model.Livraison;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LivraisonFunc {
    
    // Créer une livraison
    public int createLivraison(int idPanier, int idSecteur) throws Exception {
        String sql = "INSERT INTO livraison (idpanier, idsecteur) VALUES (?, ?) RETURNING id";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idPanier);
            pstmt.setInt(2, idSecteur);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors de la création de la livraison: " + e.getMessage());
        }
        return 0;
    }
    
    // Vérifier si un panier a déjà une livraison
    public boolean hasLivraison(int idPanier) throws Exception {
        String sql = "SELECT COUNT(*) FROM livraison WHERE idpanier = ?";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idPanier);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors de la vérification: " + e.getMessage());
        }
        return false;
    }
    
    // Récupérer une livraison par ID de panier
    public Livraison getLivraisonByPanier(int idPanier) throws Exception {
        String sql = "SELECT * FROM livraison WHERE idpanier = ?";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idPanier);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Livraison livraison = new Livraison();
                    livraison.setId(rs.getInt("id"));
                    livraison.setIdPanier(rs.getInt("idpanier"));
                    livraison.setIdSecteur(rs.getInt("idsecteur"));
                    livraison.setDateHeure(rs.getTimestamp("dateheure"));
                    return livraison;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors de la récupération de la livraison: " + e.getMessage());
        }
        return null;
    }
    
    // Mettre à jour la livraison
    public boolean updateLivraison(int idLivraison, int idSecteur) throws Exception {
        String sql = "UPDATE livraison SET idsecteur = ?, dateheure = CURRENT_TIMESTAMP WHERE id = ?";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idSecteur);
            pstmt.setInt(2, idLivraison);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors de la mise à jour de la livraison: " + e.getMessage());
        }
    }
    
    // Récupérer le prix total avec livraison
    public double getTotalAvecLivraison(int idPanier) throws Exception {
        String sql = "SELECT " +
                    "COALESCE(SUM(vpd.sous_total), 0) as total_panier, " +
                    "a.prix_livraison " +
                    "FROM panier p " +
                    "LEFT JOIN vue_panier_detail vpd ON p.id = vpd.idpanier " +
                    "LEFT JOIN livraison l ON p.id = l.idpanier " +
                    "LEFT JOIN secteur s ON l.idsecteur = s.id " +
                    "LEFT JOIN arrondissement a ON s.idarrondissement = a.id " +
                    "WHERE p.id = ? " +
                    "GROUP BY a.prix_livraison";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idPanier);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    double totalPanier = rs.getDouble("total_panier");
                    double prixLivraison = rs.getDouble("prix_livraison");
                    return totalPanier + (rs.wasNull() ? 0 : prixLivraison);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors du calcul du total: " + e.getMessage());
        }
        return 0.0;
    }

    public String creerOuMettreAJourLivraison(int idPanier, int idSecteur) throws Exception {
        try {
            // Vérifier si le panier existe
            PanierFunc panierFunc = new PanierFunc();
            if (!panierFunc.panierExiste(idPanier)) {
                return "error: Panier non trouvé";
            }
            
            // Vérifier si le panier a déjà une livraison
            if (this.hasLivraison(idPanier)) {
                // Récupérer la livraison existante
                Livraison livraisonExistante = this.getLivraisonByPanier(idPanier);
                if (livraisonExistante != null) {
                    // Mettre à jour la livraison existante
                    boolean updated = this.updateLivraison(livraisonExistante.getId(), idSecteur);
                    if (updated) {
                        return "success";
                    } else {
                        return "error: Erreur lors de la mise à jour";
                    }
                } else {
                    // Créer nouvelle livraison
                    int livraisonId = this.createLivraison(idPanier, idSecteur);
                    if (livraisonId > 0) {
                        return "success";
                    } else {
                        return "error: Erreur lors de la création";
                    }
                }
            } else {
                // Créer nouvelle livraison
                int livraisonId = this.createLivraison(idPanier, idSecteur);
                if (livraisonId > 0) {
                    return "success";
                } else {
                    return "error: Erreur lors de la création";
                }
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            return "error: " + e.getMessage();
        }
    }
    
}