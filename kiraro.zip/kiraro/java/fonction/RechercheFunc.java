package fonction;
import connexion.Connexion;
import model.*;
import java.sql.*;
import java.util.*;
import java.math.BigDecimal;

public class RechercheFunc {
    
    public List<Produit> rechercherProduits(String terme, String marqueNom, String categorieNom, 
                                           String sousCategorieNom, String genreNom, 
                                           BigDecimal prixMin, BigDecimal prixMax) throws Exception {
        List<Produit> produits = new ArrayList<>();
        StringBuilder sql = new StringBuilder();
        List<Object> params = new ArrayList<>();
        
        sql.append("SELECT * FROM vue_produit_complet WHERE est_actif = true ");
        
        // Recherche par terme
        if (terme != null && !terme.trim().isEmpty()) {
            sql.append("AND (nom ILIKE ? OR modele_nom ILIKE ? OR description ILIKE ? OR marque_nom ILIKE ?) ");
            String searchTerm = "%" + terme.trim() + "%";
            params.add(searchTerm);
            params.add(searchTerm);
            params.add(searchTerm);
            params.add(searchTerm);
        }
        
        // Filtre par marque
        if (marqueNom != null && !marqueNom.isEmpty()) {
            sql.append("AND marque_nom = ? ");
            params.add(marqueNom);
        }
        
        // Filtre par catégorie
        if (categorieNom != null && !categorieNom.isEmpty()) {
            sql.append("AND categorie_nom = ? ");
            params.add(categorieNom);
        }
        
        // Filtre par sous-catégorie
        if (sousCategorieNom != null && !sousCategorieNom.isEmpty()) {
            sql.append("AND sous_categorie_nom = ? ");
            params.add(sousCategorieNom);
        }
        
        // Filtre par genre
        if (genreNom != null && !genreNom.isEmpty()) {
            sql.append("AND genre_nom = ? ");
            params.add(genreNom);
        }
        
        // Filtre par prix
        if (prixMin != null) {
            sql.append("AND prix_base_min >= ? ");
            params.add(prixMin);
        }
        
        if (prixMax != null) {
            sql.append("AND prix_base_max <= ? ");
            params.add(prixMax);
        }
        
        sql.append("ORDER BY date_ajout DESC");
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            
            for (int i = 0; i < params.size(); i++) {
                pstmt.setObject(i + 1, params.get(i));
            }
            
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Produit produit = mapResultSetToProduit(rs);
                produits.add(produit);
            }
        }
        return produits;
    }
    
    public List<Marque> getMarquesDisponibles() throws Exception {
        List<Marque> marques = new ArrayList<>();
        String sql = "SELECT DISTINCT marque_nom FROM vue_produit_complet WHERE est_actif = true ORDER BY marque_nom";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                Marque marque = new Marque();
                marque.setNom(rs.getString("marque_nom"));
                marques.add(marque);
            }
        }
        return marques;
    }
    
    public List<String> getCategoriesDisponibles() throws Exception {
        List<String> categories = new ArrayList<>();
        String sql = "SELECT DISTINCT categorie_nom FROM vue_produit_complet WHERE est_actif = true ORDER BY categorie_nom";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                categories.add(rs.getString("categorie_nom"));
            }
        }
        return categories;
    }
    
    public List<String> getGenresDisponibles() throws Exception {
        List<String> genres = new ArrayList<>();
        String sql = "SELECT DISTINCT genre_nom FROM vue_produit_complet WHERE est_actif = true ORDER BY genre_nom";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                genres.add(rs.getString("genre_nom"));
            }
        }
        return genres;
    }
    
    private Produit mapResultSetToProduit(ResultSet rs) throws SQLException {
        Produit produit = new Produit();
        produit.setId(rs.getInt("id"));
        produit.setNom(rs.getString("nom"));
        produit.setReference(rs.getString("reference"));
        produit.setDescription(rs.getString("description"));
        produit.setImages(rs.getString("images"));
        produit.setDateAjout(rs.getTimestamp("date_ajout"));
        
        produit.setModeleNom(rs.getString("modele_nom"));
        produit.setMarqueNom(rs.getString("marque_nom"));
        produit.setGenreNom(rs.getString("genre_nom"));
        produit.setCategorieNom(rs.getString("categorie_nom"));
        produit.setSousCategorieNom(rs.getString("sous_categorie_nom"));
        
        produit.setPrix(rs.getBigDecimal("prix_min"));
        produit.setPrixPromo(rs.getBigDecimal("prix_promo_min"));
        produit.setStockTotal(rs.getInt("stock_total"));
        
        return produit;
    }
}