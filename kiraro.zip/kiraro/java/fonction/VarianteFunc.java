package fonction;
import connexion.Connexion;
import model.Variante;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VarianteFunc {
    
    public List<Variante> getVariantesByProduit(int idProduit) throws Exception {
        List<Variante> variantes = new ArrayList<>();
        String sql = "SELECT v.*, c.nom as couleur_nom, c.code_hex " +
                    "FROM variante v " +
                    "JOIN couleur c ON v.idcouleur = c.id " +
                    "WHERE v.idproduit = ? ORDER BY c.nom";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idProduit);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Variante variante = new Variante();
                    variante.setId(rs.getInt("id"));
                    variante.setIdProduit(rs.getInt("idproduit"));
                    variante.setIdCouleur(rs.getInt("idcouleur"));
                    variante.setCouleurNom(rs.getString("couleur_nom"));
                    variante.setCodeHex(rs.getString("code_hex"));
                    variantes.add(variante);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return variantes;
    }
    
    public boolean createVariante(int idProduit, int idCouleur) throws Exception {
        String sql = "INSERT INTO variante (idproduit, idcouleur) VALUES (?, ?)";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idProduit);
            pstmt.setInt(2, idCouleur);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}