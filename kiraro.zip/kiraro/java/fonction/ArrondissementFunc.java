package fonction;

import connexion.Connexion;
import model.Arrondissement;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ArrondissementFunc {
    
    // Récupérer tous les arrondissements
    public List<Arrondissement> getAllArrondissements() throws Exception {
        List<Arrondissement> arrondissements = new ArrayList<>();
        String sql = "SELECT * FROM arrondissement ORDER BY id";
        
        try (Connection conn = Connexion.getPostgresCon();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Arrondissement arr = new Arrondissement();
                arr.setId(rs.getInt("id"));
                arr.setNom(rs.getString("nom"));
                arr.setPrixLivraison(rs.getBigDecimal("prix_livraison"));
                arrondissements.add(arr);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors de la récupération des arrondissements: " + e.getMessage());
        }
        return arrondissements;
    }
    
    // Récupérer un arrondissement par ID
    public Arrondissement getArrondissementById(int id) throws Exception {
        String sql = "SELECT * FROM arrondissement WHERE id = ?";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Arrondissement arr = new Arrondissement();
                    arr.setId(rs.getInt("id"));
                    arr.setNom(rs.getString("nom"));
                    arr.setPrixLivraison(rs.getBigDecimal("prix_livraison"));
                    return arr;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors de la récupération de l'arrondissement: " + e.getMessage());
        }
        return null;
    }
    
    // Récupérer le prix de livraison d'un arrondissement
    public double getPrixLivraisonByArrondissementId(int id) throws Exception {
        String sql = "SELECT prix_livraison FROM arrondissement WHERE id = ?";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getDouble("prix_livraison");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors de la récupération du prix: " + e.getMessage());
        }
        return 0.0;
    }
}