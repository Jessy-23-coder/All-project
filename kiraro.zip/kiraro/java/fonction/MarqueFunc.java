package fonction;
import connexion.Connexion;
import model.Marque;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MarqueFunc {
    
    public List<Marque> getAllMarques() throws Exception {
        List<Marque> marques = new ArrayList<>();
        String sql = "SELECT * FROM marque ORDER BY nom";
        
        try (Connection conn = Connexion.getPostgresCon();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Marque marque = new Marque();
                marque.setId(rs.getInt("id"));
                marque.setNom(rs.getString("nom"));
                marques.add(marque);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return marques;
    }
    
    public List<String> getAllMarquesNames() throws Exception {
        List<String> noms = new ArrayList<>();
        String sql = "SELECT nom FROM marque ORDER BY nom";
        
        try (Connection conn = Connexion.getPostgresCon();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                noms.add(rs.getString("nom"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return noms;
    }
    
    public boolean createMarque(String nom) throws Exception {
        String sql = "INSERT INTO marque (nom) VALUES (?)";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, nom);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean deleteMarque(int id) throws Exception {
        String sql = "DELETE FROM marque WHERE id = ?";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}