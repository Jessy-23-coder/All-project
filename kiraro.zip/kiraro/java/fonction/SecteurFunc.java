package fonction;

import connexion.Connexion;
import model.Secteur;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SecteurFunc {
    
    // Récupérer tous les secteurs
    public List<Secteur> getAllSecteurs() throws Exception {
        List<Secteur> secteurs = new ArrayList<>();
        String sql = "SELECT * FROM secteur ORDER BY nom";
        
        try (Connection conn = Connexion.getPostgresCon();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Secteur secteur = new Secteur();
                secteur.setId(rs.getInt("id"));
                secteur.setNom(rs.getString("nom"));
                secteur.setIdArrondissement(rs.getInt("idarrondissement"));
                secteurs.add(secteur);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors de la récupération des secteurs: " + e.getMessage());
        }
        return secteurs;
    }
    
    // Récupérer les secteurs par arrondissement
    public List<Secteur> getSecteursByArrondissement(int idArrondissement) throws Exception {
        List<Secteur> secteurs = new ArrayList<>();
        String sql = "SELECT * FROM secteur WHERE idarrondissement = ? ORDER BY nom";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idArrondissement);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Secteur secteur = new Secteur();
                    secteur.setId(rs.getInt("id"));
                    secteur.setNom(rs.getString("nom"));
                    secteur.setIdArrondissement(rs.getInt("idarrondissement"));
                    secteurs.add(secteur);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors de la récupération des secteurs: " + e.getMessage());
        }
        return secteurs;
    }
    
    // Récupérer un secteur par ID
    public Secteur getSecteurById(int id) throws Exception {
        String sql = "SELECT * FROM secteur WHERE id = ?";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Secteur secteur = new Secteur();
                    secteur.setId(rs.getInt("id"));
                    secteur.setNom(rs.getString("nom"));
                    secteur.setIdArrondissement(rs.getInt("idarrondissement"));
                    return secteur;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors de la récupération du secteur: " + e.getMessage());
        }
        return null;
    }
    
    // Récupérer l'arrondissement d'un secteur
    public int getArrondissementBySecteur(int idSecteur) throws Exception {
        String sql = "SELECT idarrondissement FROM secteur WHERE id = ?";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idSecteur);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("idarrondissement");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors de la récupération de l'arrondissement: " + e.getMessage());
        }
        return 0;
    }
}