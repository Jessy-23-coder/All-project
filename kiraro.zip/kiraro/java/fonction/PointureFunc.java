package fonction;
import connexion.Connexion;
import model.Pointure;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PointureFunc {
    
    public List<Pointure> getAllPointures() throws Exception {
        List<Pointure> pointures = new ArrayList<>();
        String sql = "SELECT * FROM pointure ORDER BY pt::DECIMAL";
        
        try (Connection conn = Connexion.getPostgresCon();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Pointure pointure = new Pointure();
                pointure.setId(rs.getInt("id"));
                pointure.setPt(rs.getString("pt"));
                pointures.add(pointure);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return pointures;
    }
    
    public List<String> getAllPointuresValues() throws Exception {
        List<String> values = new ArrayList<>();
        String sql = "SELECT pt FROM pointure ORDER BY pt::DECIMAL";
        
        try (Connection conn = Connexion.getPostgresCon();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                values.add(rs.getString("pt"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return values;
    }


    public List<Pointure> getAllPointuresDisponibles(int idProduit) throws Exception {
        List<Pointure> pointures = new ArrayList<>();
        String sql = "SELECT DISTINCT p.id, p.pt FROM pointure p " +
                    "JOIN stock_prix sp ON p.id = sp.idpointure " +
                    "JOIN variante v ON sp.idvariante = v.id " +
                    "WHERE v.idproduit = ? AND sp.quantite > 0 " +
                    "ORDER BY p.pt::DECIMAL";
        
        try (Connection conn = Connexion.getPostgresCon();
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idProduit);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Pointure pointure = new Pointure();
                pointure.setId(rs.getInt("id"));
                pointure.setPt(rs.getString("pt"));
                pointures.add(pointure);
            }
        }
        return pointures;
    }


    public List<Pointure> getPointuresDisponibles(int idProduit, int idCouleur) throws Exception {
        List<Pointure> pointures = new ArrayList<>();
        String sql = "SELECT pt.id, pt.pt, sp.quantite, sp.prix, sp.prix_promo " +
                    "FROM pointure pt " +
                    "JOIN stock_prix sp ON pt.id = sp.idpointure " +
                    "JOIN variante v ON sp.idvariante = v.id " +
                    "WHERE v.idproduit = ? AND v.idcouleur = ? " +
                    "ORDER BY CAST(REPLACE(pt.pt, ',', '.') AS DECIMAL)";
        
        try (Connection conn = Connexion.getPostgresCon();
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idProduit);
            pstmt.setInt(2, idCouleur);
            
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Pointure pointure = new Pointure();
                pointure.setId(rs.getInt("id"));
                pointure.setPt(rs.getString("pt"));
                pointure.setQuantite(rs.getInt("quantite"));
                pointures.add(pointure);
            }
        }
        return pointures;
    }

}