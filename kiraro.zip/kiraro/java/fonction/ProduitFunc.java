package fonction;

import connexion.Connexion;
import model.Produit;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProduitFunc {
    
    public List<Produit> getAllProduits() throws Exception {
    List<Produit> produits = new ArrayList<>();
    
    // On précise le schéma public pour être sûr que JDBC voit la vue
    String sql = "SELECT * FROM public.vue_produit_complet ORDER BY id DESC";

    try (Connection conn = Connexion.getPostgresCon();
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(sql)) {

        while (rs.next()) {
            Produit produit = mapResultSetToProduit(rs);
            produits.add(produit);
        }

    } catch (SQLException e) {
        // Pour voir exactement ce qui bloque
        System.err.println("Erreur JDBC getAllProduits :");
        e.printStackTrace();
        throw new Exception("Impossible de récupérer les produits: " + e.getMessage());
    }

    System.out.println("Nombre de produits récupérés: " + produits.size());
    return produits;
}

    
    public Produit getProduitById(int id)throws Exception {
        Produit produit = null;
        String sql = "SELECT * FROM vue_produit_complet WHERE id = ?";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    produit = mapResultSetToProduit(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return produit;
    }
    
    public boolean createProduitUrgence(Produit produit) throws Exception{
        System.out.println("URGENCE: createProduitUrgence");
        
        // SQL ULTRA SIMPLE qui marche à coup sûr
        String sql = "INSERT INTO produit (reference, description, prix, est_actif) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = Connexion.getPostgresCon();
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, produit.getReference());
            pstmt.setString(2, produit.getDescription());
            pstmt.setBigDecimal(3, produit.getPrix());
            pstmt.setBoolean(4, true);
            
            int rows = pstmt.executeUpdate();
            System.out.println(" URGENCE: Produit créé, rows = " + rows);
            return rows > 0;
            
        } catch (SQLException e) {
            System.err.println("ERREUR URGENCE:");
            e.printStackTrace();
            
            // Afficher l'erreur EXACTE
            System.err.println("SQLState: " + e.getSQLState());
            System.err.println("ErrorCode: " + e.getErrorCode());
            System.err.println("Message: " + e.getMessage());
            
            return false;
        }
    }

    
    public boolean updateProduit(Produit produit) throws Exception {
        String sql = "UPDATE produit SET reference = ?, description = ?, caracteristiques = ?, " +
                    "est_actif = ?, images = ? WHERE id = ?";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, produit.getReference());
            pstmt.setString(2, produit.getDescription());
            pstmt.setString(3, produit.getCaracteristiques());
            pstmt.setBoolean(4, produit.isEstActif());
            pstmt.setString(5, produit.getImages());
            pstmt.setInt(6, produit.getId());
            
            int rowsAffected = pstmt.executeUpdate();
            
            // Mettre à jour également le prix dans stock_prix
            if (rowsAffected > 0) {
                updatePrixProduit(produit);
            }
            
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    

    public boolean deleteProduit(int id) throws Exception {
        // D'abord supprimer les stock_prix associés via variante
        String deleteStockSql = "DELETE FROM stock_prix WHERE idvariante IN " +
                               "(SELECT id FROM variante WHERE idproduit = ?)";
        String deleteVarianteSql = "DELETE FROM variante WHERE idproduit = ?";
        String deleteProduitSql = "DELETE FROM produit WHERE id = ?";
        
        try (Connection conn = Connexion.getPostgresCon()) {
            conn.setAutoCommit(false);
            
            try (PreparedStatement pstmt1 = conn.prepareStatement(deleteStockSql);
                 PreparedStatement pstmt2 = conn.prepareStatement(deleteVarianteSql);
                 PreparedStatement pstmt3 = conn.prepareStatement(deleteProduitSql)) {
                
                // Supprimer stock_prix
                pstmt1.setInt(1, id);
                pstmt1.executeUpdate();
                
                // Supprimer variante
                pstmt2.setInt(1, id);
                pstmt2.executeUpdate();
                
                // Supprimer produit
                pstmt3.setInt(1, id);
                int rowsAffected = pstmt3.executeUpdate();
                
                conn.commit();
                return rowsAffected > 0;
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    

    public List<Produit> searchProduits(String keyword) throws Exception {
        List<Produit> produits = new ArrayList<>();
        String sql = "SELECT * FROM vue_produit_complet " +
                    "WHERE reference ILIKE ? OR description ILIKE ? OR modele_nom ILIKE ? " +
                    "OR marque_nom ILIKE ? OR sous_categorie_nom ILIKE ? " +
                    "ORDER BY id DESC";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            String searchPattern = "%" + keyword + "%";
            pstmt.setString(1, searchPattern);
            pstmt.setString(2, searchPattern);
            pstmt.setString(3, searchPattern);
            pstmt.setString(4, searchPattern);
            pstmt.setString(5, searchPattern);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Produit produit = mapResultSetToProduit(rs);
                    produits.add(produit);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return produits;
    }
    
    
    private void updatePrixProduit(Produit produit) throws Exception {
        String sql = "UPDATE stock_prix sp SET prix = ?, prix_promo = ? " +
                    "FROM variante v WHERE v.id = sp.idvariante AND v.idproduit = ?";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setBigDecimal(1, produit.getPrix());
            pstmt.setBigDecimal(2, produit.getPrixPromo());
            pstmt.setInt(3, produit.getId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private Produit mapResultSetToProduit(ResultSet rs) throws SQLException {
        Produit produit = new Produit();
        produit.setId(rs.getInt("id"));
        produit.setNom(rs.getString("nom"));
        produit.setReference(rs.getString("reference"));
        produit.setDescription(rs.getString("description"));
        produit.setCaracteristiques(rs.getString("caracteristiques"));
        produit.setEstActif(rs.getBoolean("est_actif"));
        produit.setImages(rs.getString("images"));
        //produit.setDateAjout(rs.getTimestamp("date_ajout"));
        
        produit.setModeleNom(rs.getString("modele_nom"));
        produit.setModeleDescription(rs.getString("modele_description"));
        
        produit.setMarqueNom(rs.getString("marque_nom"));
        produit.setGenreNom(rs.getString("genre_nom"));
        produit.setCategorieNom(rs.getString("categorie_nom"));
        produit.setSousCategorieNom(rs.getString("sous_categorie_nom"));
        
        produit.setPrix(rs.getBigDecimal("prix_min"));
        //produit.setPrixPromo(rs.getBigDecimal("prix_promo"));
        produit.setStockTotal(rs.getInt("stock_total"));
        produit.setNbCouleurs(rs.getInt("nb_couleurs"));
        produit.setNbPointuresDisponibles(rs.getInt("nb_pointures_disponibles"));
        String imagesJson = rs.getString("images");
    if (imagesJson != null && !imagesJson.isEmpty()) {
        // Extraire premier nom d'image
        imagesJson = imagesJson.replaceAll("\\[|\\]|\"", "").trim();
        String[] imagesArray = imagesJson.split(",");
        if (imagesArray.length > 0) {
            produit.setImages(imagesArray[0].trim());
        } else {
            produit.setImages("default.jpg");
        }
    } else {
        produit.setImages("default.jpg");
    }
        
        return produit;
    }

    public int getOrCreateMarqueId(String nomMarque) throws Exception {
    if (nomMarque == null || nomMarque.trim().isEmpty()) {
        throw new SQLException("Nom de marque invalide");
    }
    
    // 1. Vérifier si la marque existe
    String sqlCheck = "SELECT id FROM marque WHERE nom = ?";
    try (Connection conn = Connexion.getPostgresCon();
         PreparedStatement pstmt = conn.prepareStatement(sqlCheck)) {
        
        pstmt.setString(1, nomMarque.trim());
        ResultSet rs = pstmt.executeQuery();
        
        if (rs.next()) {
            return rs.getInt("id");
        }
    }
    
    // 2. Si elle n'existe pas, la créer
    String sqlInsert = "INSERT INTO marque (nom) VALUES (?) RETURNING id";
    try (Connection conn = Connexion.getPostgresCon();
         PreparedStatement pstmt = conn.prepareStatement(sqlInsert)) {
        
        pstmt.setString(1, nomMarque.trim());
        ResultSet rs = pstmt.executeQuery();
        
        if (rs.next()) {
            return rs.getInt("id");
        }
    }
    
    throw new SQLException("Impossible de créer la marque: " + nomMarque);
}

public int getOrCreateModeleId(String nomModele, int marqueId) throws Exception {
    String sql = "INSERT INTO modele (nom, idmarque) VALUES (?, ?) " +
                 "ON CONFLICT (nom, idmarque) DO UPDATE SET nom = EXCLUDED.nom " +
                 "RETURNING id";
    
    try (Connection conn = Connexion.getPostgresCon();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        
        pstmt.setString(1, nomModele.trim());
        pstmt.setInt(2, marqueId);
        ResultSet rs = pstmt.executeQuery();
        
        if (rs.next()) {
            return rs.getInt("id");
        }
    }
    
    throw new SQLException("Impossible de créer le modèle: " + nomModele);
}

public int getOrCreateGenreId(String nomGenre) throws Exception {
    String sql = "INSERT INTO genre (nom) VALUES (?) " +
                 "ON CONFLICT (nom) DO UPDATE SET nom = EXCLUDED.nom " +
                 "RETURNING id";
    
    try (Connection conn = Connexion.getPostgresCon();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        
        pstmt.setString(1, nomGenre.trim());
        ResultSet rs = pstmt.executeQuery();
        
        if (rs.next()) {
            return rs.getInt("id");
        }
    }
    
    throw new SQLException("Impossible de créer le genre: " + nomGenre);
}

public int getOrCreateCategorieId(String nomCategorie) throws Exception {
    String sql = "INSERT INTO categorie (nom) VALUES (?) " +
                 "ON CONFLICT (nom) DO UPDATE SET nom = EXCLUDED.nom " +
                 "RETURNING id";
    
    try (Connection conn = Connexion.getPostgresCon();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        
        pstmt.setString(1, nomCategorie.trim());
        ResultSet rs = pstmt.executeQuery();
        
        if (rs.next()) {
            return rs.getInt("id");
        }
    }
    
    throw new SQLException("Impossible de créer la catégorie: " + nomCategorie);
}

public int getOrCreateSousCategorieId(String nomSousCategorie, int categorieId) throws Exception {
    String sql = "INSERT INTO sous_categorie (nom, idcateg) VALUES (?, ?) " +
                 "ON CONFLICT (nom, idcateg) DO UPDATE SET nom = EXCLUDED.nom " +
                 "RETURNING id";
    
    try (Connection conn = Connexion.getPostgresCon();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        
        pstmt.setString(1, nomSousCategorie.trim());
        pstmt.setInt(2, categorieId);
        ResultSet rs = pstmt.executeQuery();
        
        if (rs.next()) {
            return rs.getInt("id");
        }
    }
    
    throw new SQLException("Impossible de créer la sous-catégorie: " + nomSousCategorie);
}
public List<Produit> searchProduitsByMarque(String marque) throws Exception {
    List<Produit> produits = new ArrayList<>();
    String sql = "SELECT * FROM vue_produit_complet WHERE marque_nom = ? ORDER BY id DESC";

    try (Connection conn = Connexion.getPostgresCon();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, marque);
        try (ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                produits.add(mapResultSetToProduit(rs));
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return produits;
}

// Récupérer le nom de la couleur pour une variante
public String getCouleurByVariante(int idVariante) throws Exception{
    if(idVariante == 0) return "Aucune";
    String couleur = "Aucune";
    String sql = "SELECT c.nom FROM couleur c " +
                 "JOIN variante v ON v.idcouleur = c.id " +
                 "WHERE v.id = ?";

    try (Connection conn = Connexion.getPostgresCon();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setInt(1, idVariante);
        ResultSet rs = pstmt.executeQuery();
        if(rs.next()) {
            couleur = rs.getString("nom");
        }
    } catch(SQLException e) {
        e.printStackTrace();
    }
    return couleur;
}

// Récupérer une pointure disponible pour une variante
public String getPointureByVariante(int idVariante) throws Exception{
    if(idVariante == 0) return "Aucune";
    String pointure = "Aucune";
    String sql = "SELECT p.pt FROM stock_prix sp " +
                 "JOIN pointure p ON sp.idpointure = p.id " +
                 "WHERE sp.idvariante = ? LIMIT 1"; // si plusieurs, on peut modifier

    try (Connection conn = Connexion.getPostgresCon();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setInt(1, idVariante);
        ResultSet rs = pstmt.executeQuery();
        if(rs.next()) {
            pointure = rs.getString("pt");
        }
    } catch(SQLException e) {
        e.printStackTrace();
    }
    return pointure;
}







}