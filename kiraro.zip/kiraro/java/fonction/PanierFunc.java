package fonction;

import connexion.Connexion;
import model.Panier;
import java.sql.*;

public class PanierFunc {
    
    // 1. Obtenir ou créer le panier d'un utilisateur
    public Panier getOrCreatePanier(int idUtilisateur) throws Exception {
        Panier panier = null;
        String sql = "SELECT * FROM panier WHERE idutilisateur = ?";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idUtilisateur);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    panier = mapResultSetToPanier(rs);
                    // Charger les articles via PanierArticleFunc
                    panier.setArticles(PanierArticleFunc.getArticlesPanier(panier.getId()));
                } else {
                    // Créer un nouveau panier
                    panier = createPanier(idUtilisateur);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors de la récupération du panier: " + e.getMessage());
        }
        
        return panier;
    }
    
    // 2. Créer un nouveau panier
    private Panier createPanier(int idUtilisateur) throws Exception {
        String sql = "INSERT INTO panier (idutilisateur) VALUES (?) RETURNING id";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idUtilisateur);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Panier panier = new Panier();
                    panier.setId(rs.getInt("id"));
                    panier.setIdUtilisateur(idUtilisateur);
                    panier.setArticles(new java.util.ArrayList<>());
                    return panier;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors de la création du panier: " + e.getMessage());
        }
        
        throw new Exception("Impossible de créer le panier");
    }
    
    // 3. Vider le panier
    public boolean viderPanier(int idPanier) throws Exception {
        String deleteSql = "DELETE FROM panier_article WHERE idpanier = ?";
        String updateSql = "UPDATE panier SET date_modification = CURRENT_TIMESTAMP WHERE id = ?";
        
        try (Connection conn = Connexion.getPostgresCon()) {
            conn.setAutoCommit(false);
            
            try {
                // Supprimer tous les articles via PanierArticleFunc (ou directement)
                PreparedStatement deleteStmt = conn.prepareStatement(deleteSql);
                deleteStmt.setInt(1, idPanier);
                deleteStmt.executeUpdate();
                
                // Mettre à jour la date du panier
                PreparedStatement updateStmt = conn.prepareStatement(updateSql);
                updateStmt.setInt(1, idPanier);
                updateStmt.executeUpdate();
                
                conn.commit();
                return true;
                
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors du vidage du panier: " + e.getMessage());
        }
    }
    
    // 4. Mettre à jour la date du panier (méthode publique pour utilisation par PanierArticleFunc)
    public static void updateDatePanier(int idPanier, Connection conn) throws SQLException {
        String sql = "UPDATE panier SET date_modification = CURRENT_TIMESTAMP WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idPanier);
            pstmt.executeUpdate();
        }
    }
    
    // 5. Récupérer le panier actif d'un utilisateur (sans créer automatiquement)
    public Panier getPanier(int idUtilisateur) throws Exception {
        String sql = "SELECT * FROM panier WHERE idutilisateur = ? ORDER BY date_creation DESC LIMIT 1";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idUtilisateur);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Panier panier = mapResultSetToPanier(rs);
                    panier.setArticles(PanierArticleFunc.getArticlesPanier(panier.getId()));
                    return panier;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors de la récupération du panier: " + e.getMessage());
        }
        
        return null;
    }
    
    // Méthode de mapping
    private Panier mapResultSetToPanier(ResultSet rs) throws SQLException {
        Panier panier = new Panier();
        panier.setId(rs.getInt("id"));
        panier.setIdUtilisateur(rs.getInt("idutilisateur"));
        panier.setDateCreation(rs.getTimestamp("date_creation"));
        panier.setDateModification(rs.getTimestamp("date_modification"));
        return panier;
    }

    public boolean panierExiste(int panierId) throws Exception {
        String sql = "SELECT COUNT(*) FROM panier WHERE id = ?";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, panierId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur vérification panier: " + e.getMessage());
        }
        return false;
    }
}