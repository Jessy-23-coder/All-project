package fonction;
import connexion.Connexion;
import model.Genre;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class GenreFunc {
    
    public List<Genre> getAllGenres() throws Exception {
        List<Genre> genres = new ArrayList<>();
        String sql = "SELECT * FROM genre ORDER BY nom";
        
        try (Connection conn = Connexion.getPostgresCon();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Genre genre = new Genre();
                genre.setId(rs.getInt("id"));
                genre.setNom(rs.getString("nom"));
                genres.add(genre);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return genres;
    }
    
    public List<String> getAllGenresNames() throws Exception {
        List<String> noms = new ArrayList<>();
        String sql = "SELECT nom FROM genre ORDER BY nom";
        
        try (Connection conn = Connexion.getPostgresCon();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                noms.add(rs.getString("nom"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return noms;
    }
}