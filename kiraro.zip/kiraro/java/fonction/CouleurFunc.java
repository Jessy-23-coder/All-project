package fonction;
import connexion.Connexion;
import model.Couleur;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CouleurFunc {
    
    public List<Couleur> getAllCouleurs() throws Exception {
        List<Couleur> couleurs = new ArrayList<>();
        String sql = "SELECT * FROM couleur ORDER BY nom";
        
        try (Connection conn = Connexion.getPostgresCon();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Couleur couleur = new Couleur();
                couleur.setId(rs.getInt("id"));
                couleur.setNom(rs.getString("nom"));
                couleur.setCodeHex(rs.getString("code_hex"));
                couleurs.add(couleur);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return couleurs;
    }
    
    public List<String> getAllCouleursNames() throws Exception {
        List<String> noms = new ArrayList<>();
        String sql = "SELECT nom FROM couleur ORDER BY nom";
        
        try (Connection conn = Connexion.getPostgresCon();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                noms.add(rs.getString("nom"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return noms;
    }

    // Dans CouleurFunc.java
    public List<Couleur> getCouleursByProduit(int idProduit) throws Exception {
        List<Couleur> couleurs = new ArrayList<>();
        String sql = "SELECT DISTINCT c.id, c.nom, c.code_hex " +
                     "FROM couleur c " +
                     "JOIN variante v ON c.id = v.idcouleur " +
                     "WHERE v.idproduit = ? " +
                     "ORDER BY c.nom";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idProduit);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Couleur couleur = new Couleur();
                couleur.setId(rs.getInt("id"));
                couleur.setNom(rs.getString("nom"));
                couleur.setCodeHex(rs.getString("code_hex"));
                couleurs.add(couleur);
            }
        }
        return couleurs;
    }

}