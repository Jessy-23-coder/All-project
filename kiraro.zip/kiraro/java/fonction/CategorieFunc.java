package fonction;
import connexion.Connexion;
import model.Categorie;
import model.SousCategorie;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CategorieFunc {
    
    public List<Categorie> getAllCategories() throws Exception {
        List<Categorie> categories = new ArrayList<>();
        String sql = "SELECT * FROM categorie ORDER BY nom";
        
        try (Connection conn = Connexion.getPostgresCon();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Categorie categorie = new Categorie();
                categorie.setId(rs.getInt("id"));
                categorie.setNom(rs.getString("nom"));
                categories.add(categorie);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return categories;
    }
    
    public List<String> getAllCategoriesNames() throws Exception {
        List<String> noms = new ArrayList<>();
        String sql = "SELECT nom FROM categorie ORDER BY nom";
        
        try (Connection conn = Connexion.getPostgresCon();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                noms.add(rs.getString("nom"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return noms;
    }
    
    public List<SousCategorie> getSousCategoriesByCategorie(int idCategorie) throws Exception {
        List<SousCategorie> sousCategories = new ArrayList<>();
        String sql = "SELECT sc.*, c.nom as categorie_nom " +
                    "FROM sous_categorie sc " +
                    "JOIN categorie c ON sc.idcateg = c.id " +
                    "WHERE sc.idcateg = ? ORDER BY sc.nom";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idCategorie);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    SousCategorie sousCategorie = new SousCategorie();
                    sousCategorie.setId(rs.getInt("id"));
                    sousCategorie.setNom(rs.getString("nom"));
                    sousCategorie.setIdCategorie(rs.getInt("idcateg"));
                    sousCategorie.setCategorieNom(rs.getString("categorie_nom"));
                    sousCategories.add(sousCategorie);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sousCategories;
    }
    
    public boolean createCategorie(String nom) throws Exception {
        String sql = "INSERT INTO categorie (nom) VALUES (?)";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, nom);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean deleteCategorie(int id) throws Exception {
        String sql = "DELETE FROM categorie WHERE id = ?";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}