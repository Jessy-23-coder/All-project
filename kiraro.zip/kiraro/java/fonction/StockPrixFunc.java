package fonction;
import connexion.Connexion;
import model.StockPrix;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StockPrixFunc {
    
    public List<StockPrix> getStockByProduit(int idProduit) throws Exception {
        List<StockPrix> stocks = new ArrayList<>();
        String sql = "SELECT sp.*, p.pt as pointure, c.nom as couleur_nom " +
                    "FROM stock_prix sp " +
                    "JOIN variante v ON sp.idvariante = v.id " +
                    "JOIN pointure p ON sp.idpointure = p.id " +
                    "JOIN couleur c ON v.idcouleur = c.id " +
                    "WHERE v.idproduit = ? " +
                    "ORDER BY c.nom, p.pt::DECIMAL";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idProduit);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    StockPrix stock = new StockPrix();
                    stock.setId(rs.getInt("id"));
                    stock.setIdVariante(rs.getInt("idvariante"));
                    stock.setIdPointure(rs.getInt("idpointure"));
                    stock.setPointure(rs.getString("pointure"));
                    stock.setPrix(rs.getBigDecimal("prix"));
                    stock.setPrixPromo(rs.getBigDecimal("prix_promo"));
                    stock.setQuantite(rs.getInt("quantite"));
                    stocks.add(stock);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return stocks;
    }
    
    public boolean updateStock(int idStock, int quantite) throws Exception {
        String sql = "UPDATE stock_prix SET quantite = ? WHERE id = ?";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, quantite);
            pstmt.setInt(2, idStock);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean createStock(int idVariante, int idPointure, double prix, int quantite) throws Exception {
        String sql = "INSERT INTO stock_prix (idvariante, idpointure, prix, quantite) " +
                    "VALUES (?, ?, ?, ?)";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idVariante);
            pstmt.setInt(2, idPointure);
            pstmt.setDouble(3, prix);
            pstmt.setInt(4, quantite);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    public StockPrix getStockPrixComplet(int idProduit, int idCouleur, int idPointure) throws Exception {
        String sql = "SELECT sp.*, p.pt as pointure, c.nom as couleur_nom " +
                    "FROM stock_prix sp " +
                    "JOIN variante v ON sp.idvariante = v.id " +
                    "JOIN pointure p ON sp.idpointure = p.id " +
                    "JOIN couleur c ON v.idcouleur = c.id " +
                    "WHERE v.idproduit = ? AND v.idcouleur = ? AND sp.idpointure = ?";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idProduit);
            pstmt.setInt(2, idCouleur);
            pstmt.setInt(3, idPointure);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    StockPrix stock = new StockPrix();
                    stock.setId(rs.getInt("id"));
                    stock.setIdVariante(rs.getInt("idvariante"));
                    stock.setIdPointure(rs.getInt("idpointure"));
                    stock.setPointure(rs.getString("pointure"));
                    stock.setPrix(rs.getBigDecimal("prix"));
                    stock.setPrixPromo(rs.getBigDecimal("prix_promo"));
                    stock.setQuantite(rs.getInt("quantite"));
                    return stock;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors de la récupération du stock: " + e.getMessage());
        }
        return null;
    }


}


  