package fonction;

import connexion.Connexion;
import model.PanierArticle;
import java.sql.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class PanierArticleFunc {
    
    // 1. Ajouter un article au panier (sans spécifier de quantité)
    public static boolean ajouterProduitSimple(int idPanier, int idProduit) throws Exception {
        String checkSql = "SELECT id, COALESCE(quantite, 0) as quantite FROM panier_article WHERE idpanier = ? AND id_produit = ?";
        String insertSql = "INSERT INTO panier_article (idpanier, id_produit) VALUES (?, ?)";
        String updateSql = "UPDATE panier_article SET quantite = ?, date_ajout = CURRENT_TIMESTAMP WHERE id = ?";
        
        try (Connection conn = Connexion.getPostgresCon()) {
            conn.setAutoCommit(false);
            
            try {
                // Vérifier si l'article existe déjà
                PreparedStatement checkStmt = conn.prepareStatement(checkSql);
                checkStmt.setInt(1, idPanier);
                checkStmt.setInt(2, idProduit);
                ResultSet rs = checkStmt.executeQuery();
                
                if (rs.next()) {
                    // Article existe déjà - incrémenter la quantité
                    int articleId = rs.getInt("id");
                    int quantiteActuelle = rs.getInt("quantite");
                    
                    PreparedStatement updateStmt = conn.prepareStatement(updateSql);
                    updateStmt.setInt(1, quantiteActuelle + 1);
                    updateStmt.setInt(2, articleId);
                    updateStmt.executeUpdate();
                } else {
                    // Nouvel article - INSERT simple
                    PreparedStatement insertStmt = conn.prepareStatement(insertSql);
                    insertStmt.setInt(1, idPanier);
                    insertStmt.setInt(2, idProduit);
                    insertStmt.executeUpdate();
                }
                
                // Mettre à jour la date du panier
                PanierFunc.updateDatePanier(idPanier, conn);
                
                conn.commit();
                return true;
                
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors de l'ajout au panier: " + e.getMessage());
        }
    }
    
    // 2. Ajouter un article avec stock_prix et quantité
    public static boolean ajouterAvecStockPrix(int idPanier, int idStockPrix, int quantite) throws Exception {
        String checkSql = "SELECT id, quantite FROM panier_article WHERE idpanier = ? AND idstock_prix = ?";
        String insertSql = "INSERT INTO panier_article (idpanier, idstock_prix, quantite, prix_unitaire) VALUES (?, ?, ?, ?)";
        String updateSql = "UPDATE panier_article SET quantite = quantite + ?, date_ajout = CURRENT_TIMESTAMP WHERE id = ?";
        
        try (Connection conn = Connexion.getPostgresCon()) {
            conn.setAutoCommit(false);
            
            try {
                // Récupérer le prix actuel du stock
                BigDecimal prix = getPrixStock(idStockPrix);
                
                // Vérifier si l'article existe déjà
                PreparedStatement checkStmt = conn.prepareStatement(checkSql);
                checkStmt.setInt(1, idPanier);
                checkStmt.setInt(2, idStockPrix);
                ResultSet rs = checkStmt.executeQuery();
                
                if (rs.next()) {
                    // Mise à jour de la quantité
                    int existingId = rs.getInt("id");
                    int existingQuantite = rs.getInt("quantite");
                    
                    // Vérifier stock disponible
                    if (!verifierStockDisponible(idStockPrix, existingQuantite + quantite)) {
                        throw new Exception("Stock insuffisant");
                    }
                    
                    PreparedStatement updateStmt = conn.prepareStatement(updateSql);
                    updateStmt.setInt(1, quantite);
                    updateStmt.setInt(2, existingId);
                    updateStmt.executeUpdate();
                } else {
                    // Nouvel article
                    // Vérifier stock disponible
                    if (!verifierStockDisponible(idStockPrix, quantite)) {
                        throw new Exception("Stock insuffisant");
                    }
                    
                    PreparedStatement insertStmt = conn.prepareStatement(insertSql);
                    insertStmt.setInt(1, idPanier);
                    insertStmt.setInt(2, idStockPrix);
                    insertStmt.setInt(3, quantite);
                    insertStmt.setBigDecimal(4, prix);
                    insertStmt.executeUpdate();
                }
                
                // Mettre à jour la date de modification du panier
                PanierFunc.updateDatePanier(idPanier, conn);
                
                conn.commit();
                return true;
                
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors de l'ajout au panier: " + e.getMessage());
        }
    }
    
    // 3. Modifier la quantité d'un article
    public static boolean modifierQuantite(int idArticle, int nouvelleQuantite) throws Exception {
        if (nouvelleQuantite <= 0) {
            return supprimerArticle(idArticle);
        }
        
        String getStockSql = "SELECT idstock_prix, idpanier FROM panier_article WHERE id = ?";
        String updateSql = "UPDATE panier_article SET quantite = ?, date_ajout = CURRENT_TIMESTAMP WHERE id = ?";
        
        try (Connection conn = Connexion.getPostgresCon()) {
            conn.setAutoCommit(false);
            
            try {
                // Récupérer les informations
                PreparedStatement getStockStmt = conn.prepareStatement(getStockSql);
                getStockStmt.setInt(1, idArticle);
                ResultSet rs = getStockStmt.executeQuery();
                
                if (rs.next()) {
                    int idStockPrix = rs.getInt("idstock_prix");
                    int idPanier = rs.getInt("idpanier");
                    
                    // Vérifier stock disponible
                    if (!verifierStockDisponible(idStockPrix, nouvelleQuantite)) {
                        throw new Exception("Stock insuffisant");
                    }
                    
                    // Mettre à jour la quantité
                    PreparedStatement updateStmt = conn.prepareStatement(updateSql);
                    updateStmt.setInt(1, nouvelleQuantite);
                    updateStmt.setInt(2, idArticle);
                    int rows = updateStmt.executeUpdate();
                    
                    if (rows > 0) {
                        // Mettre à jour la date du panier
                        PanierFunc.updateDatePanier(idPanier, conn);
                        conn.commit();
                        return true;
                    }
                }
                
                conn.rollback();
                return false;
                
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors de la modification de la quantité: " + e.getMessage());
        }
    }
    
    // 4. Supprimer un article du panier
    public static boolean supprimerArticle(int idArticle) throws Exception {
        String getPanierSql = "SELECT idpanier FROM panier_article WHERE id = ?";
        String deleteSql = "DELETE FROM panier_article WHERE id = ?";
        
        try (Connection conn = Connexion.getPostgresCon()) {
            conn.setAutoCommit(false);
            
            try {
                // Récupérer l'id du panier
                PreparedStatement getPanierStmt = conn.prepareStatement(getPanierSql);
                getPanierStmt.setInt(1, idArticle);
                ResultSet rs = getPanierStmt.executeQuery();
                
                if (rs.next()) {
                    int idPanier = rs.getInt("idpanier");
                    
                    // Supprimer l'article
                    PreparedStatement deleteStmt = conn.prepareStatement(deleteSql);
                    deleteStmt.setInt(1, idArticle);
                    int rows = deleteStmt.executeUpdate();
                    
                    if (rows > 0) {
                        // Mettre à jour la date du panier
                        PanierFunc.updateDatePanier(idPanier, conn);
                        conn.commit();
                        return true;
                    }
                }
                
                conn.rollback();
                return false;
                
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors de la suppression de l'article: " + e.getMessage());
        }
    }
    
    // 5. Récupérer tous les articles d'un panier avec détails
    public static List<PanierArticle> getArticlesPanier(int idPanier) throws Exception {
        List<PanierArticle> articles = new ArrayList<>();
        String sql = "SELECT * FROM vue_panier_detail WHERE idpanier = ? ORDER BY date_ajout DESC";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idPanier);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    articles.add(mapResultSetToPanierArticle(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors de la récupération des articles: " + e.getMessage());
        }
        
        return articles;
    }
    
    // 6. Vérifier si un produit existe dans le panier
    public static boolean produitExisteDansPanier(int idPanier, int idProduit) throws Exception {
        String sql = "SELECT COUNT(*) FROM panier_article WHERE idpanier = ? AND id_produit = ?";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idPanier);
            pstmt.setInt(2, idProduit);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors de la vérification: " + e.getMessage());
        }
        
        return false;
    }
    
    // 7. Récupérer le nombre total d'articles dans le panier
    public static int getNombreArticlesPanier(int idPanier) throws Exception {
        String sql = "SELECT COUNT(*) as total FROM panier_article WHERE idpanier = ?";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idPanier);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("total");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors du comptage: " + e.getMessage());
        }
        
        return 0;
    }
    
    // 8. Récupérer l'id du stock_prix pour une combinaison produit/couleur/pointure
    public static Integer getStockPrixId(int idProduit, String couleur, String pointure) throws Exception {
        String sql = "SELECT sp.id FROM stock_prix sp " +
                    "JOIN variante v ON sp.idvariante = v.id " +
                    "JOIN couleur c ON v.idcouleur = c.id " +
                    "JOIN pointure p ON sp.idpointure = p.id " +
                    "WHERE v.idproduit = ? AND c.nom = ? AND p.pt = ?";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idProduit);
            pstmt.setString(2, couleur);
            pstmt.setString(3, pointure);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        }
        return null;
    }
    
    // 9. Vérifier la disponibilité du stock
    private static boolean verifierStockDisponible(int idStockPrix, int quantiteDemandee) throws Exception {
        String sql = "SELECT quantite FROM stock_prix WHERE id = ?";
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idStockPrix);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                int stockDisponible = rs.getInt("quantite");
                return stockDisponible >= quantiteDemandee;
            }
        }
        return false;
    }
    
    // 10. Récupérer le prix d'un stock
    private static BigDecimal getPrixStock(int idStockPrix) throws Exception {
        String sql = "SELECT COALESCE(prix_promo, prix) as prix_final FROM stock_prix WHERE id = ?";
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idStockPrix);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getBigDecimal("prix_final");
            }
        }
        return BigDecimal.ZERO;
    }
    
    // Méthode de mapping
    private static PanierArticle mapResultSetToPanierArticle(ResultSet rs) throws SQLException {
        PanierArticle article = new PanierArticle();
        article.setId(rs.getInt("id"));
        article.setIdPanier(rs.getInt("idpanier"));
        article.setIdStockPrix(rs.getInt("idstock_prix"));
        article.setQuantite(rs.getInt("quantite"));
        article.setPrixUnitaire(rs.getBigDecimal("prix_unitaire"));
        article.setRemiseAppliquee(rs.getBigDecimal("remise_appliquee"));
        article.setDateAjout(rs.getTimestamp("date_ajout"));
        
        // Informations supplémentaires
        article.setNomProduit(rs.getString("nomProduit"));
        article.setReference(rs.getString("reference"));
        article.setModele(rs.getString("modele_nom"));
        article.setMarque(rs.getString("marque_nom"));
        article.setCouleur(rs.getString("couleur_nom"));
        article.setPointure(rs.getString("pointure_taille"));
        article.setPrixCourant(rs.getBigDecimal("prix_courant"));
        article.setPromoCourante(rs.getBigDecimal("prix_promo_courant"));
        article.setImages(rs.getString("images"));

        
        return article;
    }
}
