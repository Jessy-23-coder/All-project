package fonction;

import connexion.Connexion;
import model.Utilisateur;
import java.sql.*;
import java.util.ArrayList;

public class UtilisateurFunc {
    
    // Vérifier login
    public Utilisateur checkLogin(String email, String password) throws Exception {
        Utilisateur user = null;
        String sql = "SELECT * FROM utilisateurs WHERE email = ? AND mot_de_passe = ?";
        
        try (Connection con = Connexion.getPostgresCon();
             PreparedStatement statprep = con.prepareStatement(sql)) {
            
            statprep.setString(1, email);
            statprep.setString(2, password);
            
            ResultSet rs = statprep.executeQuery();
            
            if (rs.next()) {
                user = new Utilisateur();
                user.setId(rs.getInt("id"));
                user.setEmail(rs.getString("email"));
                user.setNom(rs.getString("nom"));
                user.setPrenom(rs.getString("prenom"));
                user.setRole(rs.getString("role"));
            }
            
            rs.close();
            statprep.close();
            con.close();
            
        } catch (SQLException e) {
            throw new Exception("Erreur login: " + e.getMessage());
        }
        
        return user;
    }
    
    // Inscription utilisateur
    public void insertUtilisateur(String email, String password, String nom, String prenom) throws Exception {
        String sql = "INSERT INTO utilisateurs(email, mot_de_passe, nom, prenom) VALUES (?, ?, ?, ?)";
        
        try (Connection con = Connexion.getPostgresCon();
             PreparedStatement statprep = con.prepareStatement(sql)) {
            
            statprep.setString(1, email);
            statprep.setString(2, password);
            statprep.setString(3, nom);
            statprep.setString(4, prenom);
            
            statprep.executeUpdate();
            statprep.close();
            con.close();
            
        } catch (SQLException e) {
            throw new Exception("Erreur inscription: " + e.getMessage());
        }
    }
    
    // Vérifier si email existe déjà
    public boolean emailExists(String email) throws Exception {
        String sql = "SELECT COUNT(*) FROM utilisateurs WHERE email = ?";
        
        try (Connection con = Connexion.getPostgresCon();
             PreparedStatement statprep = con.prepareStatement(sql)) {
            
            statprep.setString(1, email);
            ResultSet rs = statprep.executeQuery();
            
            boolean exists = false;
            if (rs.next()) {
                exists = rs.getInt(1) > 0;
            }
            
            rs.close();
            statprep.close();
            con.close();
            
            return exists;
            
        } catch (SQLException e) {
            throw new Exception("Erreur vérification email: " + e.getMessage());
        }
    }
    
    // Récupérer tous les utilisateurs
    public ArrayList<Utilisateur> getAllUsers() throws Exception {
        ArrayList<Utilisateur> users = new ArrayList<>();
        String sql = "SELECT * FROM utilisateurs";
        
        try (Connection con = Connexion.getPostgresCon();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Utilisateur user = new Utilisateur();
                user.setId(rs.getInt("id"));
                user.setEmail(rs.getString("email"));
                user.setNom(rs.getString("nom"));
                user.setPrenom(rs.getString("prenom"));
                user.setRole(rs.getString("role"));
                users.add(user);
            }
            
            rs.close();
            stmt.close();
            con.close();
            
        } catch (SQLException e) {
            throw new Exception("Erreur récupération users: " + e.getMessage());
        }
        
        return users;
    }
    
    // Récupérer un utilisateur par ID
    public Utilisateur getUserById(int id) throws Exception {
        Utilisateur user = null;
        String sql = "SELECT * FROM utilisateurs WHERE id = ?";
        
        try (Connection con = Connexion.getPostgresCon();
             PreparedStatement statprep = con.prepareStatement(sql)) {
            
            statprep.setInt(1, id);
            ResultSet rs = statprep.executeQuery();
            
            if (rs.next()) {
                user = new Utilisateur();
                user.setId(rs.getInt("id"));
                user.setEmail(rs.getString("email"));
                user.setNom(rs.getString("nom"));
                user.setPrenom(rs.getString("prenom"));
                user.setRole(rs.getString("role"));
            }
            
            rs.close();
            statprep.close();
            con.close();
            
        } catch (SQLException e) {
            throw new Exception("Erreur récupération user: " + e.getMessage());
        }
        
        return user;
    }
}