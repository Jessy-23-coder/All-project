package model;

import java.math.BigDecimal;

public class StockPrix {
    private int id;
    private int idVariante;
    private int idPointure;
    private String pointure;
    private BigDecimal prix;
    private BigDecimal prixPromo;
    private int quantite;
    
    // Constructeurs
    public StockPrix() {}
    public StockPrix(int idVariante, int idPointure, BigDecimal prix, int quantite) {
        this.idVariante = idVariante;
        this.idPointure = idPointure;
        this.prix = prix;
        this.quantite = quantite;
    }
    
    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getIdVariante() { return idVariante; }
    public void setIdVariante(int idVariante) { this.idVariante = idVariante; }
    
    public int getIdPointure() { return idPointure; }
    public void setIdPointure(int idPointure) { this.idPointure = idPointure; }
    
    public String getPointure() { return pointure; }
    public void setPointure(String pointure) { this.pointure = pointure; }
    
    public BigDecimal getPrix() { return prix; }
    public void setPrix(BigDecimal prix) { this.prix = prix; }
    
    public BigDecimal getPrixPromo() { return prixPromo; }
    public void setPrixPromo(BigDecimal prixPromo) { this.prixPromo = prixPromo; }
    
    public int getQuantite() { return quantite; }
    public void setQuantite(int quantite) { this.quantite = quantite; }
}