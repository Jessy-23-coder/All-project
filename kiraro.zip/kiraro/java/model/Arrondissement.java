package model;

import java.math.BigDecimal;

public class Arrondissement {
    private int id;
    private String nom;
    private BigDecimal prixLivraison;
    
    // Constructeurs
    public Arrondissement() {}
    
    public Arrondissement(int id, String nom, BigDecimal prixLivraison) {
        this.id = id;
        this.nom = nom;
        this.prixLivraison = prixLivraison;
    }
    
    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }
    
    public BigDecimal getPrixLivraison() { return prixLivraison; }
    public void setPrixLivraison(BigDecimal prixLivraison) { this.prixLivraison = prixLivraison; }
    
    @Override
    public String toString() {
        return "Arrondissement{" +
                "id=" + id +
                ", nom='" + nom + '\'' +
                ", prixLivraison=" + prixLivraison +
                '}';
    }
}