package model;

public class Modele {
    private int id;
    private String nom;
    private String description;
    private int idMarque;
    private String marqueNom;
    
    // Constructeurs
    public Modele() {}
    public Modele(int id, String nom, int idMarque) {
        this.id = id;
        this.nom = nom;
        this.idMarque = idMarque;
    }
    
    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public int getIdMarque() { return idMarque; }
    public void setIdMarque(int idMarque) { this.idMarque = idMarque; }
    
    public String getMarqueNom() { return marqueNom; }
    public void setMarqueNom(String marqueNom) { this.marqueNom = marqueNom; }
}