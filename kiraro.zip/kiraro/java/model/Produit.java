package model;

import java.math.BigDecimal;
import java.util.Date;

public class Produit {
    private int id;
    private String nom;
    private String reference;
    private String description;
    private String caracteristiques;
    private boolean estActif;
    private String images;
    private Date dateAjout;
    
    // Relations
    private int idModele;
    private String modeleNom;
    private String modeleDescription;
    
    private int idMarque;
    private String marqueNom;
    
    private int idGenre;
    private String genreNom;
    
    private int idCategorie;
    private String categorieNom;
    
    private int idSousCategorie;
    private String sousCategorieNom;
    
    // Prix et stock
    private BigDecimal prix;
    private BigDecimal prixPromo;
    private int stockTotal;
    private int nbCouleurs;
    private int nbPointuresDisponibles;
    
    // Constructeurs
    public Produit() {}
    
    public Produit(int id, String nom, String reference, String description, boolean estActif) {
        this.id = id;
        this.nom = nom;
        this.reference = reference;
        this.description = description;
        this.estActif = estActif;
    }
    
    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getReference() { return reference; }
    public void setReference(String reference) { this.reference = reference; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public String getCaracteristiques() { return caracteristiques; }
    public void setCaracteristiques(String caracteristiques) { this.caracteristiques = caracteristiques; }
    
    public boolean isEstActif() { return estActif; }
    public void setEstActif(boolean estActif) { this.estActif = estActif; }
    
    public String getImages() { return images; }
    public void setImages(String images) { this.images = images; }
    
    public Date getDateAjout() { return dateAjout; }
    public void setDateAjout(Date dateAjout) { this.dateAjout = dateAjout; }
    
    public int getIdModele() { return idModele; }
    public void setIdModele(int idModele) { this.idModele = idModele; }
    
    public String getModeleNom() { return modeleNom; }
    public void setModeleNom(String modeleNom) { this.modeleNom = modeleNom; }
    
    public String getModeleDescription() { return modeleDescription; }
    public void setModeleDescription(String modeleDescription) { this.modeleDescription = modeleDescription; }
    
    public int getIdMarque() { return idMarque; }
    public void setIdMarque(int idMarque) { this.idMarque = idMarque; }
    
    public String getMarqueNom() { return marqueNom; }
    public void setMarqueNom(String marqueNom) { this.marqueNom = marqueNom; }
    
    public int getIdGenre() { return idGenre; }
    public void setIdGenre(int idGenre) { this.idGenre = idGenre; }
    
    public String getGenreNom() { return genreNom; }
    public void setGenreNom(String genreNom) { this.genreNom = genreNom; }
    
    public int getIdCategorie() { return idCategorie; }
    public void setIdCategorie(int idCategorie) { this.idCategorie = idCategorie; }
    
    public String getCategorieNom() { return categorieNom; }
    public void setCategorieNom(String categorieNom) { this.categorieNom = categorieNom; }
    
    public int getIdSousCategorie() { return idSousCategorie; }
    public void setIdSousCategorie(int idSousCategorie) { this.idSousCategorie = idSousCategorie; }
    
    public String getSousCategorieNom() { return sousCategorieNom; }
    public void setSousCategorieNom(String sousCategorieNom) { this.sousCategorieNom = sousCategorieNom; }
    
    public BigDecimal getPrix() { return prix; }
    public void setPrix(BigDecimal prix) { this.prix = prix; }
    
    public BigDecimal getPrixPromo() { return prixPromo; }
    public void setPrixPromo(BigDecimal prixPromo) { this.prixPromo = prixPromo; }
    
    public int getStockTotal() { return stockTotal; }
    public void setStockTotal(int stockTotal) { this.stockTotal = stockTotal; }
    
    public int getNbCouleurs() { return nbCouleurs; }
    public void setNbCouleurs(int nbCouleurs) { this.nbCouleurs = nbCouleurs; }
    
    public int getNbPointuresDisponibles() { return nbPointuresDisponibles; }
    public void setNbPointuresDisponibles(int nbPointuresDisponibles) { this.nbPointuresDisponibles = nbPointuresDisponibles; }

    public String getNom() {return nom;}

    public void setNom(String nom) {this.nom = nom;}

    public String getFirstImage() {
    if (images == null || images.isEmpty()) {
        return "default.jpg";
    }
    
    try {
        // Simple extraction pour JSON comme ["image1.jpg", "image2.jpg"]
        String cleanJson = images.replaceAll("\\[|\\]|\"", "").trim();
        String[] parts = cleanJson.split(",");
        if (parts.length > 0 && !parts[0].trim().isEmpty()) {
            return parts[0].trim();
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    
    return "default.jpg";
}

   
}