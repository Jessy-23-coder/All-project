// model/PanierArticle.java
package model;

import java.math.BigDecimal;
import java.sql.Timestamp;


public class PanierArticle {
    private int id;
    private int idPanier;
    private int idProduit;
    private int quantite;
    private BigDecimal remiseAppliquee;
    private Timestamp dateAjout;
    
    // Informations supplémentaires pour l'affichage
    private String nomProduit;
    private String reference;
    private String modele;
    private String marque;
    private String couleur;
    private String pointure;
    private BigDecimal prixCourant;
    private BigDecimal promoCourante;
    private String images;
    
    // Constructeurs
    public PanierArticle() {}
    
    public PanierArticle(int idPanier, int quantite) {
        this.idPanier = idPanier;
        this.quantite = quantite;
    }
    
    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getIdPanier() { return idPanier; }
    public void setIdPanier(int idPanier) { this.idPanier = idPanier; }
    
    public int getIdProduit() { return idProduit; }
    public void setIdProduit(int idProduit) { this.idProduit = idProduit; }
    
    
    public int getQuantite() { return quantite; }
    public void setQuantite(int quantite) { this.quantite = quantite; }
    
    
    public BigDecimal getRemiseAppliquee() { return remiseAppliquee; }
    public void setRemiseAppliquee(BigDecimal remiseAppliquee) { this.remiseAppliquee = remiseAppliquee; }
    
    public Timestamp getDateAjout() { return dateAjout; }
    public void setDateAjout(Timestamp dateAjout) { this.dateAjout = dateAjout; }
    
    // Getters pour l'affichage
    public String getReference() { return reference; }
    public void setReference(String reference) { this.reference = reference; }
    
    public String getModele() { return modele; }
    public void setModele(String modele) { this.modele = modele; }
    
    public String getMarque() { return marque; }
    public void setMarque(String marque) { this.marque = marque; }
    
    public String getCouleur() { return couleur; }
    public void setCouleur(String couleur) { this.couleur = couleur; }
    
    public String getPointure() { return pointure; }
    public void setPointure(String pointure) { this.pointure = pointure; }
    
    public BigDecimal getPrixCourant() { return prixCourant; }
    public void setPrixCourant(BigDecimal prixCourant) { this.prixCourant = prixCourant; }
    
    public BigDecimal getPromoCourante() { return promoCourante; }
    public void setPromoCourante(BigDecimal promoCourante) { this.promoCourante = promoCourante; }
    
    public String getNomProduit() {return nomProduit;}

    public void setNomProduit(String nomProduit) {this.nomProduit = nomProduit;}


    public String getImages() {
        return images;
    }

    public void setImages(String images) {
        this.images = images;
    }
}