package model;

import java.sql.Timestamp;

public class Livraison {
    private int id;
    private int idPanier;
    private int idSecteur;
    private Timestamp dateHeure;
    
    // Constructeurs
    public Livraison() {}
    
    public Livraison(int id, int idPanier, int idSecteur, Timestamp dateHeure) {
        this.id = id;
        this.idPanier = idPanier;
        this.idSecteur = idSecteur;
        this.dateHeure = dateHeure;
    }
    
    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getIdPanier() { return idPanier; }
    public void setIdPanier(int idPanier) { this.idPanier = idPanier; }
    
    public int getIdSecteur() { return idSecteur; }
    public void setIdSecteur(int idSecteur) { this.idSecteur = idSecteur; }
    
    public Timestamp getDateHeure() { return dateHeure; }
    public void setDateHeure(Timestamp dateHeure) { this.dateHeure = dateHeure; }
    
    @Override
    public String toString() {
        return "Livraison{" +
                "id=" + id +
                ", idPanier=" + idPanier +
                ", idSecteur=" + idSecteur +
                ", dateHeure=" + dateHeure +
                '}';
    }
}