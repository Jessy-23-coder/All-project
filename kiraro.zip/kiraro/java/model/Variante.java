package model;

public class Variante {
    private int id;
    private int idProduit;
    private int idCouleur;
    private String couleurNom;
    private String codeHex;
    
    // Constructeurs
    public Variante() {}
    public Variante(int idProduit, int idCouleur) {
        this.idProduit = idProduit;
        this.idCouleur = idCouleur;
    }
    
    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getIdProduit() { return idProduit; }
    public void setIdProduit(int idProduit) { this.idProduit = idProduit; }
    
    public int getIdCouleur() { return idCouleur; }
    public void setIdCouleur(int idCouleur) { this.idCouleur = idCouleur; }
    
    public String getCouleurNom() { return couleurNom; }
    public void setCouleurNom(String couleurNom) { this.couleurNom = couleurNom; }
    
    public String getCodeHex() { return codeHex; }
    public void setCodeHex(String codeHex) { this.codeHex = codeHex; }
}