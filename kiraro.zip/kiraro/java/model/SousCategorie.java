package model;

public class SousCategorie {
    private int id;
    private String nom;
    private int idCategorie;
    private String categorieNom;
    
    // Constructeurs
    public SousCategorie() {}
    public SousCategorie(int id, String nom, int idCategorie) {
        this.id = id;
        this.nom = nom;
        this.idCategorie = idCategorie;
    }
    
    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }
    
    public int getIdCategorie() { return idCategorie; }
    public void setIdCategorie(int idCategorie) { this.idCategorie = idCategorie; }
    
    public String getCategorieNom() { return categorieNom; }
    public void setCategorieNom(String categorieNom) { this.categorieNom = categorieNom; }
}