package model;

public class Pointure {
    private int id;
    private String pt;
    private int quantite;


// Constructeurs
    public Pointure() {}
    public Pointure(int id, String pt, int quantite) {
        this.id = id;
        this.pt = pt;
        this.quantite = quantite;
    }
    
    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getPt() { return pt; }
    public void setPt(String pt) { this.pt = pt; }

    public int getQuantite() { return quantite; }
    public void setQuantite(int quantite) { this.quantite = quantite; }
}