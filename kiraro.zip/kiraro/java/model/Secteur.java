package model;

public class Secteur {
    private int id;
    private String nom;
    private int idArrondissement;
    
    // Constructeurs
    public Secteur() {}
    
    public Secteur(int id, String nom, int idArrondissement) {
        this.id = id;
        this.nom = nom;
        this.idArrondissement = idArrondissement;
    }
    
    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }
    
    public int getIdArrondissement() { return idArrondissement; }
    public void setIdArrondissement(int idArrondissement) { this.idArrondissement = idArrondissement; }
    
    @Override
    public String toString() {
        return "Secteur{" +
                "id=" + id +
                ", nom='" + nom + '\'' +
                ", idArrondissement=" + idArrondissement +
                '}';
    }
}