package connexion;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connexion {
    public static Connection getPostgresCon() throws Exception {
        try {
            Class.forName("org.postgresql.Driver");
            String url = "jdbc:postgresql://localhost:5432/kiraro";
            String user = "postgres";
            String password = "123";
            
            return DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            throw new Exception("Erreur de connexion: " + e.getMessage());
        }
    }
}