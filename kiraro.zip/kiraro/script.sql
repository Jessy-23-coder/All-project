--databse : kiraro

CREATE TABLE utilisateurs (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    mot_de_passe VARCHAR(255) NOT NULL,
    nom VARCHAR(100),
    prenom VARCHAR(100),
    role VARCHAR(20) DEFAULT 'client'
);

-- 1. CATÉGORIE
CREATE TABLE categorie (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(100)
);

-- 2. SOUS_CATEGORIE
CREATE TABLE sous_categorie (
    id SERIAL PRIMARY KEY,
    idcateg INTEGER,
    nom VARCHAR(100),
    FOREIGN KEY (idcateg) REFERENCES categorie(id) ON DELETE CASCADE
);

-- 3. POINTURE
CREATE TABLE pointure (
    id SERIAL PRIMARY KEY,
    pt VARCHAR(10) UNIQUE NOT NULL
);

-- 4. MARQUE
CREATE TABLE marque (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(100) UNIQUE
);

-- 5. GENRE
CREATE TABLE genre (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(50) UNIQUE
);

-- 6. MODÈLE
CREATE TABLE modele (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(200) NOT NULL,
    idmarque INTEGER,
    description TEXT,
    FOREIGN KEY (idmarque) REFERENCES marque(id) ON DELETE CASCADE
);

-- 7. COULEUR
CREATE TABLE couleur (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(50) UNIQUE,
    code_hex VARCHAR(7)
);

-- 8. PRODUIT
CREATE TABLE produit (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(255),
    idmodele INTEGER,
    idgenre INTEGER,
    idsouscategorie INTEGER,
    reference VARCHAR(100) UNIQUE,
    description TEXT,
    caracteristiques JSONB,
    est_actif BOOLEAN DEFAULT true,
    images JSONB,
    date_ajout TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (idmodele) REFERENCES modele(id) ON DELETE CASCADE,
    FOREIGN KEY (idgenre) REFERENCES genre(id) ON DELETE CASCADE,
    FOREIGN KEY (idsouscategorie) REFERENCES sous_categorie(id) ON DELETE CASCADE
);

-- 9. VARIANTE
CREATE TABLE variante (
    id SERIAL PRIMARY KEY,
    idproduit INTEGER,
    idcouleur INTEGER,
    
    FOREIGN KEY (idproduit) REFERENCES produit(id) ON DELETE CASCADE,
    FOREIGN KEY (idcouleur) REFERENCES couleur(id) ON DELETE CASCADE,
    
    UNIQUE (idproduit, idcouleur)
);


-- 10. STOCK_PRIX
CREATE TABLE stock_prix (
    id SERIAL PRIMARY KEY,
    idvariante INTEGER,
    idpointure INTEGER,
    prix DECIMAL(10,2) NOT NULL CHECK (prix >= 0),
    prix_promo DECIMAL(10,2) CHECK (prix_promo >= 0),
    quantite INTEGER DEFAULT 0 CHECK (quantite >= 0),
    
    FOREIGN KEY (idvariante) REFERENCES variante(id) ON DELETE CASCADE,
    FOREIGN KEY (idpointure) REFERENCES pointure(id) ON DELETE CASCADE,
    CHECK (prix_promo IS NULL OR prix_promo <= prix),
    UNIQUE (idvariante, idpointure)

);


-- Création des index pour optimiser les performances
CREATE INDEX idx_souscategorie_categorie ON sous_categorie(idcateg);
CREATE INDEX idx_modele_marque ON modele(idmarque);
CREATE INDEX idx_produit_modele ON produit(idmodele);
CREATE INDEX idx_produit_genre ON produit(idgenre);
CREATE INDEX idx_produit_souscategorie ON produit(idsouscategorie);
CREATE INDEX idx_variante_produit ON variante(idproduit);
CREATE INDEX idx_variante_couleur ON variante(idcouleur);
CREATE INDEX idx_stock_variante ON stock_prix(idvariante);
CREATE INDEX idx_stock_pointure ON stock_prix(idpointure);
CREATE INDEX idx_produit_actif ON produit(est_actif) WHERE est_actif = true;


-- Optionnel: Fonction pour calculer le prix final
CREATE OR REPLACE FUNCTION prix_final(prix_base DECIMAL, prix_promo DECIMAL)
RETURNS DECIMAL AS $$
BEGIN
    RETURN COALESCE(prix_promo, prix_base);
END;
$$ LANGUAGE plpgsql;

drop VIEW vue_produit_complet;
-- Recréer la vue avec COALESCE approprié
CREATE OR REPLACE VIEW vue_produit_complet AS
SELECT 
    p.id,
    p.nom,
    p.reference,
    p.description,
    p.caracteristiques,
    p.est_actif,
    p.images,
    p.date_ajout,
    
    m.id as modele_id,
    m.nom as modele_nom,
    m.description as modele_description,
    
    marque.id as marque_id,
    marque.nom as marque_nom,
    
    g.id as genre_id,
    g.nom as genre_nom,
    
    cat.id as categorie_id,
    cat.nom as categorie_nom,
    
    sc.id as sous_categorie_id,
    sc.nom as sous_categorie_nom,
    
    -- PRIX : CORRIGÉ POUR ÉVITER LES NULL
    COALESCE(MIN(sp.prix_promo), MIN(sp.prix), 0.00) as prix_min,
    COALESCE(MAX(sp.prix_promo), MAX(sp.prix), 0.00) as prix_max,
    COALESCE(MIN(sp.prix), 0.00) as prix_base_min,
    COALESCE(MAX(sp.prix), 0.00) as prix_base_max,
    
    -- Stock
    COALESCE(SUM(sp.quantite), 0) as stock_total,
    
    -- Disponibilité
    COUNT(DISTINCT v.idcouleur) as nb_couleurs,
    COUNT(DISTINCT sp.idpointure) as nb_pointures_total,
    COUNT(DISTINCT CASE WHEN sp.quantite > 0 THEN sp.idpointure END) as nb_pointures_disponibles,
    
    -- Promotion flag
    MAX(CASE WHEN sp.prix_promo IS NOT NULL THEN 1 ELSE 0 END) as a_promotion
    
FROM produit p
JOIN modele m ON p.idmodele = m.id
JOIN marque ON m.idmarque = marque.id
JOIN genre g ON p.idgenre = g.id
JOIN sous_categorie sc ON p.idsouscategorie = sc.id
JOIN categorie cat ON sc.idcateg = cat.id
LEFT JOIN variante v ON p.id = v.idproduit
LEFT JOIN stock_prix sp ON v.id = sp.idvariante
WHERE p.est_actif = true
GROUP BY p.id,p.nom, p.reference, p.description, p.caracteristiques, p.est_actif, p.images, p.date_ajout,
         m.id, m.nom, m.description, marque.id, marque.nom, g.id, g.nom, 
         cat.id, cat.nom, sc.id, sc.nom;


--Panier


-- Table pour les paramètres de remise par quantité
CREATE TABLE parametre_remise (
    id SERIAL PRIMARY KEY,
    quantite_min INTEGER NOT NULL CHECK (quantite_min >= 0),
    quantite_max INTEGER CHECK (quantite_max >= quantite_min OR quantite_max IS NULL),
    pourcentage_remise DECIMAL(5,2) NOT NULL CHECK (pourcentage_remise >= 0 AND pourcentage_remise <= 100),
    date_debut TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    date_fin TIMESTAMP,
    est_actif BOOLEAN DEFAULT true
);

-- Table panier (en-tête)
CREATE TABLE panier (
    id SERIAL PRIMARY KEY,
    idutilisateur INTEGER NOT NULL,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    date_modification TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (idutilisateur) REFERENCES utilisateurs(id) ON DELETE CASCADE
);


select sp.prix from stock_prix  join variante as v on sp.idvariante = v.id where v.idproduit = 1

-- Table pour les articles dans le panier
CREATE TABLE panier_article (
    id SERIAL PRIMARY KEY,
    idpanier INTEGER NOT NULL,
    id_produit INTEGER NOT NULL REFERENCES produit(id) ON DELETE CASCADE,
    quantite INTEGER NOT NULL CHECK (quantite > 0),
    remise_appliquee DECIMAL(5,2) DEFAULT 0 CHECK (remise_appliquee >= 0 AND remise_appliquee <= 100),
    date_ajout TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (idpanier) REFERENCES panier(id) ON DELETE CASCADE,
    
    FOREIGN KEY (idstock_prix) REFERENCES stock_prix(id) ON DELETE CASCADE,
    UNIQUE (idpanier, idstock_prix)
);


-- CREATE VIEW vue_panier_detail AS
-- SELECT 
--     pa.id,
--     pa.idpanier,
--     pa.idstock_prix,
--     pa.id_produit,  -- Colonne ajoutée  -- Colonne ajoutée
--     pa.quantite,
--     pa.prix_unitaire,
--     pa.remise_appliquee,
--     pa.date_ajout,
    
--     -- Calcul du sous-total avec remise
--     (pa.prix_unitaire * pa.quantite * (1 - pa.remise_appliquee / 100)) AS sous_total_remise,
    
--     -- Informations PRODUIT complètes
--     p.id as produit_id,
--     p.nom as nom_produit,        -- Nom du produit
--     p.reference,
--     p.description,
--     p.images,
    
--     -- Informations MODÈLE
--     m.id as modele_id,
--     m.nom as modele_nom,
    
--     -- Informations MARQUE
--     mar.id as marque_id,
--     mar.nom as marque_nom,
    
--     -- Informations VARIANTE (couleur)
--     c.id as couleur_id,
--     c.nom as couleur_nom,
--     c.code_hex as couleur_code,
    
--     -- Informations POINTURE
--     pt.id as pointure_id,
--     pt.pt as pointure_taille,
    
--     -- Informations STOCK et PRIX
--     sp.prix as prix_courant,
--     sp.prix_promo as prix_promo_courant,
--     sp.quantite as stock_disponible,
    
--     -- Informations CATÉGORIE
--     cat.nom as categorie_nom,
--     ssc.nom as sous_categorie_nom,
    
--     -- Informations GENRE
--     g.nom as genre_nom
    
-- FROM panier_article pa

-- -- Jointures principales
-- JOIN stock_prix sp ON pa.idstock_prix = sp.id
-- JOIN pointure pt ON sp.idpointure = pt.id
-- JOIN variante v ON sp.idvariante = v.id
-- JOIN produit p ON v.idproduit = p.id
-- JOIN couleur c ON v.idcouleur = c.id
-- JOIN modele m ON p.idmodele = m.id
-- JOIN marque mar ON m.idmarque = mar.id

-- -- Jointures supplémentaires
-- LEFT JOIN sous_categorie ssc ON p.idsouscategorie = ssc.id
-- LEFT JOIN categorie cat ON ssc.idcateg = cat.id
-- LEFT JOIN genre g ON p.idgenre = g.id

-- ORDER BY pa.date_ajout DESC;



DROP VIEW IF EXISTS vue_panier_detail;

CREATE OR REPLACE VIEW vue_panier_detail AS
SELECT 
    pa.id,
    pa.idpanier,
    pa.id_produit,
    pa.quantite,
    pa.remise_appliquee,
    pa.date_ajout,
    
    -- Informations PRODUIT
    p.id as produit_id,
    p.nom as nomProduit,
    p.reference,
    p.description,
    p.images,
    
    -- Informations MODÈLE
    m.id as modele_id,
    m.nom as modele_nom,
    m.description as modele_description,

    (COALESCE(sp.prix_promo, sp.prix) * pa.quantite) as sous_total,
    
    -- Informations MARQUE
    mar.id as marque_id,
    mar.nom as marque_nom,
    
    -- Informations VARIANTE (couleur)
    c.id as couleur_id,
    c.nom as couleur_nom,
    c.code_hex as couleur_code,
    
    -- Informations POINTURE
    pt.id as pointure_id,
    pt.pt as pointure_taille,
    
    -- Informations STOCK et PRIX - IMPORTANT: pas de prix_promo_courant dans stock_prix
    sp.prix as prix_courant,
    sp.prix_promo as prix_promo_courant,
    sp.quantite as stock_disponible,
    
    -- Informations CATÉGORIE
    cat.nom as categorie_nom,
    ssc.nom as sous_categorie_nom,
    
    -- Informations GENRE
    g.nom as genre_nom
    
FROM panier_article pa

-- Jointure avec produit (toujours présent)
LEFT JOIN produit p ON pa.id_produit = p.id
LEFT JOIN variante v ON p.id = v.idproduit
LEFT JOIN modele m ON p.idmodele = m.id
LEFT JOIN marque mar ON m.idmarque = mar.id
LEFT JOIN genre g ON p.idgenre = g.id
LEFT JOIN sous_categorie ssc ON p.idsouscategorie = ssc.id
LEFT JOIN categorie cat ON ssc.idcateg = cat.id

-- Jointures optionnelles (peuvent être NULL)
LEFT JOIN stock_prix sp ON v.id = sp.idvariante
LEFT JOIN pointure pt ON sp.idpointure = pt.id
LEFT JOIN couleur c ON v.idcouleur = c.id

ORDER BY pa.date_ajout DESC;

-- Table des Arrondissements
CREATE TABLE arrondissement (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(100),
    prix_livraison DECIMAL(10,2)
);

-- Table des Secteurs
CREATE TABLE secteur (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(100),
    idArrondissement INTEGER,
    FOREIGN KEY (idArrondissement) REFERENCES arrondissement(id)
);

-- Table des Livraisons
CREATE TABLE livraison (
    id SERIAL PRIMARY KEY,
    idPanier INTEGER,
    idSecteur INTEGER,
    dateHeure TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (idPanier) REFERENCES panier(id),
    FOREIGN KEY (idSecteur) REFERENCES secteur(id)
);