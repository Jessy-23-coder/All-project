-- Utilisateur test (mot de passe: "test")
INSERT INTO utilisateurs (email, mot_de_passe, nom, prenom,role) 
VALUES ('ralay@example.com', 'test', 'Ralay', 'Jean','client');

INSERT INTO utilisateurs (email, mot_de_passe, nom, prenom,role) 
VALUES ('admin@shoesshop.com', 'admin123','Rakoto', 'Benja', 'admin');


-- 1. Correction de l'insertion des catégories (une seule valeur par INSERT)

INSERT INTO categorie (nom) VALUES ('Chaussures');

-- 2. Garder 5 sous-catégories principales

INSERT INTO sous_categorie (idcateg, nom) VALUES 
(1, 'Baskets'),
(1, 'Bottes'),
(1, 'Sandales'),
(1, 'Escarpins'),
(1, 'Mocassins');

-- 3. Garder 4 genres principaux

INSERT INTO genre (nom) VALUES 
('Homme'),
('Femme'),
('Enfant'),
('Unisexe');

-- 4. Garder 5 marques principales

INSERT INTO marque (nom) VALUES 
('Nike'),
('Adidas'),
('Puma'),
('New Balance'),
('Converse');

-- 5. Garder 5 modèles cohérents (1 par marque)

INSERT INTO modele (nom, idmarque, description) VALUES 
('Air Force 1', 1, 'Basket basse emblématique Nike'),
('Stan Smith', 2, 'Tennis shoe classique Adidas'),
('Suede Classic', 3, 'Basket en daim Puma'),
('574 Core', 4, 'Running classique New Balance'),
('Chuck Taylor', 5, 'Basket canvas iconique Converse');

-- 6. Garder 8 couleurs de base

INSERT INTO couleur (nom, code_hex) VALUES 
('Noir', '#000000'),
('Blanc', '#FFFFFF'),
('Rouge', '#FF0000'),
('Bleu', '#0000FF'),
('Vert', '#008000'),
('Gris', '#808080'),
('Rose', '#FFC0CB'),
('Jaune', '#FFFF00');

-- 7. Garder 8 pointures principales

INSERT INTO pointure (pt) VALUES 
('36'), ('37'), ('38'), ('39'), ('40'), ('41'), ('42'), ('43');

-- 8. Créer 15 produits (3 par marque) - TOUS COHÉRENTS ET COMPLETS AVEC DATE_AJOUT


-- NIKE (3 produits)
INSERT INTO produit (idmodele, idgenre, idsouscategorie, reference, description, images, est_actif, date_ajout) VALUES
(1, 1, 1, 'NIKE-AF1-NOIR', 'Nike Air Force 1 - Noir', '["nike1.jpg"]', true, '2024-01-15 10:30:00'),
(1, 1, 1, 'NIKE-AF1-BLANC', 'Nike Air Force 1 - Blanc', '["nike2.jpg"]', true, '2024-01-20 14:15:00'),
(1, 2, 1, 'NIKE-AF1-ROSE', 'Nike Air Force 1 Femme - Rose', '["nike3.jpg"]', true, '2024-02-05 09:45:00');

-- ADIDAS (3 produits)
INSERT INTO produit (idmodele, idgenre, idsouscategorie, reference, description, images, est_actif, date_ajout) VALUES
(2, 1, 1, 'ADIDAS-STAN-BLANC', 'Adidas Stan Smith - Blanc/Verte', '["adidas1.jpg"]', true, '2024-01-25 11:20:00'),
(2, 1, 1, 'ADIDAS-STAN-NOIR', 'Adidas Stan Smith - Noir', '["adidas2.jpg"]', true, '2024-02-10 16:40:00'),
(2, 2, 1, 'ADIDAS-STAN-ROUGE', 'Adidas Stan Smith Femme - Rouge', '["adidas3.jpg"]', true, '2024-02-28 13:10:00');

-- PUMA (3 produits)
INSERT INTO produit (idmodele, idgenre, idsouscategorie, reference, description, images, est_actif, date_ajout) VALUES
(3, 1, 1, 'PUMA-SUEDE-NOIR', 'Puma Suede Classic - Noir', '["puma1.jpg"]', true, '2024-02-15 08:30:00'),
(3, 1, 1, 'PUMA-SUEDE-BLEU', 'Puma Suede Classic - Bleu', '["puma2.jpg"]', true, '2024-02-22 15:25:00'),
(3, 2, 1, 'PUMA-SUEDE-ROSE', 'Puma Suede Classic Femme - Rose', '["puma3.jpg"]', true, '2024-03-05 10:50:00');

-- NEW BALANCE (3 produits)
INSERT INTO produit (idmodele, idgenre, idsouscategorie, reference, description, images, est_actif, date_ajout) VALUES
(4, 1, 1, 'NB-574-GRIS', 'New Balance 574 - Gris', '["nb1.jpg"]', true, '2024-03-01 12:00:00'),
(4, 1, 1, 'NB-574-BLEU', 'New Balance 574 - Bleu Marine', '["nb2.jpg"]', true, '2024-03-08 14:35:00'),
(4, 2, 1, 'NB-574-ROSE', 'New Balance 574 Femme - Rose', '["nb3.jpg"]', true, '2024-03-12 09:15:00');

-- CONVERSE (3 produits)
INSERT INTO produit (idmodele, idgenre, idsouscategorie, reference, description, images, est_actif, date_ajout) VALUES
(5, 1, 1, 'CONVERSE-BLANC', 'Converse Chuck Taylor - Blanc', '["converse1.jpg"]', true, '2024-03-10 11:45:00'),
(5, 1, 1, 'CONVERSE-NOIR', 'Converse Chuck Taylor - Noir', '["converse2.jpg"]', true, '2024-03-18 16:20:00'),
(5, 3, 1, 'CONVERSE-ENFANT', 'Converse Chuck Taylor Enfant - Rouge', '["converse3.jpg"]', true, '2024-03-20 13:40:00');

-- 9. Créer des variantes pour CHAQUE produit (2-3 couleurs par produit)


-- Produit 1: NIKE-AF1-NOIR (2 couleurs)
INSERT INTO variante (idproduit, idcouleur) VALUES (1, 1), (1, 2); -- Noir, Blanc

-- Produit 2: NIKE-AF1-BLANC (2 couleurs)
INSERT INTO variante (idproduit, idcouleur) VALUES (2, 2), (2, 4); -- Blanc, Bleu

-- Produit 3: NIKE-AF1-ROSE (2 couleurs)
INSERT INTO variante (idproduit, idcouleur) VALUES (3, 7), (3, 2); -- Rose, Blanc

-- Produit 4: ADIDAS-STAN-BLANC (2 couleurs)
INSERT INTO variante (idproduit, idcouleur) VALUES (4, 2), (4, 5); -- Blanc, Vert

-- Produit 5: ADIDAS-STAN-NOIR (2 couleurs)
INSERT INTO variante (idproduit, idcouleur) VALUES (5, 1), (5, 3); -- Noir, Rouge

-- Produit 6: ADIDAS-STAN-ROUGE (2 couleurs)
INSERT INTO variante (idproduit, idcouleur) VALUES (6, 3), (6, 7); -- Rouge, Rose

-- Produit 7: PUMA-SUEDE-NOIR (2 couleurs)
INSERT INTO variante (idproduit, idcouleur) VALUES (7, 1), (7, 8); -- Noir, Jaune

-- Produit 8: PUMA-SUEDE-BLEU (2 couleurs)
INSERT INTO variante (idproduit, idcouleur) VALUES (8, 4), (8, 1); -- Bleu, Noir

-- Produit 9: PUMA-SUEDE-ROSE (2 couleurs)
INSERT INTO variante (idproduit, idcouleur) VALUES (9, 7), (9, 6); -- Rose, Gris

-- Produit 10: NB-574-GRIS (2 couleurs)
INSERT INTO variante (idproduit, idcouleur) VALUES (10, 6), (10, 2); -- Gris, Blanc

-- Produit 11: NB-574-BLEU (2 couleurs)
INSERT INTO variante (idproduit, idcouleur) VALUES (11, 4), (11, 5); -- Bleu, Vert

-- Produit 12: NB-574-ROSE (2 couleurs)
INSERT INTO variante (idproduit, idcouleur) VALUES (12, 7), (12, 1); -- Rose, Noir

-- Produit 13: CONVERSE-BLANC (2 couleurs)
INSERT INTO variante (idproduit, idcouleur) VALUES (13, 2), (13, 3); -- Blanc, Rouge

-- Produit 14: CONVERSE-NOIR (2 couleurs)
INSERT INTO variante (idproduit, idcouleur) VALUES (14, 1), (14, 4); -- Noir, Bleu

-- Produit 15: CONVERSE-ENFANT (2 couleurs)
INSERT INTO variante (idproduit, idcouleur) VALUES (15, 3), (15, 8); -- Rouge, Jaune

-- 10. Créer des stocks/prix COHÉRENTS pour chaque variante
-- Chaque variante aura au moins 3 pointures avec prix différents selon la pointure


-- Variante 1: Nike AF1 Noir (idvariante=1)
INSERT INTO stock_prix (idvariante, idpointure, prix, prix_promo, quantite) VALUES 
(1, 3, 99.99, NULL, 10),   -- 38: 99.99€, 10 en stock
(1, 4, 102.99, 94.99, 8),  -- 39: 102.99€ (promo 94.99), 8 en stock
(1, 5, 105.99, NULL, 6);   -- 40: 105.99€, 6 en stock

-- Variante 2: Nike AF1 Blanc (idvariante=2)
INSERT INTO stock_prix (idvariante, idpointure, prix, prix_promo, quantite) VALUES 
(2, 3, 99.99, 89.99, 12),  -- 38: 99.99€ (promo 89.99), 12 en stock
(2, 4, 102.99, NULL, 9),   -- 39: 102.99€, 9 en stock
(2, 5, 105.99, NULL, 7);   -- 40: 105.99€, 7 en stock

-- Variante 3: Nike AF1 Rose (idvariante=3)
INSERT INTO stock_prix (idvariante, idpointure, prix, prix_promo, quantite) VALUES 
(3, 1, 109.99, NULL, 8),   -- 36: 109.99€, 8 en stock
(3, 2, 112.99, 99.99, 6),  -- 37: 112.99€ (promo 99.99), 6 en stock
(3, 3, 115.99, NULL, 5);   -- 38: 115.99€, 5 en stock

-- Variante 4: Adidas Stan Blanc (idvariante=4)
INSERT INTO stock_prix (idvariante, idpointure, prix, prix_promo, quantite) VALUES 
(4, 3, 89.99, 79.99, 15),  -- 38: 89.99€ (promo 79.99), 15 en stock
(4, 4, 92.99, NULL, 12),   -- 39: 92.99€, 12 en stock
(4, 5, 95.99, NULL, 10);   -- 40: 95.99€, 10 en stock

-- Variante 5: Adidas Stan Vert (idvariante=5)
INSERT INTO stock_prix (idvariante, idpointure, prix, prix_promo, quantite) VALUES 
(5, 2, 94.99, NULL, 8),    -- 37: 94.99€, 8 en stock
(5, 3, 97.99, 87.99, 7),   -- 38: 97.99€ (promo 87.99), 7 en stock
(5, 4, 100.99, NULL, 6);   -- 39: 100.99€, 6 en stock

-- Variante 6: Adidas Stan Rouge (idvariante=6)
INSERT INTO stock_prix (idvariante, idpointure, prix, prix_promo, quantite) VALUES 
(6, 2, 84.99, NULL, 10),   -- 37: 84.99€, 10 en stock
(6, 3, 87.99, 77.99, 8),   -- 38: 87.99€ (promo 77.99), 8 en stock
(6, 4, 90.99, NULL, 6);    -- 39: 90.99€, 6 en stock

-- Variante 7: Puma Suede Noir (idvariante=7)
INSERT INTO stock_prix (idvariante, idpointure, prix, prix_promo, quantite) VALUES 
(7, 4, 79.99, NULL, 14),   -- 39: 79.99€, 14 en stock
(7, 5, 82.99, 74.99, 11),  -- 40: 82.99€ (promo 74.99), 11 en stock
(7, 6, 85.99, NULL, 9);    -- 41: 85.99€, 9 en stock

-- Variante 8: Puma Suede Jaune (idvariante=8)
INSERT INTO stock_prix (idvariante, idpointure, prix, prix_promo, quantite) VALUES 
(8, 3, 81.99, NULL, 9),    -- 38: 81.99€, 9 en stock
(8, 4, 84.99, NULL, 7),    -- 39: 84.99€, 7 en stock
(8, 5, 87.99, 79.99, 5);   -- 40: 87.99€ (promo 79.99), 5 en stock

-- Variante 9: Puma Suede Rose (idvariante=9)
INSERT INTO stock_prix (idvariante, idpointure, prix, prix_promo, quantite) VALUES 
(9, 1, 86.99, NULL, 8),    -- 36: 86.99€, 8 en stock
(9, 2, 89.99, 81.99, 6),   -- 37: 89.99€ (promo 81.99), 6 en stock
(9, 3, 92.99, NULL, 4);    -- 38: 92.99€, 4 en stock

-- Variante 10: NB 574 Gris (idvariante=10)
INSERT INTO stock_prix (idvariante, idpointure, prix, prix_promo, quantite) VALUES 
(10, 5, 109.99, 99.99, 12), -- 40: 109.99€ (promo 99.99), 12 en stock
(10, 6, 112.99, NULL, 10),  -- 41: 112.99€, 10 en stock
(10, 7, 115.99, NULL, 8);   -- 42: 115.99€, 8 en stock

-- Variante 11: NB 574 Blanc (idvariante=11)
INSERT INTO stock_prix (idvariante, idpointure, prix, prix_promo, quantite) VALUES 
(11, 4, 114.99, NULL, 9),   -- 39: 114.99€, 9 en stock
(11, 5, 117.99, 107.99, 7), -- 40: 117.99€ (promo 107.99), 7 en stock
(11, 6, 120.99, NULL, 5);   -- 41: 120.99€, 5 en stock

-- Variante 12: NB 574 Bleu (idvariante=12)
INSERT INTO stock_prix (idvariante, idpointure, prix, prix_promo, quantite) VALUES 
(12, 5, 104.99, NULL, 11),  -- 40: 104.99€, 11 en stock
(12, 6, 107.99, 97.99, 9),  -- 41: 107.99€ (promo 97.99), 9 en stock
(12, 7, 110.99, NULL, 7);   -- 42: 110.99€, 7 en stock

-- Variante 13: Converse Blanc (idvariante=13)
INSERT INTO stock_prix (idvariante, idpointure, prix, prix_promo, quantite) VALUES 
(13, 4, 69.99, 59.99, 15),  -- 39: 69.99€ (promo 59.99), 15 en stock
(13, 5, 72.99, NULL, 12),   -- 40: 72.99€, 12 en stock
(13, 6, 75.99, NULL, 10);   -- 41: 75.99€, 10 en stock

-- Variante 14: Converse Rouge (idvariante=14)
INSERT INTO stock_prix (idvariante, idpointure, prix, prix_promo, quantite) VALUES 
(14, 3, 74.99, NULL, 13),   -- 38: 74.99€, 13 en stock
(14, 4, 77.99, 69.99, 10),  -- 39: 77.99€ (promo 69.99), 10 en stock
(14, 5, 80.99, NULL, 8);    -- 40: 80.99€, 8 en stock

-- Variante 15: Converse Noir (idvariante=15)
INSERT INTO stock_prix (idvariante, idpointure, prix, prix_promo, quantite) VALUES 
(15, 4, 71.99, NULL, 11),   -- 39: 71.99€, 11 en stock
(15, 5, 74.99, 66.99, 9),   -- 40: 74.99€ (promo 66.99), 9 en stock
(15, 6, 77.99, NULL, 7);    -- 41: 77.99€, 7 en stock

-- Variante 16: Converse Bleu (idvariante=16)
INSERT INTO stock_prix (idvariante, idpointure, prix, prix_promo, quantite) VALUES 
(16, 2, 49.99, NULL, 20),   -- 37: 49.99€, 20 en stock (enfant)
(16, 3, 52.99, 47.99, 18),  -- 38: 52.99€ (promo 47.99), 18 en stock
(16, 4, 55.99, NULL, 15);   -- 39: 55.99€, 15 en stock

-- Variante 17: Converse Enfant Jaune (idvariante=17)
INSERT INTO stock_prix (idvariante, idpointure, prix, prix_promo, quantite) VALUES 
(17, 1, 47.99, NULL, 22),   -- 36: 47.99€, 22 en stock
(17, 2, 50.99, 45.99, 19),  -- 37: 50.99€ (promo 45.99), 19 en stock
(17, 3, 53.99, NULL, 16);   -- 38: 53.99€, 16 en stock

-- Variante 18: Nike AF1 Bleu (idvariante=18) - EXEMPLE DE TON CAS
INSERT INTO stock_prix (idvariante, idpointure, prix, prix_promo, quantite) VALUES 
(18, 2, 12.00, NULL, 15),   -- 37: 12€, 15 en stock
(18, 3, 15.00, 13.50, 12),  -- 38: 15€ (promo 13.50), 12 en stock
(18, 4, 14.00, NULL, 10);   -- 39: 14€, 10 en stock

-- Variante 19: Adidas Stan Rouge (idvariante=19) - EXEMPLE DE TON CAS
INSERT INTO stock_prix (idvariante, idpointure, prix, prix_promo, quantite) VALUES 
(19, 1, 30.00, NULL, 8),    -- 36: 30€, 8 en stock
(19, 5, 45.00, 40.00, 6),   -- 40: 45€ (promo 40.00), 6 en stock
(19, 6, 48.00, NULL, 4);    -- 41: 48€, 4 en stock



--Variante sans prix

-- 1. D'abord vérifier précisément ce qui manque
SELECT 
    'Produit ' || p.id || ' - ' || p.reference || 
    ' (Variante ' || v.id || ' - ' || c.nom || ')' as details,
    (SELECT COUNT(*) FROM stock_prix sp WHERE sp.idvariante = v.id) as nb_stocks
FROM variante v
JOIN produit p ON v.idproduit = p.id
JOIN couleur c ON v.idcouleur = c.id
WHERE NOT EXISTS (
    SELECT 1 FROM stock_prix sp WHERE sp.idvariante = v.id
)
ORDER BY p.id, v.id;

-- 2. Ajouter des stock_prix pour les variantes manquantes
-- Pour chaque variante, ajouter 3 pointures standards
DO $$ 
DECLARE
    variante_record RECORD;
    pointure_id INTEGER;
    base_prix DECIMAL;
    i INTEGER;
BEGIN
    FOR variante_record IN 
        SELECT v.id, p.id as produit_id, m.nom as marque
        FROM variante v
        JOIN produit p ON v.idproduit = p.id
        JOIN modele m2 ON p.idmodele = m2.id
        JOIN marque m ON m2.idmarque = m.id
        WHERE NOT EXISTS (
            SELECT 1 FROM stock_prix sp WHERE sp.idvariante = v.id
        )
        ORDER BY p.id, v.id
    LOOP
        -- Déterminer le prix selon la marque
        CASE 
            WHEN variante_record.marque = 'Nike' THEN base_prix := 99.99;
            WHEN variante_record.marque = 'Adidas' THEN base_prix := 89.99;
            WHEN variante_record.marque = 'Puma' THEN base_prix := 79.99;
            WHEN variante_record.marque = 'New Balance' THEN base_prix := 109.99;
            WHEN variante_record.marque = 'Converse' THEN base_prix := 69.99;
            ELSE base_prix := 89.99;
        END CASE;
        
        -- Ajouter 3 pointures (38, 39, 40)
        FOR i IN 1..3 LOOP
            pointure_id := i + 2;  -- 3=38, 4=39, 5=40
            
            INSERT INTO stock_prix (idvariante, idpointure, prix, quantite)
            VALUES (
                variante_record.id,
                pointure_id,
                base_prix + (i-1) * 5.00,  -- Augmente de 5€ par pointure
                FLOOR(RANDOM() * 15) + 5   -- Quantité aléatoire 5-20
            );
        END LOOP;
        
        RAISE NOTICE 'Ajouté stocks pour variante % (produit %, marque %)', 
            variante_record.id, variante_record.produit_id, variante_record.marque;
    END LOOP;
END $$;

-- 3. Vérifier le résultat
SELECT 
    p.reference,
    m.nom as marque,
    COUNT(DISTINCT v.id) as nb_variantes,
    COUNT(sp.id) as nb_stocks,
    MIN(sp.prix) as prix_min,
    MAX(sp.prix) as prix_max,
    SUM(sp.quantite) as stock_total
FROM produit p
JOIN modele m2 ON p.idmodele = m2.id
JOIN marque m ON m2.idmarque = m.id
LEFT JOIN variante v ON p.id = v.idproduit
LEFT JOIN stock_prix sp ON v.id = sp.idvariante
GROUP BY p.id, p.reference, m.nom
ORDER BY p.id;





UPDATE produit
SET nom = 'Nike Air Force 1 ''07'
WHERE id = 1; 

UPDATE produit 
SET images = '["airforce1.png"]'::jsonb
WHERE id = 1;



UPDATE produit
SET nom = 'Nike Air Max 90'
WHERE id = 2; 

UPDATE produit 
SET images = '["NikeAirMax90.png"]'::jsonb
WHERE id = 2;



UPDATE produit
SET nom = 'Nike Dunk Low Retro'
WHERE id = 3; 

UPDATE produit 
SET images = '["NikeDunkLowRetro.png"]'::jsonb
WHERE id = 3;



UPDATE produit
SET nom = 'Adidas Samba'
WHERE id = 4; 

UPDATE produit 
SET images = '["AdidasSamba.png"]'::jsonb
WHERE id = 4;



UPDATE produit
SET nom = 'Adidas Gazelle'
WHERE id = 5; 

UPDATE produit 
SET images = '["AdidasGazelle.png"]'::jsonb
WHERE id = 5;



UPDATE produit
SET nom = 'Adidas Ultraboost 1.0 DNA'
WHERE id = 6; 

UPDATE produit 
SET images = '["AdidasUltraboost1.0DNA.png"]'::jsonb
WHERE id = 6;



UPDATE produit
SET nom = 'Puma Suede Classic'
WHERE id = 7; 

UPDATE produit 
SET images = '["PumaSuedeClassic.png"]'::jsonb
WHERE id = 7;



UPDATE produit
SET nom = 'Puma Clyde'
WHERE id = 8; 

UPDATE produit 
SET images = '["PumaClyde.png"]'::jsonb
WHERE id = 8;



UPDATE produit
SET nom = 'Puma RS-X'
WHERE id = 9; 

UPDATE produit 
SET images = '["PumaRS-X.png"]'::jsonb
WHERE id = 9;



UPDATE produit
SET nom = 'New Balance 574'
WHERE id = 10; 

UPDATE produit 
SET images = '["NewBalance574.png"]'::jsonb
WHERE id = 10;



UPDATE produit
SET nom = 'New Balance 990v6'
WHERE id = 11; 

UPDATE produit 
SET images = '["NewBalance990v6.png"]'::jsonb
WHERE id = 11;



UPDATE produit
SET nom = 'New Balance 550'
WHERE id = 12; 

UPDATE produit 
SET images = '["NewBalance550.png"]'::jsonb
WHERE id = 12;



UPDATE produit
SET nom = 'Converse Run Star Motion'
WHERE id = 13; 

UPDATE produit 
SET images = '["ConverseRunStarMotion.png"]'::jsonb
WHERE id = 13;



UPDATE produit
SET nom = 'Converse Chuck Taylor All Star High'
WHERE id = 14; 

UPDATE produit 
SET images = '["ConverseChuckTaylorAllStarHigh.png"]'::jsonb
WHERE id = 14;



UPDATE produit
SET nom = 'Converse Jack Purcell'
WHERE id = 15; 

UPDATE produit 
SET images = '["ConverseJackPurcell.png"]'::jsonb
WHERE id = 15;


INSERT INTO parametre_remise (quantite_min, quantite_max, pourcentage_remise, est_actif) 
VALUES  
(2, NULL, 10.00, true);