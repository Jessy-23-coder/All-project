// panier.js - version complète
class PanierManager {
    constructor() {
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.renderAllOptions();
        this.checkExistingSelections();
    }
    
    bindEvents() {
        // Boutons quantité
        document.querySelectorAll('.qty-btn.minus').forEach(btn => {
            btn.addEventListener('click', (e) => this.changeQuantity(e.target, -1));
        });
        
        document.querySelectorAll('.qty-btn.plus').forEach(btn => {
            btn.addEventListener('click', (e) => this.changeQuantity(e.target, 1));
        });
        
        // Validation de la quantité
        document.querySelectorAll('.quantity-input').forEach(input => {
            input.addEventListener('change', (e) => this.validateQuantity(e.target));
            input.addEventListener('input', (e) => this.validateQuantity(e.target));
        });
        
        // Bouton procéder au paiement
        const checkoutBtn = document.getElementById('btn-checkout');
        if (checkoutBtn) {
            checkoutBtn.addEventListener('click', (e) => this.proceedToCheckout(e));
        }
        
        // Soumission automatique du formulaire quantité après modification
        document.querySelectorAll('.quantity-input').forEach(input => {
            input.addEventListener('change', () => {
                // Attendre un peu avant de soumettre pour laisser le temps à l'utilisateur
                setTimeout(() => {
                    const form = input.closest('.quantity-form');
                    if (form) {
                        form.submit();
                    }
                }, 500);
            });
        });
        
        // Gestion de l'affichage des images
        this.bindImageEvents();
    }
    
    bindImageEvents() {
        // Si vous avez des miniatures d'images
        document.querySelectorAll('.thumbnail').forEach(thumbnail => {
            thumbnail.addEventListener('click', (e) => {
                this.changeMainImage(e.target);
            });
        });
    }
    
    changeMainImage(thumbnail) {
        const mainImage = thumbnail.closest('.cart-item').querySelector('.item-image');
        if (mainImage && thumbnail.src) {
            mainImage.src = thumbnail.src;
        }
    }
    
    renderAllOptions() {
        const containers = document.querySelectorAll('.options-container');
        console.log("Nombre d'articles avec options:", containers.length);
        
        containers.forEach((container, index) => {
            try {
                const optionsJson = container.getAttribute('data-options');
                const articleId = container.getAttribute('data-article-id');
                
                console.log(`Article ${index + 1} (ID: ${articleId}):`, 
                    "JSON longueur:", optionsJson.length,
                    "Contenu:", optionsJson.substring(0, 100) + "...");
                
                if (!optionsJson || optionsJson === '[]' || optionsJson === '[]]') {
                    container.innerHTML = '<div class="no-options">Pas d\'options disponibles</div>';
                    return;
                }
                
                // Nettoyer le JSON si nécessaire
                let cleanJson = optionsJson;
                if (optionsJson.includes('\\"')) {
                    cleanJson = optionsJson.replace(/\\"/g, '"');
                }
                
                const options = JSON.parse(cleanJson);
                console.log(`Options parsées pour article ${articleId}:`, options.length, "options");
                this.renderOptions(container, options, articleId);
                
            } catch (error) {
                console.error('Erreur parsing JSON pour container', index, ':', error);
                console.error('JSON problématique:', container.getAttribute('data-options'));
                container.innerHTML = `
                    <div class="error-options">
                        <i class="fas fa-exclamation-triangle"></i>
                        Erreur d'affichage des options
                        <button onclick="location.reload()" class="btn-retry">
                            Rafraîchir
                        </button>
                    </div>
                `;
            }
        });
    }
    
    renderOptions(container, options, articleId) {
        if (!options || !Array.isArray(options) || options.length === 0) {
            container.innerHTML = '<div class="no-options">Pas d\'options disponibles</div>';
            return;
        }
        
        // Grouper par couleur
        const couleurs = {};
        const optionsTraitees = new Set();
        
        options.forEach((option, index) => {
            const key = option.couleur_id + '_' + option.pointure_id;
            
            if (!optionsTraitees.has(key)) {
                if (!couleurs[option.couleur_id]) {
                    couleurs[option.couleur_id] = {
                        id: option.couleur_id,
                        nom: option.couleur_nom || 'Non spécifié',
                        code_hex: option.couleur_code || '#cccccc',
                        pointures: []
                    };
                }
                
                couleurs[option.couleur_id].pointures.push({
                    id: option.pointure_id,
                    taille: option.pointure_taille || '?',
                    stock_prix_id: option.stock_prix_id,
                    prix: option.prix || '0.00',
                    stock: option.stock || 0
                });
                
                optionsTraitees.add(key);
            }
        });
        
        // Trier les couleurs par nom
        const couleursSorted = Object.values(couleurs).sort((a, b) => 
            a.nom.localeCompare(b.nom)
        );
        
        if (couleursSorted.length === 0) {
            container.innerHTML = '<div class="no-options">Aucune option valide trouvée</div>';
            return;
        }
        
        let html = '';
        
        couleursSorted.forEach(couleur => {
            // Trier les pointures par taille
            couleur.pointures.sort((a, b) => {
                const aNum = this.parseTaille(a.taille);
                const bNum = this.parseTaille(b.taille);
                return aNum - bNum;
            });
            
            const isWhite = couleur.nom.toLowerCase().includes('blanc') || 
                           couleur.code_hex.toLowerCase() === '#ffffff';
            
            html += `
                <div class="color-group">
                    <div class="color-header">
                        <div class="color-sample" style="background-color: ${couleur.code_hex}; 
                            ${isWhite ? 'border: 1px solid #ddd;' : ''}"></div>
                        <span class="color-name">${couleur.nom}</span>
                    </div>
                    <div class="pointures-list">
            `;
            
            // Afficher les pointures
            couleur.pointures.forEach(pointure => {
                const disponible = pointure.stock > 0;
                const classeDisponible = disponible ? '' : 'out-of-stock';
                const selectedClass = '';
                
                html += `
                    <button type="button" class="pointure-btn ${classeDisponible} ${selectedClass}" 
                            data-article-id="${articleId}"
                            data-couleur-id="${couleur.id}"
                            data-couleur-nom="${couleur.nom}"
                            data-pointure-id="${pointure.id}"
                            data-pointure-taille="${pointure.taille}"
                            data-stock-prix-id="${pointure.stock_prix_id}"
                            data-prix="${pointure.prix}"
                            data-stock="${pointure.stock}"
                            onclick="window.panierManager.selectOption(this)"
                            ${!disponible ? 'disabled' : ''}
                            title="${couleur.nom} - ${pointure.taille} (Stock: ${pointure.stock})">
                        ${pointure.taille}
                        ${!disponible ? '<span class="stock-badge">Épuisé</span>' : ''}
                    </button>
                `;
            });
            
            html += `
                    </div>
                </div>
            `;
        });
        
        container.innerHTML = html;
        console.log(`Options rendues pour article ${articleId}: ${couleursSorted.length} couleurs`);
    }
    
    parseTaille(taille) {
        if (!taille) return 0;
        const clean = taille.toString().replace(',', '.').replace(/[^0-9.]/g, '');
        return parseFloat(clean) || 0;
    }
    
    checkExistingSelections() {
        // Vérifier s'il y a déjà des sélections dans les données du panier
        if (window.panierData && window.panierData.articles) {
            window.panierData.articles.forEach(article => {
                if (article.couleur && article.pointure) {
                    // Trouver le bouton correspondant et le marquer comme sélectionné
                    const buttons = document.querySelectorAll(`.pointure-btn[data-article-id="${article.id}"]`);
                    buttons.forEach(button => {
                        const buttonCouleur = button.getAttribute('data-couleur-nom');
                        const buttonPointure = button.getAttribute('data-pointure-taille');
                        
                        if (buttonCouleur === article.couleur && buttonPointure === article.pointure) {
                            button.classList.add('selected');
                            this.updateSelectionDisplay(
                                article.id,
                                article.couleur,
                                article.pointure,
                                button.getAttribute('data-prix')
                            );
                        }
                    });
                }
            });
        }
    }
    
    selectOption(button) {
        const articleId = button.getAttribute('data-article-id');
        const couleurId = button.getAttribute('data-couleur-id');
        const couleurNom = button.getAttribute('data-couleur-nom');
        const pointureId = button.getAttribute('data-pointure-id');
        const pointureTaille = button.getAttribute('data-pointure-taille');
        const stockPrixId = button.getAttribute('data-stock-prix-id');
        const prix = button.getAttribute('data-prix');
        const stock = parseInt(button.getAttribute('data-stock'));
        
        if (stock <= 0) {
            this.showNotification('Cette option est épuisée', 'error');
            return;
        }
        
        // Mettre à jour visuellement
        const container = button.closest('.options-container');
        container.querySelectorAll('.pointure-btn').forEach(btn => {
            btn.classList.remove('selected');
        });
        button.classList.add('selected');
        
        // Mettre à jour l'affichage
        this.updateSelectionDisplay(articleId, couleurNom, pointureTaille, prix);
        
        // Envoyer la sélection au serveur
        this.saveSelection(articleId, couleurId, pointureId, stockPrixId);
    }
    
    updateSelectionDisplay(articleId, couleurNom, pointureTaille, prix) {
        const itemElement = document.querySelector(`.cart-item[data-article-id="${articleId}"]`);
        if (!itemElement) return;
        
        // Mettre à jour la section "Sélection"
        const detailsDiv = itemElement.querySelector('.item-details');
        let selectionSpan = detailsDiv.querySelector('.selection-display');
        
        if (!selectionSpan) {
            // Créer l'élément s'il n'existe pas
            selectionSpan = document.createElement('span');
            selectionSpan.className = 'selection-display';
            detailsDiv.appendChild(selectionSpan);
        }
        
        selectionSpan.innerHTML = `<strong>Sélection:</strong> ${couleurNom} - ${pointureTaille}`;
        
        // Mettre à jour le prix unitaire affiché
        const prixElements = itemElement.querySelectorAll('.item-price-detail span');
        if (prixElements.length > 0) {
            prixElements[0].innerHTML = `<strong>Prix unitaire:</strong> ${prix} €`;
        }
        
        // Mettre à jour le prix total
        const quantiteInput = itemElement.querySelector('.quantity-input');
        if (quantiteInput) {
            const quantite = parseInt(quantiteInput.value) || 1;
            const total = (parseFloat(prix) * quantite).toFixed(2);
            const totalElement = itemElement.querySelector('.item-price');
            if (totalElement) {
                totalElement.textContent = total + ' €';
            }
        }
    }
    
    saveSelection(articleId, couleurId, pointureId, stockPrixId) {
        // Créer un formulaire caché pour envoyer la sélection
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = 'panier.jsp';
        form.style.display = 'none';
        
        const fields = {
            articleId: articleId,
            couleurId: couleurId,
            pointureId: pointureId,
            stockPrixId: stockPrixId,
            action: 'choisir'
        };
        
        Object.entries(fields).forEach(([name, value]) => {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = name;
            input.value = value;
            form.appendChild(input);
        });
        
        document.body.appendChild(form);
        this.showNotification('Sélection enregistrée...', 'info');
        form.submit();
    }
    
    changeQuantity(button, delta) {
        const inputGroup = button.closest('.quantity-input-group');
        const input = inputGroup.querySelector('.quantity-input');
        
        let value = parseInt(input.value) || 1;
        const max = parseInt(input.max) || 10;
        const min = parseInt(input.min) || 1;
        
        value += delta;
        
        if (value < min) value = min;
        if (value > max) value = max;
        
        input.value = value;
        
        // Mettre à jour le prix total si une sélection existe
        this.updateItemPriceFromQuantity(input);
    }
    
    updateItemPriceFromQuantity(input) {
        const itemElement = input.closest('.cart-item');
        const selectedOption = itemElement.querySelector('.pointure-btn.selected');
        
        if (selectedOption) {
            const prix = parseFloat(selectedOption.getAttribute('data-prix'));
            const quantite = parseInt(input.value);
            const total = (prix * quantite).toFixed(2);
            
            const totalElement = itemElement.querySelector('.item-price');
            if (totalElement) {
                totalElement.textContent = total + ' €';
            }
        }
    }
    
    validateQuantity(input) {
        let value = parseInt(input.value) || 1;
        const max = parseInt(input.max) || 10;
        const min = parseInt(input.min) || 1;
        
        if (value < min) value = min;
        if (value > max) value = max;
        
        input.value = value;
        
        // Mettre à jour le prix
        this.updateItemPriceFromQuantity(input);
        
        // Vérifier le stock si une option est sélectionnée
        const itemElement = input.closest('.cart-item');
        const selectedOption = itemElement.querySelector('.pointure-btn.selected');
        
        if (selectedOption) {
            const stock = parseInt(selectedOption.getAttribute('data-stock'));
            if (value > stock) {
                this.showNotification(`Stock insuffisant. Maximum disponible: ${stock}`, 'warning');
                input.value = stock;
            }
        }
    }
    
    proceedToCheckout(e) {
        e.preventDefault();
        
        // Vérifier que toutes les sélections sont faites
        const missingSelections = [];
        const stockIssues = [];
        
        document.querySelectorAll('.cart-item').forEach(item => {
            const articleId = item.getAttribute('data-article-id');
            const selectedOption = item.querySelector('.pointure-btn.selected');
            const quantiteInput = item.querySelector('.quantity-input');
            const productName = item.querySelector('.item-name').textContent;
            
            if (!selectedOption) {
                missingSelections.push(productName);
            } else {
                const quantite = parseInt(quantiteInput.value) || 1;
                const stock = parseInt(selectedOption.getAttribute('data-stock'));
                
                if (quantite > stock) {
                    stockIssues.push(`${productName}: ${quantite} demandés, ${stock} disponibles`);
                }
            }
        });
        
        let errorMessage = '';
        
        if (missingSelections.length > 0) {
            errorMessage += `Veuillez sélectionner une option pour :<br>${missingSelections.join('<br>')}`;
        }
        
        if (stockIssues.length > 0) {
            if (errorMessage) errorMessage += '<br><br>';
            errorMessage += `Problème de stock :<br>${stockIssues.join('<br>')}`;
        }
        
        if (errorMessage) {
            this.showNotification(errorMessage, 'error');
            return;
        }
        
        // Tout est bon, procéder au paiement
        this.showNotification('Redirection vers la commande...', 'success');
        setTimeout(() => {
            window.location.href = 'commande.jsp';
        }, 1000);
    }
    
    showNotification(message, type = 'info') {
        // Supprimer les notifications existantes
        document.querySelectorAll('.temp-notification').forEach(n => n.remove());
        
        const notification = document.createElement('div');
        notification.className = `temp-notification notification-${type}`;
        
        // Styles CSS
        const styles = {
            position: 'fixed',
            top: '20px',
            right: '20px',
            padding: '15px 20px',
            background: type === 'error' ? '#f8d7da' : 
                       type === 'warning' ? '#fff3cd' : 
                       type === 'success' ? '#d4edda' : '#d1ecf1',
            color: type === 'error' ? '#721c24' : 
                   type === 'warning' ? '#856404' : 
                   type === 'success' ? '#155724' : '#0c5460',
            border: type === 'error' ? '1px solid #f5c6cb' : 
                    type === 'warning' ? '1px solid #ffeaa7' : 
                    type === 'success' ? '1px solid #c3e6cb' : '1px solid #bee5eb',
            borderRadius: '6px',
            zIndex: '10000',
            boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            maxWidth: '500px',
            minWidth: '300px',
            fontSize: '14px',
            animation: 'slideIn 0.3s ease-out'
        };
        
        // Appliquer les styles
        Object.assign(notification.style, styles);
        
        // Icône selon le type
        const icon = type === 'error' ? 'fa-exclamation-circle' : 
                    type === 'warning' ? 'fa-exclamation-triangle' : 
                    type === 'success' ? 'fa-check-circle' : 'fa-info-circle';
        
        notification.innerHTML = `
            <i class="fas ${icon}" style="font-size: 18px;"></i>
            <div>${message}</div>
        `;
        
        document.body.appendChild(notification);
        
        // Supprimer après 5 secondes
        setTimeout(() => {
            notification.style.opacity = '0';
            notification.style.transition = 'opacity 0.5s';
            setTimeout(() => notification.remove(), 500);
        }, 5000);
        
        // Animation CSS
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideIn {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    // Méthode pour vider le panier
    emptyCart() {
        if (confirm('Êtes-vous sûr de vouloir vider tout le panier ?')) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'panier.jsp';
            form.style.display = 'none';
            
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'action';
            input.value = 'vider';
            
            form.appendChild(input);
            document.body.appendChild(form);
            form.submit();
        }
    }
    
    // Méthode pour supprimer un article
    removeArticle(articleId) {
        if (confirm('Supprimer cet article du panier ?')) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'panier.jsp';
            form.style.display = 'none';
            
            const articleIdInput = document.createElement('input');
            articleIdInput.type = 'hidden';
            articleIdInput.name = 'articleId';
            articleIdInput.value = articleId;
            
            const actionInput = document.createElement('input');
            actionInput.type = 'hidden';
            actionInput.name = 'action';
            actionInput.value = 'supprimer';
            
            form.appendChild(articleIdInput);
            form.appendChild(actionInput);
            document.body.appendChild(form);
            form.submit();
        }
    }
}

// Initialiser quand le DOM est chargé
document.addEventListener('DOMContentLoaded', function() {
    console.log("Initialisation du PanierManager...");
    window.panierManager = new PanierManager();
    
    // Exposer les fonctions globales
    window.selectOption = function(button) {
        window.panierManager.selectOption(button);
    };
    
    window.emptyCart = function() {
        window.panierManager.emptyCart();
    };
    
    window.removeArticle = function(articleId) {
        window.panierManager.removeArticle(articleId);
    };
    
    // Gestionnaire d'erreurs global
    window.addEventListener('error', function(e) {
        console.error('Erreur globale:', e.error);
    });
});