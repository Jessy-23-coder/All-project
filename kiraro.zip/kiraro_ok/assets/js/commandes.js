// commandes.js - Gestion des commandes et retours

// Gestion des tabs
document.addEventListener('DOMContentLoaded', function() {
    // Initialiser les tabs
    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', function() {
            // Désactiver toutes les tabs
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.style.display = 'none');
            
            // Activer la tab courante
            this.classList.add('active');
            const tabName = this.dataset.tab;
            document.getElementById(tabName + '-tab').style.display = 'block';
        });
    });
    
    // Initialiser les événements pour les formulaires de retour
    initRetourForms();
});

// Fonctions pour les formulaires de retour
function showRetourForm(articleId, maxQuantite, prixUnitaire) {
    // Cacher tous les formulaires
    document.querySelectorAll('.retour-form').forEach(form => {
        form.classList.remove('active');
    });
    
    // Afficher le formulaire spécifique
    const form = document.getElementById('retour-form-' + articleId);
    if (form) {
        form.classList.add('active');
        form.scrollIntoView({ behavior: 'smooth', block: 'center' });
        
        // Initialiser le montant estimé
        updateRetourMontant(articleId, prixUnitaire);
    }
}

function hideRetourForm(articleId) {
    const form = document.getElementById('retour-form-' + articleId);
    if (form) {
        form.classList.remove('active');
    }
}

// Fonction pour mettre à jour le montant du retour
function updateRetourMontant(articleId, prixUnitaire) {
    const form = document.getElementById('retour-form-' + articleId);
    if (!form) return;
    
    const quantiteSelect = form.querySelector('select[name="quantite"]');
    const montantDisplay = document.getElementById('montant-display-' + articleId);
    
    if (quantiteSelect && montantDisplay) {
        const quantite = parseInt(quantiteSelect.value) || 1;
        const montant = prixUnitaire * quantite;
        montantDisplay.textContent = montant.toFixed(2) + ' €';
    }
}

// Initialiser tous les formulaires de retour
function initRetourForms() {
    document.querySelectorAll('.retour-form').forEach(form => {
        const formId = form.id;
        const articleId = formId.replace('retour-form-', '');
        
        // Trouver le bouton de retour correspondant
        const retourBtn = document.querySelector(`button[onclick*="showRetourForm(${articleId}"]`);
        if (retourBtn) {
            // Extraire le prix unitaire de l'attribut onclick
            const onclickText = retourBtn.getAttribute('onclick');
            const prixMatch = onclickText.match(/showRetourForm\(.*?,\s*.*?,\s*(.*?)\)/);
            
            if (prixMatch) {
                const prixUnitaire = parseFloat(prixMatch[1]) || 0;
                
                // Configurer l'événement sur le sélecteur de quantité
                const quantiteSelect = form.querySelector('select[name="quantite"]');
                if (quantiteSelect) {
                    quantiteSelect.addEventListener('change', function() {
                        updateRetourMontant(articleId, prixUnitaire);
                    });
                }
                
                // Configurer la soumission du formulaire
                const formElement = form.querySelector('form');
                if (formElement) {
                    formElement.addEventListener('submit', function(e) {
                        return validateRetourForm(this, articleId, prixUnitaire);
                    });
                }
            }
        }
    });
}

// Fonction pour valider le formulaire de retour
function validateRetourForm(form, articleId, prixUnitaire) {
    const quantiteInput = form.querySelector('select[name="quantite"]');
    const motifInput = form.querySelector('textarea[name="motif"]');
    
    if (!quantiteInput || !motifInput) {
        alert('Erreur dans le formulaire');
        return false;
    }
    
    const quantite = parseInt(quantiteInput.value);
    const motif = motifInput.value.trim();
    
    if (quantite <= 0) {
        alert('Veuillez sélectionner une quantité valide');
        return false;
    }
    
    if (motif.length === 0) {
        alert('Veuillez indiquer le motif du retour');
        return false;
    }
    
    if (motif.length < 10) {
        alert('Veuillez fournir un motif plus détaillé (au moins 10 caractères)');
        return false;
    }
    
    // Calculer le montant estimé
    const montantEstime = prixUnitaire * quantite;
    
    return confirm('Êtes-vous sûr de vouloir soumettre cette demande de retour ?\n\n' +
                  'Détails :\n' +
                  '• Quantité : ' + quantite + ' article(s)\n' +
                  '• Montant estimé : ' + montantEstime.toFixed(2) + ' €\n' +
                  '• Motif : ' + (motif.length > 50 ? motif.substring(0, 50) + '...' : motif));
}

// Fonction pour afficher/masquer les détails d'un article
function toggleArticleDetails(articleId) {
    const details = document.getElementById('article-details-' + articleId);
    if (details) {
        details.style.display = details.style.display === 'none' ? 'block' : 'none';
    }
}

// Fonction pour exporter la commande en PDF
function exporterCommandePDF(commandeId) {
    if (confirm('Voulez-vous télécharger la facture de cette commande ?')) {
        window.location.href = 'generer_facture.jsp?commandeId=' + commandeId;
    }
}

// Fonction pour partager la commande
function partagerCommande(commandeId) {
    const url = window.location.origin + window.location.pathname + '?commandeId=' + commandeId;
    
    if (navigator.share) {
        // Utiliser l'API Web Share si disponible
        navigator.share({
            title: 'Commande #' + commandeId + ' - ShoesShop',
            text: 'Voir les détails de ma commande sur ShoesShop',
            url: url
        });
    } else {
        // Fallback: copier dans le presse-papier
        navigator.clipboard.writeText(url).then(function() {
            alert('Lien copié dans le presse-papier !');
        }, function() {
            // Fallback pour les anciens navigateurs
            const tempInput = document.createElement('input');
            tempInput.value = url;
            document.body.appendChild(tempInput);
            tempInput.select();
            document.execCommand('copy');
            document.body.removeChild(tempInput);
            alert('Lien copié dans le presse-papier !');
        });
    }
}

// Fonction pour filtrer les commandes
function filtrerCommandes() {
    const filtre = document.getElementById('filtre-statut').value;
    const commandes = document.querySelectorAll('.commande-card');
    
    commandes.forEach(commande => {
        const statut = commande.querySelector('.commande-statut').textContent.toLowerCase();
        
        if (filtre === 'tous' || statut.includes(filtre)) {
            commande.style.display = 'block';
        } else {
            commande.style.display = 'none';
        }
    });
}

// Fonction pour rechercher dans les commandes
function rechercherCommandes() {
    const recherche = document.getElementById('recherche-commandes').value.toLowerCase();
    const commandes = document.querySelectorAll('.commande-card');
    
    commandes.forEach(commande => {
        const texteCommande = commande.textContent.toLowerCase();
        
        if (texteCommande.includes(recherche)) {
            commande.style.display = 'block';
        } else {
            commande.style.display = 'none';
        }
    });
}

// Fonction pour trier les commandes
function trierCommandes(critere) {
    const container = document.querySelector('.commandes-list');
    const commandes = Array.from(container.querySelectorAll('.commande-card'));
    
    commandes.sort((a, b) => {
        let valeurA, valeurB;
        
        switch(critere) {
            case 'date_desc':
                valeurA = new Date(a.querySelector('.date').textContent);
                valeurB = new Date(b.querySelector('.date').textContent);
                return valeurB - valeurA;
                
            case 'date_asc':
                valeurA = new Date(a.querySelector('.date').textContent);
                valeurB = new Date(b.querySelector('.date').textContent);
                return valeurA - valeurB;
                
            case 'montant_desc':
                valeurA = parseFloat(a.querySelector('.commande-total').textContent.replace(/[^0-9.,]/g, '').replace(',', '.'));
                valeurB = parseFloat(b.querySelector('.commande-total').textContent.replace(/[^0-9.,]/g, '').replace(',', '.'));
                return valeurB - valeurA;
                
            case 'montant_asc':
                valeurA = parseFloat(a.querySelector('.commande-total').textContent.replace(/[^0-9.,]/g, '').replace(',', '.'));
                valeurB = parseFloat(b.querySelector('.commande-total').textContent.replace(/[^0-9.,]/g, '').replace(',', '.'));
                return valeurA - valeurB;
                
            default:
                return 0;
        }
    });
    
    // Réorganiser les commandes dans le container
    commandes.forEach(commande => {
        container.appendChild(commande);
    });
}

// Initialiser les tooltips
function initTooltips() {
    const tooltips = document.querySelectorAll('[data-tooltip]');
    
    tooltips.forEach(element => {
        element.addEventListener('mouseenter', function() {
            const tooltipText = this.getAttribute('data-tooltip');
            const tooltip = document.createElement('div');
            tooltip.className = 'tooltip';
            tooltip.textContent = tooltipText;
            
            const rect = this.getBoundingClientRect();
            tooltip.style.position = 'fixed';
            tooltip.style.top = (rect.top - 40) + 'px';
            tooltip.style.left = (rect.left + rect.width / 2) + 'px';
            tooltip.style.transform = 'translateX(-50%)';
            
            document.body.appendChild(tooltip);
            
            this.tooltipElement = tooltip;
        });
        
        element.addEventListener('mouseleave', function() {
            if (this.tooltipElement) {
                this.tooltipElement.remove();
                this.tooltipElement = null;
            }
        });
    });
}

// Gestion des notifications
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        <span>${message}</span>
    `;
    
    const container = document.querySelector('.container') || document.body;
    container.insertBefore(notification, container.firstChild);
    
    // Animation d'entrée
    setTimeout(() => {
        notification.style.opacity = '1';
        notification.style.transform = 'translateY(0)';
    }, 10);
    
    // Supprimer après 5 secondes
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transform = 'translateY(-10px)';
        setTimeout(() => notification.remove(), 300);
    }, 5000);
}

// Exporter les fonctions globalement
window.showRetourForm = showRetourForm;
window.hideRetourForm = hideRetourForm;
window.exporterCommandePDF = exporterCommandePDF;
window.partagerCommande = partagerCommande;
window.filtrerCommandes = filtrerCommandes;
window.rechercherCommandes = rechercherCommandes;
window.trierCommandes = trierCommandes;

// Initialiser quand le DOM est chargé
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initRetourForms);
} else {
    initRetourForms();
}