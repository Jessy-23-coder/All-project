package model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class CommandeArticle {
    private int id;
    private int idCommande;
    private int idProduit;
    private Integer idCouleur;
    private Integer idPointure;
    private int quantite;
    private BigDecimal prixUnitaire;
    private BigDecimal remiseAppliquee;
    private BigDecimal sousTotalBrut;
    private BigDecimal sousTotalNet;
    private LocalDateTime dateAjout;
    
    // Informations supplémentaires pour l'affichage
    private String produitNom;
    private String reference;
    private String images;
    private String marqueNom;
    private String couleurNom;
    private String pointureTaille;
    private int quantiteRetournee;
    private BigDecimal montantRembourse;
    
    // Constructeurs
    public CommandeArticle() {}
    
    public CommandeArticle(int idCommande, int idProduit, int quantite, 
                          BigDecimal prixUnitaire, BigDecimal remiseAppliquee) {
        this.idCommande = idCommande;
        this.idProduit = idProduit;
        this.quantite = quantite;
        this.prixUnitaire = prixUnitaire;
        this.remiseAppliquee = remiseAppliquee;
        this.sousTotalBrut = prixUnitaire.multiply(BigDecimal.valueOf(quantite));
        BigDecimal montantRemise = this.sousTotalBrut.multiply(remiseAppliquee).divide(new BigDecimal(100));
        this.sousTotalNet = this.sousTotalBrut.subtract(montantRemise);
        this.dateAjout = LocalDateTime.now();
    }
    
    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getIdCommande() { return idCommande; }
    public void setIdCommande(int idCommande) { this.idCommande = idCommande; }
    
    public int getIdProduit() { return idProduit; }
    public void setIdProduit(int idProduit) { this.idProduit = idProduit; }
    
    public Integer getIdCouleur() { return idCouleur; }
    public void setIdCouleur(Integer idCouleur) { this.idCouleur = idCouleur; }
    
    public Integer getIdPointure() { return idPointure; }
    public void setIdPointure(Integer idPointure) { this.idPointure = idPointure; }
    
    public int getQuantite() { return quantite; }
    public void setQuantite(int quantite) { this.quantite = quantite; }
    
    public BigDecimal getPrixUnitaire() { return prixUnitaire; }
    public void setPrixUnitaire(BigDecimal prixUnitaire) { this.prixUnitaire = prixUnitaire; }
    
    public BigDecimal getRemiseAppliquee() { return remiseAppliquee; }
    public void setRemiseAppliquee(BigDecimal remiseAppliquee) { this.remiseAppliquee = remiseAppliquee; }
    
    public BigDecimal getSousTotalBrut() { return sousTotalBrut; }
    public void setSousTotalBrut(BigDecimal sousTotalBrut) { this.sousTotalBrut = sousTotalBrut; }
    
    public BigDecimal getSousTotalNet() { return sousTotalNet; }
    public void setSousTotalNet(BigDecimal sousTotalNet) { this.sousTotalNet = sousTotalNet; }
    
    public LocalDateTime getDateAjout() { return dateAjout; }
    public void setDateAjout(LocalDateTime dateAjout) { this.dateAjout = dateAjout; }
    
    public String getProduitNom() { return produitNom; }
    public void setProduitNom(String produitNom) { this.produitNom = produitNom; }
    
    public String getReference() { return reference; }
    public void setReference(String reference) { this.reference = reference; }
    
    public String getImages() { return images; }
    public void setImages(String images) { this.images = images; }
    
    public String getMarqueNom() { return marqueNom; }
    public void setMarqueNom(String marqueNom) { this.marqueNom = marqueNom; }
    
    public String getCouleurNom() { return couleurNom; }
    public void setCouleurNom(String couleurNom) { this.couleurNom = couleurNom; }
    
    public String getPointureTaille() { return pointureTaille; }
    public void setPointureTaille(String pointureTaille) { this.pointureTaille = pointureTaille; }
    
    public int getQuantiteRetournee() { return quantiteRetournee; }
    public void setQuantiteRetournee(int quantiteRetournee) { this.quantiteRetournee = quantiteRetournee; }
    
    public BigDecimal getMontantRembourse() { return montantRembourse; }
    public void setMontantRembourse(BigDecimal montantRembourse) { this.montantRembourse = montantRembourse; }
    
    // Méthode utilitaire
    public int getQuantiteRestante() {
        return this.quantite - this.quantiteRetournee;
    }
}