// model/Panier.java
package model;

import java.sql.Timestamp;
import java.util.List;

public class Panier {
    private int id;
    private int idUtilisateur;
    private Timestamp dateCreation;
    private Timestamp dateModification;
    private List<PanierArticle> articles;
    
    // Constructeurs
    public Panier() {}
    
    public Panier(int idUtilisateur) {
        this.idUtilisateur = idUtilisateur;
    }
    
    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getIdUtilisateur() { return idUtilisateur; }
    public void setIdUtilisateur(int idUtilisateur) { this.idUtilisateur = idUtilisateur; }
    
    public Timestamp getDateCreation() { return dateCreation; }
    public void setDateCreation(Timestamp dateCreation) { this.dateCreation = dateCreation; }
    
    public Timestamp getDateModification() { return dateModification; }
    public void setDateModification(Timestamp dateModification) { this.dateModification = dateModification; }
    
    public List<PanierArticle> getArticles() { return articles; }
    public void setArticles(List<PanierArticle> articles) { this.articles = articles; }
    
   
}