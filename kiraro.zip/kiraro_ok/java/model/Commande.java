package model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class Commande {
    private int id;
    private int idUtilisateur;
    private int idPanier;
    private LocalDateTime dateCommande;
    private String statut;
    private BigDecimal totalAvantRemise;
    private BigDecimal totalRemise;
    private BigDecimal totalFinal;
    private String adresseLivraison;
    private String methodePaiement;
    
    // Constructeurs
    public Commande() {}
    
    public Commande(int idUtilisateur, int idPanier, BigDecimal totalAvantRemise, 
                   BigDecimal totalRemise, BigDecimal totalFinal) {
        this.idUtilisateur = idUtilisateur;
        this.idPanier = idPanier;
        this.totalAvantRemise = totalAvantRemise;
        this.totalRemise = totalRemise;
        this.totalFinal = totalFinal;
        this.statut = "validée";
        this.dateCommande = LocalDateTime.now();
    }
    
    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getIdUtilisateur() { return idUtilisateur; }
    public void setIdUtilisateur(int idUtilisateur) { this.idUtilisateur = idUtilisateur; }
    
    public int getIdPanier() { return idPanier; }
    public void setIdPanier(int idPanier) { this.idPanier = idPanier; }
    
    public LocalDateTime getDateCommande() { return dateCommande; }
    public void setDateCommande(LocalDateTime dateCommande) { this.dateCommande = dateCommande; }
    
    public String getStatut() { return statut; }
    public void setStatut(String statut) { this.statut = statut; }
    
    public BigDecimal getTotalAvantRemise() { return totalAvantRemise; }
    public void setTotalAvantRemise(BigDecimal totalAvantRemise) { this.totalAvantRemise = totalAvantRemise; }
    
    public BigDecimal getTotalRemise() { return totalRemise; }
    public void setTotalRemise(BigDecimal totalRemise) { this.totalRemise = totalRemise; }
    
    public BigDecimal getTotalFinal() { return totalFinal; }
    public void setTotalFinal(BigDecimal totalFinal) { this.totalFinal = totalFinal; }
    
    public String getAdresseLivraison() { return adresseLivraison; }
    public void setAdresseLivraison(String adresseLivraison) { this.adresseLivraison = adresseLivraison; }
    
    public String getMethodePaiement() { return methodePaiement; }
    public void setMethodePaiement(String methodePaiement) { this.methodePaiement = methodePaiement; }
}