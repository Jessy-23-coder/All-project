package model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class RetourArticle {
    private int id;
    private int idCommandeArticle;
    private int quantiteRetournee;
    private String motif;
    private String statut;
    private LocalDateTime dateDemande;
    private LocalDateTime dateTraitement;
    private BigDecimal montantRembourse;
    private String commentaireAdmin;
    
    // Informations supplémentaires
    private String produitNom;
    private String reference;
    private BigDecimal prixUnitaire;
    private BigDecimal remiseAppliquee;
    
    // Constructeurs
    public RetourArticle() {}
    
    public RetourArticle(int idCommandeArticle, int quantiteRetournee, String motif) {
        this.idCommandeArticle = idCommandeArticle;
        this.quantiteRetournee = quantiteRetournee;
        this.motif = motif;
        this.statut = "en_attente";
        this.dateDemande = LocalDateTime.now();
    }
    
    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getIdCommandeArticle() { return idCommandeArticle; }
    public void setIdCommandeArticle(int idCommandeArticle) { this.idCommandeArticle = idCommandeArticle; }
    
    public int getQuantiteRetournee() { return quantiteRetournee; }
    public void setQuantiteRetournee(int quantiteRetournee) { this.quantiteRetournee = quantiteRetournee; }
    
    public String getMotif() { return motif; }
    public void setMotif(String motif) { this.motif = motif; }
    
    public String getStatut() { return statut; }
    public void setStatut(String statut) { this.statut = statut; }
    
    public LocalDateTime getDateDemande() { return dateDemande; }
    public void setDateDemande(LocalDateTime dateDemande) { this.dateDemande = dateDemande; }
    
    public LocalDateTime getDateTraitement() { return dateTraitement; }
    public void setDateTraitement(LocalDateTime dateTraitement) { this.dateTraitement = dateTraitement; }
    
    public BigDecimal getMontantRembourse() { return montantRembourse; }
    public void setMontantRembourse(BigDecimal montantRembourse) { this.montantRembourse = montantRembourse; }
    
    public String getCommentaireAdmin() { return commentaireAdmin; }
    public void setCommentaireAdmin(String commentaireAdmin) { this.commentaireAdmin = commentaireAdmin; }
    
    public String getProduitNom() { return produitNom; }
    public void setProduitNom(String produitNom) { this.produitNom = produitNom; }
    
    public String getReference() { return reference; }
    public void setReference(String reference) { this.reference = reference; }
    
    public BigDecimal getPrixUnitaire() { return prixUnitaire; }
    public void setPrixUnitaire(BigDecimal prixUnitaire) { this.prixUnitaire = prixUnitaire; }
    
    public BigDecimal getRemiseAppliquee() { return remiseAppliquee; }
    public void setRemiseAppliquee(BigDecimal remiseAppliquee) { this.remiseAppliquee = remiseAppliquee; }
}