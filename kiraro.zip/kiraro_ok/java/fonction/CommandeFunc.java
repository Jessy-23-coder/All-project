package fonction;

import model.Commande;
import model.CommandeArticle;
import model.PanierArticle;
import java.sql.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import connexion.Connexion;

public class CommandeFunc {
    
    private Connection connect() throws Exception {
        Connection conn;
        conn = Connexion.getPostgresCon();
        return conn;
    }
    
    // Valider le panier et créer une commande
    public int validerPanier(int idUtilisateur, int idPanier, String adresse, String methodePaiement) throws Exception {
        Connection conn = null;
        PreparedStatement pstmtCommande = null;
        PreparedStatement pstmtArticle = null;
        PreparedStatement pstmtSelect = null;
        ResultSet rs = null;
        
        try {
            conn = connect();
            conn.setAutoCommit(false);
            
            // 1. Calculer les totaux du panier
            BigDecimal totalAvantRemise = BigDecimal.ZERO;
            BigDecimal totalRemise = BigDecimal.ZERO;
            BigDecimal totalFinal = BigDecimal.ZERO;
            
            String sqlSelect = "SELECT sous_total_brut, montant_remise, sous_total_net " +
                              "FROM vue_panier_detail WHERE idpanier = ?";
            pstmtSelect = conn.prepareStatement(sqlSelect);
            pstmtSelect.setInt(1, idPanier);
            rs = pstmtSelect.executeQuery();
            
            while (rs.next()) {
                totalAvantRemise = totalAvantRemise.add(rs.getBigDecimal("sous_total_brut"));
                totalRemise = totalRemise.add(rs.getBigDecimal("montant_remise"));
                totalFinal = totalFinal.add(rs.getBigDecimal("sous_total_net"));
            }
            
            // 2. Créer la commande
            String sqlCommande = "INSERT INTO commande (idutilisateur, idpanier, total_avant_remise, " +
                                "total_remise, total_final, adresse_livraison, methode_paiement) " +
                                "VALUES (?, ?, ?, ?, ?, ?, ?) RETURNING id";
            pstmtCommande = conn.prepareStatement(sqlCommande);
            pstmtCommande.setInt(1, idUtilisateur);
            pstmtCommande.setInt(2, idPanier);
            pstmtCommande.setBigDecimal(3, totalAvantRemise);
            pstmtCommande.setBigDecimal(4, totalRemise);
            pstmtCommande.setBigDecimal(5, totalFinal);
            pstmtCommande.setString(6, adresse);
            pstmtCommande.setString(7, methodePaiement);
            
            rs = pstmtCommande.executeQuery();
            int idCommande = 0;
            if (rs.next()) {
                idCommande = rs.getInt(1);
            }
            
            // 3. Copier les articles du panier dans commande_article
            String sqlArticles = "INSERT INTO commande_article (idcommande, idproduit, idcouleur, " +
                               "idpointure, quantite, prix_unitaire, remise_appliquee, " +
                               "sous_total_brut, sous_total_net) " +
                               "SELECT ?, id_produit, idcouleur_selectionnee, idpointure_selectionnee, " +
                               "quantite, prix_unitaire, remise_appliquee, sous_total_brut, sous_total_net " +
                               "FROM vue_panier_detail WHERE idpanier = ?";
            pstmtArticle = conn.prepareStatement(sqlArticles);
            pstmtArticle.setInt(1, idCommande);
            pstmtArticle.setInt(2, idPanier);
            pstmtArticle.executeUpdate();
            
            // 4. Vider le panier
            String sqlVider = "DELETE FROM panier_article WHERE idpanier = ?";
            try (PreparedStatement pstmtVider = conn.prepareStatement(sqlVider)) {
                pstmtVider.setInt(1, idPanier);
                pstmtVider.executeUpdate();
            }
            
            conn.commit();
            return idCommande;
            
        } catch (SQLException e) {
            if (conn != null) {
                conn.rollback();
            }
            throw e;
        } finally {
            if (rs != null) rs.close();
            if (pstmtSelect != null) pstmtSelect.close();
            if (pstmtArticle != null) pstmtArticle.close();
            if (pstmtCommande != null) pstmtCommande.close();
            if (conn != null) conn.close();
        }
    }
    
    // Récupérer les commandes d'un utilisateur
    public List<Commande> getCommandesUtilisateur(int idUtilisateur) throws Exception {
        List<Commande> commandes = new ArrayList<>();
        String sql = "SELECT * FROM commande WHERE idutilisateur = ? ORDER BY date_commande DESC";
        
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idUtilisateur);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Commande commande = new Commande();
                    commande.setId(rs.getInt("id"));
                    commande.setIdUtilisateur(rs.getInt("idutilisateur"));
                    commande.setIdPanier(rs.getInt("idpanier"));
                    commande.setDateCommande(rs.getTimestamp("date_commande").toLocalDateTime());
                    commande.setStatut(rs.getString("statut"));
                    commande.setTotalAvantRemise(rs.getBigDecimal("total_avant_remise"));
                    commande.setTotalRemise(rs.getBigDecimal("total_remise"));
                    commande.setTotalFinal(rs.getBigDecimal("total_final"));
                    commande.setAdresseLivraison(rs.getString("adresse_livraison"));
                    commande.setMethodePaiement(rs.getString("methode_paiement"));
                    commandes.add(commande);
                }
            }
        }
        return commandes;
    }
    
    // Récupérer les articles d'une commande avec détails
    public List<CommandeArticle> getArticlesCommande(int idCommande) throws Exception {
        List<CommandeArticle> articles = new ArrayList<>();
        String sql = "SELECT * FROM vue_commande_detail WHERE commande_id = ?";
        
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idCommande);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    CommandeArticle article = new CommandeArticle();
                    article.setId(rs.getInt("article_id"));
                    article.setIdCommande(rs.getInt("commande_id"));
                    article.setIdProduit(rs.getInt("idproduit"));
                    article.setIdCouleur(rs.getInt("idcouleur"));
                    article.setIdPointure(rs.getInt("idpointure"));
                    article.setQuantite(rs.getInt("quantite"));
                    article.setPrixUnitaire(rs.getBigDecimal("prix_unitaire"));
                    article.setRemiseAppliquee(rs.getBigDecimal("remise_appliquee"));
                    article.setSousTotalBrut(rs.getBigDecimal("sous_total_brut"));
                    article.setSousTotalNet(rs.getBigDecimal("sous_total_net"));
                    
                    article.setProduitNom(rs.getString("produit_nom"));
                    article.setReference(rs.getString("reference"));
                    article.setImages(rs.getString("images"));
                    article.setMarqueNom(rs.getString("marque_nom"));
                    article.setCouleurNom(rs.getString("couleur_nom"));
                    article.setPointureTaille(rs.getString("pointure_taille"));
                    article.setQuantiteRetournee(rs.getInt("quantite_retournee_approuvee"));
                    article.setMontantRembourse(rs.getBigDecimal("montant_rembourse_total"));
                    
                    articles.add(article);
                }
            }
        }
        return articles;
    }
    
    // Récupérer une commande par ID
    public Commande getCommandeById(int idCommande) throws Exception {
        String sql = "SELECT * FROM commande WHERE id = ?";
        
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idCommande);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Commande commande = new Commande();
                    commande.setId(rs.getInt("id"));
                    commande.setIdUtilisateur(rs.getInt("idutilisateur"));
                    commande.setIdPanier(rs.getInt("idpanier"));
                    commande.setDateCommande(rs.getTimestamp("date_commande").toLocalDateTime());
                    commande.setStatut(rs.getString("statut"));
                    commande.setTotalAvantRemise(rs.getBigDecimal("total_avant_remise"));
                    commande.setTotalRemise(rs.getBigDecimal("total_remise"));
                    commande.setTotalFinal(rs.getBigDecimal("total_final"));
                    commande.setAdresseLivraison(rs.getString("adresse_livraison"));
                    commande.setMethodePaiement(rs.getString("methode_paiement"));
                    return commande;
                }
            }
        }
        return null;
    }
}