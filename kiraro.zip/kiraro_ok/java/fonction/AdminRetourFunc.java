package fonction;

import model.RetourArticle;
import java.sql.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import connexion.Connexion;

public class AdminRetourFunc {
    
    private Connection connect() throws Exception {
        Connection conn;
        conn = Connexion.getPostgresCon();
        return conn;
    }
    
    // Récupérer tous les retours en attente
    public List<RetourArticle> getRetoursEnAttente() throws Exception {
        List<RetourArticle> retours = new ArrayList<>();
        String sql = "SELECT ra.*, p.nom as produit_nom, p.reference, " +
                    "ca.prix_unitaire, ca.remise_appliquee, " +
                    "u.nom as client_nom, u.prenom as client_prenom " +
                    "FROM retour_article ra " +
                    "JOIN commande_article ca ON ra.idcommande_article = ca.id " +
                    "JOIN produit p ON ca.idproduit = p.id " +
                    "JOIN commande c ON ca.idcommande = c.id " +
                    "JOIN utilisateurs u ON c.idutilisateur = u.id " +
                    "WHERE ra.statut = 'en_attente' " +
                    "ORDER BY ra.date_demande ASC";
        
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                RetourArticle retour = mapRetourArticle(rs);
                retours.add(retour);
            }
        }
        return retours;
    }
    
    // Récupérer tous les retours traités
    public List<RetourArticle> getRetoursTraites() throws Exception {
        List<RetourArticle> retours = new ArrayList<>();
        String sql = "SELECT ra.*, p.nom as produit_nom, p.reference, " +
                    "ca.prix_unitaire, ca.remise_appliquee, " +
                    "u.nom as client_nom, u.prenom as client_prenom, " +
                    "au.nom as admin_nom, au.prenom as admin_prenom " +
                    "FROM retour_article ra " +
                    "JOIN commande_article ca ON ra.idcommande_article = ca.id " +
                    "JOIN produit p ON ca.idproduit = p.id " +
                    "JOIN commande c ON ca.idcommande = c.id " +
                    "JOIN utilisateurs u ON c.idutilisateur = u.id " +
                    "LEFT JOIN admin_utilisateur au ON ra.id_admin_traitement = au.id " +
                    "WHERE ra.statut IN ('approuvé', 'refusé') " +
                    "ORDER BY ra.date_traitement DESC";
        
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                RetourArticle retour = mapRetourArticle(rs);
                retour.setCommentaireAdmin(rs.getString("commentaire_admin"));
                retours.add(retour);
            }
        }
        return retours;
    }
    
    // Traiter un retour (approuver ou refuser)
    public boolean traiterRetour(int idRetour, String statut, BigDecimal montantRembourse, 
                                 String commentaire, int idAdmin) throws Exception {
        String sql = "UPDATE retour_article SET " +
                    "statut = ?, " +
                    "montant_rembourse = ?, " +
                    "commentaire_admin = ?, " +
                    "date_traitement = CURRENT_TIMESTAMP, " +
                    "id_admin_traitement = ? " +
                    "WHERE id = ?";
        
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, statut);
            
            if (montantRembourse != null) {
                pstmt.setBigDecimal(2, montantRembourse);
            } else {
                pstmt.setNull(2, Types.DECIMAL);
            }
            
            pstmt.setString(3, commentaire);
            pstmt.setInt(4, idAdmin);
            pstmt.setInt(5, idRetour);
            
            int rowsAffected = pstmt.executeUpdate();
            
            // Si le retour est approuvé, mettre à jour le stock
            if ("approuvé".equals(statut) && rowsAffected > 0) {
                updateStockAfterReturn(idRetour);
            }
            
            return rowsAffected > 0;
        }
    }
    
    // Mettre à jour le stock après un retour approuvé
    private void updateStockAfterReturn(int idRetour) throws Exception {
        String sql = "UPDATE stock_prix sp " +
                    "SET quantite = sp.quantite + ra.quantite_retournee " +
                    "FROM retour_article ra " +
                    "JOIN commande_article ca ON ra.idcommande_article = ca.id " +
                    "WHERE ra.id = ? " +
                    "AND sp.idvariante IN (" +
                    "    SELECT v.id FROM variante v " +
                    "    WHERE v.idproduit = ca.idproduit " +
                    "    AND v.idcouleur = ca.idcouleur" +
                    ") " +
                    "AND sp.idpointure = ca.idpointure";
        
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idRetour);
            pstmt.executeUpdate();
        }
    }
    
    // Récupérer les détails complets d'un retour
    public RetourArticle getRetourDetails(int idRetour) throws Exception {
        String sql = "SELECT ra.*, p.nom as produit_nom, p.reference, p.images, " +
                    "ca.prix_unitaire, ca.remise_appliquee, ca.quantite as quantite_commande, " +
                    "c.id as commande_id, c.total_final, " +
                    "u.nom as client_nom, u.prenom as client_prenom, u.email, " +
                    "cl.nom as couleur_nom, pt.pt as pointure_taille, " +
                    "au.nom as admin_nom, au.prenom as admin_prenom " +
                    "FROM retour_article ra " +
                    "JOIN commande_article ca ON ra.idcommande_article = ca.id " +
                    "JOIN produit p ON ca.idproduit = p.id " +
                    "JOIN commande c ON ca.idcommande = c.id " +
                    "JOIN utilisateurs u ON c.idutilisateur = u.id " +
                    "LEFT JOIN couleur cl ON ca.idcouleur = cl.id " +
                    "LEFT JOIN pointure pt ON ca.idpointure = pt.id " +
                    "LEFT JOIN admin_utilisateur au ON ra.id_admin_traitement = au.id " +
                    "WHERE ra.id = ?";
        
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idRetour);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapRetourArticle(rs);
                }
            }
        }
        return null;
    }
    
    // Statistiques
    public int getNombreRetoursMois() throws Exception {
        String sql = "SELECT COUNT(*) FROM retour_article " +
                    "WHERE date_demande >= DATE_TRUNC('month', CURRENT_DATE)";
        
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }
    
    public BigDecimal getMontantRembourseMois() throws Exception {
        String sql = "SELECT COALESCE(SUM(montant_rembourse), 0) FROM retour_article " +
                    "WHERE statut = 'approuvé' " +
                    "AND date_traitement >= DATE_TRUNC('month', CURRENT_DATE)";
        
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            if (rs.next()) {
                return rs.getBigDecimal(1);
            }
        }
        return BigDecimal.ZERO;
    }
    
    public double getTauxApprobation() throws Exception {
        String sql = "SELECT " +
                    "COUNT(CASE WHEN statut = 'approuvé' THEN 1 END) * 100.0 / " +
                    "NULLIF(COUNT(CASE WHEN statut IN ('approuvé', 'refusé') THEN 1 END), 0) " +
                    "FROM retour_article";
        
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            if (rs.next()) {
                return rs.getDouble(1);
            }
        }
        return 0.0;
    }
    
    // Méthode utilitaire pour mapper un ResultSet à RetourArticle
    private RetourArticle mapRetourArticle(ResultSet rs) throws Exception {
        RetourArticle retour = new RetourArticle();
        retour.setId(rs.getInt("id"));
        retour.setIdCommandeArticle(rs.getInt("idcommande_article"));
        retour.setQuantiteRetournee(rs.getInt("quantite_retournee"));
        retour.setMotif(rs.getString("motif"));
        retour.setStatut(rs.getString("statut"));
        retour.setDateDemande(rs.getTimestamp("date_demande").toLocalDateTime());
        
        if (rs.getTimestamp("date_traitement") != null) {
            retour.setDateTraitement(rs.getTimestamp("date_traitement").toLocalDateTime());
        }
        
        retour.setMontantRembourse(rs.getBigDecimal("montant_rembourse"));
        retour.setCommentaireAdmin(rs.getString("commentaire_admin"));
        
        // Informations supplémentaires
        retour.setProduitNom(rs.getString("produit_nom"));
        retour.setReference(rs.getString("reference"));
        retour.setPrixUnitaire(rs.getBigDecimal("prix_unitaire"));
        retour.setRemiseAppliquee(rs.getBigDecimal("remise_appliquee"));
        
        return retour;
    }
}