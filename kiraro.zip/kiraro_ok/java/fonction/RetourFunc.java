// fonction/RetourFunc.java
package fonction;
import connexion.Connexion;
import model.RetourArticle;
import java.sql.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class RetourFunc {
    
    private Connection connect() throws Exception {
        Connection conn;
        conn = Connexion.getPostgresCon();
        return conn;
    }
    
    // Demander un retour
    public boolean demanderRetour(int idCommandeArticle, int quantite, String motif) throws Exception {
        String sql = "INSERT INTO retour_article (idcommande_article, quantite_retournee, motif) " +
                    "VALUES (?, ?, ?)";
        
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idCommandeArticle);
            pstmt.setInt(2, quantite);
            pstmt.setString(3, motif);
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // Récupérer les retours d'un utilisateur
    public List<RetourArticle> getRetoursUtilisateur(int idUtilisateur) throws Exception {
        List<RetourArticle> retours = new ArrayList<>();
        String sql = "SELECT ra.*, p.nom as produit_nom, p.reference, ca.prix_unitaire, ca.remise_appliquee " +
                    "FROM retour_article ra " +
                    "JOIN commande_article ca ON ra.idcommande_article = ca.id " +
                    "JOIN commande c ON ca.idcommande = c.id " +
                    "JOIN produit p ON ca.idproduit = p.id " +
                    "WHERE c.idutilisateur = ? " +
                    "ORDER BY ra.date_demande DESC";
        
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idUtilisateur);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    RetourArticle retour = new RetourArticle();
                    retour.setId(rs.getInt("id"));
                    retour.setIdCommandeArticle(rs.getInt("idcommande_article"));
                    retour.setQuantiteRetournee(rs.getInt("quantite_retournee"));
                    retour.setMotif(rs.getString("motif"));
                    retour.setStatut(rs.getString("statut"));
                    retour.setDateDemande(rs.getTimestamp("date_demande").toLocalDateTime());
                    if (rs.getTimestamp("date_traitement") != null) {
                        retour.setDateTraitement(rs.getTimestamp("date_traitement").toLocalDateTime());
                    }
                    retour.setMontantRembourse(rs.getBigDecimal("montant_rembourse"));
                    retour.setCommentaireAdmin(rs.getString("commentaire_admin"));
                    
                    retour.setProduitNom(rs.getString("produit_nom"));
                    retour.setReference(rs.getString("reference"));
                    retour.setPrixUnitaire(rs.getBigDecimal("prix_unitaire"));
                    retour.setRemiseAppliquee(rs.getBigDecimal("remise_appliquee"));
                    
                    retours.add(retour);
                }
            }
        }
        return retours;
    }
    
    // Vérifier si un retour est possible pour un article
    public boolean peutRetourner(int idCommandeArticle, int quantiteDemandee) throws Exception {
        String sql = "SELECT ca.quantite - COALESCE(SUM(CASE WHEN ra.statut = 'approuvé' THEN ra.quantite_retournee ELSE 0 END), 0) as quantite_disponible " +
                    "FROM commande_article ca " +
                    "LEFT JOIN retour_article ra ON ca.id = ra.idcommande_article " +
                    "WHERE ca.id = ? " +
                    "GROUP BY ca.id, ca.quantite";
        
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idCommandeArticle);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    int quantiteDisponible = rs.getInt("quantite_disponible");
                    return quantiteDemandee > 0 && quantiteDemandee <= quantiteDisponible;
                }
            }
        }
        return false;
    }
    
    // Calculer le montant à rembourser
    public BigDecimal calculerMontantRemboursement(int idCommandeArticle, int quantite) throws Exception {
        String sql = "SELECT prix_unitaire, remise_appliquee, sous_total_net / quantite as prix_unitaire_net " +
                    "FROM commande_article WHERE id = ?";
        
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idCommandeArticle);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    BigDecimal prixUnitaireNet = rs.getBigDecimal("prix_unitaire_net");
                    return prixUnitaireNet.multiply(BigDecimal.valueOf(quantite));
                }
            }
        }
        return BigDecimal.ZERO;
    }
}