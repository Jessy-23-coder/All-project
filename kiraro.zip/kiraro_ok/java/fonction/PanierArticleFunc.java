package fonction;

import connexion.Connexion;
import model.PanierArticle;
import java.sql.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class PanierArticleFunc {
    
    public static boolean mettreAJourSelection(int idArticle, int idCouleur, int idPointure, int idStockPrix) throws Exception {
    String sql = "UPDATE panier_article SET " +
                "idcouleur_selectionnee = ?, " +
                "idpointure_selectionnee = ?, " +
                "idstock_prix_selectionne = ? " +
                "WHERE id = ?";
    
    String getPanierSql = "SELECT idpanier FROM panier_article WHERE id = ?";
    
    try (Connection conn = Connexion.getPostgresCon()) {
        conn.setAutoCommit(false);
        
        try {
            // Récupérer l'id du panier
            PreparedStatement getPanierStmt = conn.prepareStatement(getPanierSql);
            getPanierStmt.setInt(1, idArticle);
            ResultSet rs = getPanierStmt.executeQuery();
            
            int idPanier = 0;
            if (rs.next()) {
                idPanier = rs.getInt("idpanier");
            }
            
            // Mettre à jour la sélection
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, idCouleur);
                pstmt.setInt(2, idPointure);
                pstmt.setInt(3, idStockPrix);
                pstmt.setInt(4, idArticle);
                
                int rows = pstmt.executeUpdate();
                
                if (rows > 0 && idPanier > 0) {
                    // Mettre à jour la date du panier
                    PanierFunc.updateDatePanier(idPanier, conn);
                    conn.commit();
                    return true;
                } else {
                    conn.rollback();
                    return false;
                }
            }
            
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        }
    } catch (SQLException e) {
        e.printStackTrace();
        throw new Exception("Erreur lors de la mise à jour de la sélection: " + e.getMessage());
    }
}
 


    public static boolean ajouterProduitAvecSelection(int idPanier, int idProduit, 
                                                  Integer idCouleur, Integer idPointure, 
                                                  Integer idStockPrix, int quantite) throws Exception {
    
    // Vérifier la disponibilité du stock
    if (idStockPrix != null) {
        if (!verifierStockDisponible(idStockPrix, quantite)) {
            throw new Exception("Stock insuffisant pour la quantité demandée");
        }
    }
    
    // Obtenir le prix unitaire
    BigDecimal prixUnitaire = idStockPrix != null ? getPrixEffectif(idStockPrix) : getPrixMinimumProduit(idProduit);
    
    String sql = "INSERT INTO panier_article " +
                "(idpanier, id_produit, idcouleur_selectionnee, idpointure_selectionnee, " +
                "idstock_prix_selectionne, quantite, prix_unitaire_selectionne) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?) " +
                "ON CONFLICT (idpanier, id_produit) " +
                "DO UPDATE SET " +
                "quantite = panier_article.quantite + EXCLUDED.quantite, " +
                "idcouleur_selectionnee = COALESCE(EXCLUDED.idcouleur_selectionnee, panier_article.idcouleur_selectionnee), " +
                "idpointure_selectionnee = COALESCE(EXCLUDED.idpointure_selectionnee, panier_article.idpointure_selectionnee), " +
                "idstock_prix_selectionne = COALESCE(EXCLUDED.idstock_prix_selectionne, panier_article.idstock_prix_selectionne), " +
                "prix_unitaire_selectionne = COALESCE(EXCLUDED.prix_unitaire_selectionne, panier_article.prix_unitaire_selectionne), " +
                "date_ajout = CURRENT_TIMESTAMP";
    
    try (Connection conn = Connexion.getPostgresCon()) {
        conn.setAutoCommit(false);
        
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idPanier);
            pstmt.setInt(2, idProduit);
            
            if (idCouleur != null) {
                pstmt.setInt(3, idCouleur);
            } else {
                pstmt.setNull(3, Types.INTEGER);
            }
            
            if (idPointure != null) {
                pstmt.setInt(4, idPointure);
            } else {
                pstmt.setNull(4, Types.INTEGER);
            }
            
            if (idStockPrix != null) {
                pstmt.setInt(5, idStockPrix);
            } else {
                pstmt.setNull(5, Types.INTEGER);
            }
            
            pstmt.setInt(6, quantite);
            pstmt.setBigDecimal(7, prixUnitaire);
            
            int rows = pstmt.executeUpdate();
            
            if (rows > 0) {
                // Mettre à jour la date du panier
                PanierFunc.updateDatePanier(idPanier, conn);
                conn.commit();
                return true;
            }
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        }
    }
    
    return false;
}


public static BigDecimal getPrixMinimumProduit(int idProduit) throws Exception {
    String sql = "SELECT MIN(COALESCE(sp.prix_promo, sp.prix)) as prix_min " +
                "FROM produit p " +
                "LEFT JOIN variante v ON p.id = v.idproduit " +
                "LEFT JOIN stock_prix sp ON v.id = sp.idvariante " +
                "WHERE p.id = ? AND p.est_actif = true " +
                "GROUP BY p.id";
    
    try (Connection conn = Connexion.getPostgresCon();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setInt(1, idProduit);
        ResultSet rs = pstmt.executeQuery();
        if (rs.next()) {
            BigDecimal prix = rs.getBigDecimal("prix_min");
            return prix != null ? prix : BigDecimal.ZERO;
        }
    }
    return BigDecimal.ZERO;
}

    
   public static boolean modifierQuantite(int idArticle, int nouvelleQuantite) throws Exception {
    if (nouvelleQuantite <= 0) {
        return supprimerArticle(idArticle);
    }
    
    String updateSql = "UPDATE panier_article SET quantite = ?, date_ajout = CURRENT_TIMESTAMP WHERE id = ?";
    String getPanierSql = "SELECT idpanier FROM panier_article WHERE id = ?";
    
    try (Connection conn = Connexion.getPostgresCon()) {
        conn.setAutoCommit(false);
        
        try {
            // Récupérer l'id du panier
            PreparedStatement getPanierStmt = conn.prepareStatement(getPanierSql);
            getPanierStmt.setInt(1, idArticle);
            ResultSet rs = getPanierStmt.executeQuery();
            
            int idPanier = 0;
            if (rs.next()) {
                idPanier = rs.getInt("idpanier");
            }
            
            // Mettre à jour la quantité
            PreparedStatement updateStmt = conn.prepareStatement(updateSql);
            updateStmt.setInt(1, nouvelleQuantite);
            updateStmt.setInt(2, idArticle);
            int rows = updateStmt.executeUpdate();
            
            if (rows > 0 && idPanier > 0) {
                // Mettre à jour la date du panier
                PanierFunc.updateDatePanier(idPanier, conn);
                conn.commit();
                return true;
            }
            
            conn.rollback();
            return false;
            
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        }
    } catch (SQLException e) {
        e.printStackTrace();
        throw new Exception("Erreur lors de la modification de la quantité: " + e.getMessage());
    }
}
    
    // 4. Supprimer un article du panier
    public static boolean supprimerArticle(int idArticle) throws Exception {
        String getPanierSql = "SELECT idpanier FROM panier_article WHERE id = ?";
        String deleteSql = "DELETE FROM panier_article WHERE id = ?";
        
        try (Connection conn = Connexion.getPostgresCon()) {
            conn.setAutoCommit(false);
            
            try {
                // Récupérer l'id du panier
                PreparedStatement getPanierStmt = conn.prepareStatement(getPanierSql);
                getPanierStmt.setInt(1, idArticle);
                ResultSet rs = getPanierStmt.executeQuery();
                
                if (rs.next()) {
                    int idPanier = rs.getInt("idpanier");
                    
                    // Supprimer l'article
                    PreparedStatement deleteStmt = conn.prepareStatement(deleteSql);
                    deleteStmt.setInt(1, idArticle);
                    int rows = deleteStmt.executeUpdate();
                    
                    if (rows > 0) {
                        // Mettre à jour la date du panier
                        PanierFunc.updateDatePanier(idPanier, conn);
                        conn.commit();
                        return true;
                    }
                }
                
                conn.rollback();
                return false;
                
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors de la suppression de l'article: " + e.getMessage());
        }
    }
    
    // 5. Récupérer tous les articles d'un panier avec détails
   public static List<PanierArticle> getArticlesPanier(int idPanier) throws Exception {
    List<PanierArticle> articles = new ArrayList<>();
    
    // Requête SIMPLIFIÉE - uniquement les colonnes qui existent vraiment
    String sql = "SELECT " +
                "pa.id, " +
                "pa.idpanier, " +
                "pa.id_produit, " +
                "pa.quantite, " +
                "pa.remise_appliquee, " +
                "pa.date_ajout, " +
                "p.nom as nomProduit, " +
                "p.reference, " +
                "p.images, " +
                "m.nom as modele_nom, " +
                "mar.nom as marque_nom, " +
                "COALESCE(MIN(sp.prix), 0.00) as prix_unitaire " +
                "FROM panier_article pa " +
                "INNER JOIN produit p ON pa.id_produit = p.id " +
                "LEFT JOIN modele m ON p.idmodele = m.id " +
                "LEFT JOIN marque mar ON m.idmarque = mar.id " +
                "LEFT JOIN variante v ON p.id = v.idproduit " +
                "LEFT JOIN stock_prix sp ON v.id = sp.idvariante " +
                "WHERE p.est_actif = true AND pa.idpanier = ? " +
                "GROUP BY pa.id, pa.idpanier, pa.id_produit, pa.quantite, " +
                "pa.remise_appliquee, pa.date_ajout, " +
                "p.nom, p.reference, p.images, m.nom, mar.nom " +
                "ORDER BY pa.date_ajout DESC";
    
    try (Connection conn = Connexion.getPostgresCon();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        
        pstmt.setInt(1, idPanier);
        try (ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                articles.add(mapResultSetToPanierArticle(rs));
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        throw new Exception("Erreur lors de la récupération des articles: " + e.getMessage());
    }
    
    return articles;
}


   public static String getOptionsForArticle(int articleId, int produitId) throws Exception {
    String sql = "SELECT DISTINCT " +
                "c.id as couleur_id, c.nom as couleur_nom, " +
                "COALESCE(c.code_hex, '#cccccc') as couleur_code, " +
                "pt.id as pointure_id, pt.pt as pointure_taille, " +
                "sp.id as stock_prix_id, " +
                "COALESCE(sp.prix_promo, sp.prix, 0.00) as prix, " +
                "COALESCE(sp.quantite, 0) as stock " +
                "FROM variante v " +
                "JOIN couleur c ON v.idcouleur = c.id " +
                "JOIN stock_prix sp ON v.id = sp.idvariante " +
                "JOIN pointure pt ON sp.idpointure = pt.id " +
                "WHERE v.idproduit = ? " +
                "ORDER BY c.nom, pt.pt";
    
    StringBuilder json = new StringBuilder();
    json.append("[");
    
    try (Connection conn = Connexion.getPostgresCon();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        
        pstmt.setInt(1, produitId);
        try (ResultSet rs = pstmt.executeQuery()) {
            boolean first = true;
            int count = 0;
            
            while (rs.next()) {
                if (!first) json.append(",");
                
                int stock = rs.getInt("stock");
                BigDecimal prix = rs.getBigDecimal("prix");
                
                json.append("{")
                    .append("\"couleur_id\":").append(rs.getInt("couleur_id")).append(",")
                    .append("\"couleur_nom\":\"").append(escapeJson(rs.getString("couleur_nom"))).append("\",")
                    .append("\"couleur_code\":\"").append(escapeJson(rs.getString("couleur_code"))).append("\",")
                    .append("\"pointure_id\":").append(rs.getInt("pointure_id")).append(",")
                    .append("\"pointure_taille\":\"").append(escapeJson(rs.getString("pointure_taille"))).append("\",")
                    .append("\"stock_prix_id\":").append(rs.getInt("stock_prix_id")).append(",")
                    .append("\"prix\":").append(prix != null ? prix.toString() : "0.00").append(",")
                    .append("\"stock\":").append(stock)
                    .append("}");
                
                first = false;
                count++;
            }
            
            System.out.println("Trouvé " + count + " options pour produit " + produitId);
        }
    } catch (SQLException e) {
        e.printStackTrace();
        throw new Exception("Erreur lors de la récupération des options: " + e.getMessage());
    }
    
    json.append("]");
    String result = json.toString();
    System.out.println("JSON généré: " + (result.length() > 100 ? result.substring(0, 100) + "..." : result));
    return result;
}

// Dans PanierArticleFunc.java, ajoutez une méthode de test
public static void testOptions() {
    try {
        String options = getOptionsForArticle(1, 1); // Remplacez par un ID existant
        System.out.println("Options JSON: " + options);
    } catch (Exception e) {
        e.printStackTrace();
    }
}
    
    // 6. Vérifier si un produit existe dans le panier
    public static boolean produitExisteDansPanier(int idPanier, int idProduit) throws Exception {
        String sql = "SELECT COUNT(*) FROM panier_article WHERE idpanier = ? AND id_produit = ?";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idPanier);
            pstmt.setInt(2, idProduit);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors de la vérification: " + e.getMessage());
        }
        
        return false;
    }
    
    // 7. Récupérer le nombre total d'articles dans le panier
    public static int getNombreArticlesPanier(int idPanier) throws Exception {
        String sql = "SELECT COUNT(*) as total FROM panier_article WHERE idpanier = ?";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idPanier);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("total");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors du comptage: " + e.getMessage());
        }
        
        return 0;
    }
    
    // 8. Récupérer l'id du stock_prix pour une combinaison produit/couleur/pointure
    public static Integer getStockPrixId(int idProduit, int idCouleur, int idPointure) throws Exception {
        String sql = "SELECT sp.id FROM stock_prix sp " +
                    "JOIN variante v ON sp.idvariante = v.id " +
                    "WHERE v.idproduit = ? AND v.idcouleur = ? AND sp.idpointure = ?";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idProduit);
            pstmt.setInt(2, idCouleur);
            pstmt.setInt(3, idPointure);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        }
        return null;
    }
    
    // 9. Récupérer les variantes disponibles d'un produit au format JSON
    public static String getVariantesProduitJson(int idProduit) throws Exception {
        String sql = "SELECT " +
                    "c.id as couleur_id, " +
                    "c.nom as couleur_nom, " +
                    "c.code_hex as couleur_code, " +
                    "pt.id as pointure_id, " +
                    "pt.pt as pointure_taille, " +
                    "sp.id as stock_prix_id, " +
                    "COALESCE(sp.prix_promo, sp.prix) as prix_effectif, " +
                    "sp.quantite as stock " +
                    "FROM variante v " +
                    "JOIN couleur c ON v.idcouleur = c.id " +
                    "JOIN stock_prix sp ON v.id = sp.idvariante " +
                    "JOIN pointure pt ON sp.idpointure = pt.id " +
                    "WHERE v.idproduit = ? " +
                    "ORDER BY c.nom, pt.pt";
        
        StringBuilder json = new StringBuilder();
        json.append("[");
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idProduit);
            try (ResultSet rs = pstmt.executeQuery()) {
                boolean first = true;
                while (rs.next()) {
                    if (!first) json.append(",");
                    
                    json.append("{")
                        .append("\"couleur_id\":").append(rs.getInt("couleur_id")).append(",")
                        .append("\"couleur_nom\":\"").append(escapeJson(rs.getString("couleur_nom"))).append("\",")
                        .append("\"couleur_code\":\"").append(rs.getString("couleur_code") != null ? rs.getString("couleur_code") : "#cccccc").append("\",")
                        .append("\"pointure_id\":").append(rs.getInt("pointure_id")).append(",")
                        .append("\"pointure_taille\":\"").append(escapeJson(rs.getString("pointure_taille"))).append("\",")
                        .append("\"stock_prix_id\":").append(rs.getInt("stock_prix_id")).append(",")
                        .append("\"prix\":").append(rs.getBigDecimal("prix_effectif")).append(",")
                        .append("\"stock\":").append(rs.getInt("stock"))
                        .append("}");
                    
                    first = false;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors de la récupération des variantes: " + e.getMessage());
        }
        
        json.append("]");
        return json.toString();
    }
    
    // 10. Récupérer la sélection actuelle d'un article
    public static Map<String, Object> getSelectionActuelle(int idArticle) throws Exception {
        Map<String, Object> selection = new HashMap<>();
        String sql = "SELECT " +
                    "pa.idcouleur_selectionnee, " +
                    "pa.idpointure_selectionnee, " +
                    "pa.idstock_prix_selectionne, " +
                    "c.nom as couleur_nom, " +
                    "p.pt as pointure_taille, " +
                    "sp.prix, " +
                    "sp.prix_promo " +
                    "FROM panier_article pa " +
                    "LEFT JOIN couleur c ON pa.idcouleur_selectionnee = c.id " +
                    "LEFT JOIN pointure p ON pa.idpointure_selectionnee = p.id " +
                    "LEFT JOIN stock_prix sp ON pa.idstock_prix_selectionne = sp.id " +
                    "WHERE pa.id = ?";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idArticle);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                selection.put("couleur_id", rs.getObject("idcouleur_selectionnee"));
                selection.put("pointure_id", rs.getObject("idpointure_selectionnee"));
                selection.put("stock_prix_id", rs.getObject("idstock_prix_selectionne"));
                selection.put("couleur_nom", rs.getString("couleur_nom"));
                selection.put("pointure_taille", rs.getString("pointure_taille"));
                selection.put("prix", rs.getBigDecimal("prix"));
                selection.put("prix_promo", rs.getBigDecimal("prix_promo"));
                selection.put("prix_effectif", rs.getBigDecimal("prix_promo") != null ? 
                    rs.getBigDecimal("prix_promo") : rs.getBigDecimal("prix"));
                selection.put("selection_complete", 
                    rs.getObject("idcouleur_selectionnee") != null && 
                    rs.getObject("idpointure_selectionnee") != null);
            }
        }
        return selection;
    }
    
    // 11. Vérifier si tous les articles du panier ont une sélection
    public static boolean toutesSelectionsCompletes(int idPanier) throws Exception {
        String sql = "SELECT COUNT(*) as total, " +
                    "COUNT(CASE WHEN idcouleur_selectionnee IS NOT NULL AND idpointure_selectionnee IS NOT NULL THEN 1 END) as completes " +
                    "FROM panier_article WHERE idpanier = ?";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idPanier);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                int total = rs.getInt("total");
                int completes = rs.getInt("completes");
                return total > 0 && total == completes;
            }
        }
        return false;
    }
    
    // 12. Annuler la sélection d'un article
    public static boolean annulerSelection(int idArticle) throws Exception {
        String sql = "UPDATE panier_article SET " +
                    "idcouleur_selectionnee = NULL, " +
                    "idpointure_selectionnee = NULL, " +
                    "idstock_prix_selectionne = NULL " +
                    "WHERE id = ?";
        
        try (Connection conn = Connexion.getPostgresCon()) {
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, idArticle);
                int rows = pstmt.executeUpdate();
                return rows > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors de l'annulation de la sélection: " + e.getMessage());
        }
    }
    
    // 13. Vérifier la disponibilité du stock
    private static boolean verifierStockDisponible(int idStockPrix) throws Exception {
        if (idStockPrix <= 0) return true; // Pas de vérification si pas de sélection
        
        String sql = "SELECT quantite FROM stock_prix WHERE id = ?";
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idStockPrix);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                int stockDisponible = rs.getInt("quantite");
                return stockDisponible > 0;
            }
        }
        return false;
    }
    
    // 14. Vérifier la disponibilité du stock avec quantité spécifique
    private static boolean verifierStockDisponible(int idStockPrix, int quantiteDemandee) throws Exception {
        if (idStockPrix <= 0) return true; // Pas de vérification si pas de sélection
        
        String sql = "SELECT quantite FROM stock_prix WHERE id = ?";
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idStockPrix);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                int stockDisponible = rs.getInt("quantite");
                return stockDisponible >= quantiteDemandee;
            }
        }
        return false;
    }
    
    // 15. Mettre à jour la date du panier à partir de l'article
    private static void updateDatePanierFromArticle(int idArticle, Connection conn) throws SQLException {
        String sql = "UPDATE panier SET date_modification = CURRENT_TIMESTAMP " +
                    "WHERE id = (SELECT idpanier FROM panier_article WHERE id = ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idArticle);
            pstmt.executeUpdate();
        }
    }
    
    // 16. Vider le panier
    public static boolean viderPanier(int idPanier) throws Exception {
        String sql = "DELETE FROM panier_article WHERE idpanier = ?";
        
        try (Connection conn = Connexion.getPostgresCon()) {
            conn.setAutoCommit(false);
            
            try {
                // Supprimer tous les articles
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, idPanier);
                int rows = pstmt.executeUpdate();
                
                // Mettre à jour la date du panier
                PanierFunc.updateDatePanier(idPanier, conn);
                
                conn.commit();
                return rows >= 0;
                
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors du vidage du panier: " + e.getMessage());
        }
    }
    
    // 17. Méthode de mapping
  private static PanierArticle mapResultSetToPanierArticle(ResultSet rs) throws SQLException {
    PanierArticle article = new PanierArticle();
    
    // Colonnes de base (celles qui existent vraiment)
    article.setId(rs.getInt("id"));
    article.setIdPanier(rs.getInt("idpanier"));
    article.setIdProduit(rs.getInt("id_produit"));
    article.setQuantite(rs.getInt("quantite"));
    article.setRemiseAppliquee(rs.getBigDecimal("remise_appliquee"));
    article.setDateAjout(rs.getTimestamp("date_ajout"));
    article.setPrixUnitaire(rs.getBigDecimal("prix_unitaire"));
    
    // Informations supplémentaires
    article.setNomProduit(rs.getString("nomProduit"));
    article.setReference(rs.getString("reference"));
    article.setModele(rs.getString("modele_nom"));
    article.setMarque(rs.getString("marque_nom"));
    article.setImages(rs.getString("images"));
    
    // NE PAS ESSAYER DE LIRE LES COLONNES QUI N'EXISTENT PAS
    // article.setSousTotalBrut(...); // Cette colonne n'existe pas dans la requête
    // article.setMontantRemise(...); // Cette colonne n'existe pas dans la requête
    // article.setSousTotalNet(...);  // Cette colonne n'existe pas dans la requête
    // article.setRemiseDisponible(...); // Cette colonne n'existe pas dans la requête
    
    return article;
}
    
    // 18. Méthode utilitaire pour échapper les caractères JSON
    private static String escapeJson(String input) {
        if (input == null) return "";
        return input.replace("\\", "\\\\")
                   .replace("\"", "\\\"")
                   .replace("\n", "\\n")
                   .replace("\r", "\\r")
                   .replace("\t", "\\t");
    }
    
    // 19. Récupérer le prix effectif pour un stock_prix
    public static BigDecimal getPrixEffectif(int idStockPrix) throws Exception {
        String sql = "SELECT COALESCE(prix_promo, prix) as prix_final FROM stock_prix WHERE id = ?";
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idStockPrix);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getBigDecimal("prix_final");
            }
        }
        return BigDecimal.ZERO;
    }
    
    // 20. Récupérer les informations complètes d'un article du panier
    public static PanierArticle getArticleById(int idArticle) throws Exception {
        String sql = "SELECT * FROM vue_panier_detail WHERE id = ?";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idArticle);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToPanierArticle(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erreur lors de la récupération de l'article: " + e.getMessage());
        }
        
        return null;
    }
    
    // 21. Calculer le total du panier
    public static BigDecimal calculerTotalPanier(int idPanier) throws Exception {
        String sql = "SELECT SUM(COALESCE(prix_unitaire, 0) * quantite) as total FROM vue_panier_detail WHERE idpanier = ?";
        
        try (Connection conn = Connexion.getPostgresCon();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idPanier);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                BigDecimal total = rs.getBigDecimal("total");
                return total != null ? total : BigDecimal.ZERO;
            }
        }
        return BigDecimal.ZERO;
    }
}