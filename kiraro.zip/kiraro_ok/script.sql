--databse : kiraro

CREATE TABLE utilisateurs (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    mot_de_passe VARCHAR(255) NOT NULL,
    nom VARCHAR(100),
    prenom VARCHAR(100),
    role VARCHAR(20) DEFAULT 'client'
);

-- 1. CATÉGORIE
CREATE TABLE categorie (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(100)
);

-- 2. SOUS_CATEGORIE
CREATE TABLE sous_categorie (
    id SERIAL PRIMARY KEY,
    idcateg INTEGER,
    nom VARCHAR(100),
    FOREIGN KEY (idcateg) REFERENCES categorie(id) ON DELETE CASCADE
);

-- 3. POINTURE
CREATE TABLE pointure (
    id SERIAL PRIMARY KEY,
    pt VARCHAR(10) UNIQUE NOT NULL
);

-- 4. MARQUE
CREATE TABLE marque (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(100) UNIQUE
);

-- 5. GENRE
CREATE TABLE genre (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(50) UNIQUE
);

-- 6. MODÈLE
CREATE TABLE modele (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(200) NOT NULL,
    idmarque INTEGER,
    description TEXT,
    FOREIGN KEY (idmarque) REFERENCES marque(id) ON DELETE CASCADE
);

-- 7. COULEUR
CREATE TABLE couleur (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(50) UNIQUE,
    code_hex VARCHAR(7)
);

-- 8. PRODUIT
CREATE TABLE produit (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(255),
    idmodele INTEGER,
    idgenre INTEGER,
    idsouscategorie INTEGER,
    reference VARCHAR(100) UNIQUE,
    description TEXT,
    caracteristiques JSONB,
    est_actif BOOLEAN DEFAULT true,
    images JSONB,
    date_ajout TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (idmodele) REFERENCES modele(id) ON DELETE CASCADE,
    FOREIGN KEY (idgenre) REFERENCES genre(id) ON DELETE CASCADE,
    FOREIGN KEY (idsouscategorie) REFERENCES sous_categorie(id) ON DELETE CASCADE
);

-- 9. VARIANTE
CREATE TABLE variante (
    id SERIAL PRIMARY KEY,
    idproduit INTEGER,
    idcouleur INTEGER,
    
    FOREIGN KEY (idproduit) REFERENCES produit(id) ON DELETE CASCADE,
    FOREIGN KEY (idcouleur) REFERENCES couleur(id) ON DELETE CASCADE,
    
    UNIQUE (idproduit, idcouleur)
);


-- 10. STOCK_PRIX
CREATE TABLE stock_prix (
    id SERIAL PRIMARY KEY,
    idvariante INTEGER,
    idpointure INTEGER,
    prix DECIMAL(10,2) NOT NULL CHECK (prix >= 0),
    prix_promo DECIMAL(10,2) CHECK (prix_promo >= 0),
    quantite INTEGER DEFAULT 0 CHECK (quantite >= 0),
    
    FOREIGN KEY (idvariante) REFERENCES variante(id) ON DELETE CASCADE,
    FOREIGN KEY (idpointure) REFERENCES pointure(id) ON DELETE CASCADE,
    CHECK (prix_promo IS NULL OR prix_promo <= prix),
    UNIQUE (idvariante, idpointure)

);


-- Création des index pour optimiser les performances
CREATE INDEX idx_souscategorie_categorie ON sous_categorie(idcateg);
CREATE INDEX idx_modele_marque ON modele(idmarque);
CREATE INDEX idx_produit_modele ON produit(idmodele);
CREATE INDEX idx_produit_genre ON produit(idgenre);
CREATE INDEX idx_produit_souscategorie ON produit(idsouscategorie);
CREATE INDEX idx_variante_produit ON variante(idproduit);
CREATE INDEX idx_variante_couleur ON variante(idcouleur);
CREATE INDEX idx_stock_variante ON stock_prix(idvariante);
CREATE INDEX idx_stock_pointure ON stock_prix(idpointure);
CREATE INDEX idx_produit_actif ON produit(est_actif) WHERE est_actif = true;


-- Optionnel: Fonction pour calculer le prix final
CREATE OR REPLACE FUNCTION prix_final(prix_base DECIMAL, prix_promo DECIMAL)
RETURNS DECIMAL AS $$
BEGIN
    RETURN COALESCE(prix_promo, prix_base);
END;
$$ LANGUAGE plpgsql;

drop VIEW vue_produit_complet;
-- Recréer la vue avec COALESCE approprié
CREATE OR REPLACE VIEW vue_produit_complet AS
SELECT 
    p.id,
    p.nom,
    p.reference,
    p.description,
    p.caracteristiques,
    p.est_actif,
    p.images,
    p.date_ajout,
    
    m.id as modele_id,
    m.nom as modele_nom,
    m.description as modele_description,
    
    marque.id as marque_id,
    marque.nom as marque_nom,
    
    g.id as genre_id,
    g.nom as genre_nom,
    
    cat.id as categorie_id,
    cat.nom as categorie_nom,
    
    sc.id as sous_categorie_id,
    sc.nom as sous_categorie_nom,
    
    -- PRIX : CORRIGÉ POUR ÉVITER LES NULL
    COALESCE(MIN(sp.prix_promo), MIN(sp.prix), 0.00) as prix_min,
    COALESCE(MAX(sp.prix_promo), MAX(sp.prix), 0.00) as prix_max,
    COALESCE(MIN(sp.prix), 0.00) as prix_base_min,
    COALESCE(MAX(sp.prix), 0.00) as prix_base_max,
    
    -- Stock
    COALESCE(SUM(sp.quantite), 0) as stock_total,
    
    -- Disponibilité
    COUNT(DISTINCT v.idcouleur) as nb_couleurs,
    COUNT(DISTINCT sp.idpointure) as nb_pointures_total,
    COUNT(DISTINCT CASE WHEN sp.quantite > 0 THEN sp.idpointure END) as nb_pointures_disponibles,
    
    -- Promotion flag
    MAX(CASE WHEN sp.prix_promo IS NOT NULL THEN 1 ELSE 0 END) as a_promotion
    
FROM produit p
JOIN modele m ON p.idmodele = m.id
JOIN marque ON m.idmarque = marque.id
JOIN genre g ON p.idgenre = g.id
JOIN sous_categorie sc ON p.idsouscategorie = sc.id
JOIN categorie cat ON sc.idcateg = cat.id
LEFT JOIN variante v ON p.id = v.idproduit
LEFT JOIN stock_prix sp ON v.id = sp.idvariante
WHERE p.est_actif = true
GROUP BY p.id,p.nom, p.reference, p.description, p.caracteristiques, p.est_actif, p.images, p.date_ajout,
         m.id, m.nom, m.description, marque.id, marque.nom, g.id, g.nom, 
         cat.id, cat.nom, sc.id, sc.nom;


--Panier


-- Table pour les paramètres de remise par quantité
CREATE TABLE parametre_remise (
    id SERIAL PRIMARY KEY,
    quantite_min INTEGER NOT NULL CHECK (quantite_min >= 0),
    quantite_max INTEGER CHECK (quantite_max >= quantite_min OR quantite_max IS NULL),
    pourcentage_remise DECIMAL(5,2) NOT NULL CHECK (pourcentage_remise >= 0 AND pourcentage_remise <= 100),
    date_debut TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    date_fin TIMESTAMP,
    est_actif BOOLEAN DEFAULT true
);

-- Table panier (en-tête)
CREATE TABLE panier (
    id SERIAL PRIMARY KEY,
    idutilisateur INTEGER NOT NULL,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    date_modification TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (idutilisateur) REFERENCES utilisateurs(id) ON DELETE CASCADE
);




-- Table pour les articles dans le panier
CREATE TABLE panier_article (
    id SERIAL PRIMARY KEY,
    idpanier INTEGER NOT NULL,
    id_produit INTEGER NOT NULL REFERENCES produit(id) ON DELETE CASCADE,
    quantite INTEGER NOT NULL CHECK (quantite > 0),
    remise_appliquee DECIMAL(5,2) DEFAULT 0 CHECK (remise_appliquee >= 0 AND remise_appliquee <= 100),
    date_ajout TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (idpanier) REFERENCES panier(id) ON DELETE CASCADE,
);

-- Ajoutez ces colonnes à votre table panier_article
ALTER TABLE panier_article 
ADD COLUMN idcouleur_selectionnee INTEGER REFERENCES couleur(id),
ADD COLUMN idpointure_selectionnee INTEGER REFERENCES pointure(id),
ADD COLUMN idstock_prix_selectionne INTEGER REFERENCES stock_prix(id);

ALTER TABLE panier_article 
ALTER COLUMN quantite DROP NOT NULL;


DROP VIEW IF EXISTS vue_panier_detail;
CREATE OR REPLACE VIEW vue_panier_detail AS
WITH 
-- Prix et variantes par produit
produit_variantes AS (
    SELECT 
        p.id as produit_id,
        MIN(COALESCE(sp.prix_promo, sp.prix)) as prix_min,
        MAX(COALESCE(sp.prix_promo, sp.prix)) as prix_max,
        ARRAY_AGG(
            DISTINCT JSONB_BUILD_OBJECT(
                'couleur_id', c.id,
                'couleur_nom', c.nom,
                'couleur_code', c.code_hex,
                'pointure_id', pt.id,
                'pointure_taille', pt.pt,
                'stock_prix_id', sp.id,
                'prix', COALESCE(sp.prix_promo, sp.prix),
                'prix_base', sp.prix,
                'prix_promo', sp.prix_promo,
                'stock', sp.quantite
            )
        ) as variantes_json
    FROM produit p
    LEFT JOIN variante v ON p.id = v.idproduit
    LEFT JOIN couleur c ON v.idcouleur = c.id
    LEFT JOIN stock_prix sp ON v.id = sp.idvariante
    LEFT JOIN pointure pt ON sp.idpointure = pt.id
    WHERE p.est_actif = true
    GROUP BY p.id
),
-- Récupérer la remise applicable selon la quantité
remise_applicable AS (
    SELECT 
        pa.id as article_id,
        pa.quantite,
        COALESCE(MAX(pr.pourcentage_remise), 0) as remise_calculée
    FROM panier_article pa
    LEFT JOIN parametre_remise pr ON 
        pa.quantite >= pr.quantite_min 
        AND (pa.quantite <= pr.quantite_max OR pr.quantite_max IS NULL)
        AND pr.est_actif = true
    GROUP BY pa.id, pa.quantite
)
SELECT 
    pa.id,
    pa.idpanier,
    pa.id_produit,
    pa.quantite,
    -- Utiliser la remise calculée ou celle déjà définie
    COALESCE(pa.remise_appliquee, ra.remise_calculée, 0) as remise_appliquee,
    pa.date_ajout,
    
    -- PRIX : prendre le prix minimum du produit
    COALESCE(pv.prix_min, 0.00) as prix_unitaire,
    
    -- Calcul du sous-total AVANT remise
    (COALESCE(pv.prix_min, 0.00) * pa.quantite) as sous_total_brut,
    
    -- Calcul du sous-total APRÈS remise
    (COALESCE(pv.prix_min, 0.00) * pa.quantite * 
     (1 - COALESCE(pa.remise_appliquee, ra.remise_calculée, 0) / 100)) as sous_total_net,
    
    -- Montant de la remise
    (COALESCE(pv.prix_min, 0.00) * pa.quantite * 
     COALESCE(pa.remise_appliquee, ra.remise_calculée, 0) / 100) as montant_remise,
    
    -- Informations PRODUIT
    p.id as produit_id,
    p.nom as nomProduit,
    p.reference,
    p.description,
    p.images,
    p.est_actif,
    p.date_ajout as produit_date_ajout,
    
    -- Informations MODÈLE
    m.id as modele_id,
    m.nom as modele_nom,
    m.description as modele_description,
    
    -- Informations MARQUE
    mar.id as marque_id,
    mar.nom as marque_nom,
    
    -- Informations CATÉGORIE
    cat.id as categorie_id,
    cat.nom as categorie_nom,
    ssc.id as sous_categorie_id,
    ssc.nom as sous_categorie_nom,
    
    -- Informations GENRE
    g.id as genre_id,
    g.nom as genre_nom,
    
    -- Informations de prix
    pv.prix_min,
    pv.prix_max,
    
    -- Variantes disponibles (JSON)
    pv.variantes_json,
    
    -- Stock total du produit
    (
        SELECT SUM(sp2.quantite)
        FROM variante v2
        JOIN stock_prix sp2 ON v2.id = sp2.idvariante
        WHERE v2.idproduit = p.id
    ) as stock_total,
    
    -- Indicateur si le produit a des variantes
    EXISTS (
        SELECT 1 FROM variante v3 WHERE v3.idproduit = p.id
    ) as a_des_variantes,
    
    -- Pourcentage de remise applicable
    ra.remise_calculée as remise_disponible
    
FROM panier_article pa

-- Jointure OBLIGATOIRE avec produit
INNER JOIN produit p ON pa.id_produit = p.id

-- Jointures pour les informations du produit
LEFT JOIN modele m ON p.idmodele = m.id
LEFT JOIN marque mar ON m.idmarque = mar.id
LEFT JOIN genre g ON p.idgenre = g.id
LEFT JOIN sous_categorie ssc ON p.idsouscategorie = ssc.id
LEFT JOIN categorie cat ON ssc.idcateg = cat.id

-- Informations de prix et variantes
LEFT JOIN produit_variantes pv ON p.id = pv.produit_id

-- Informations de remise
LEFT JOIN remise_applicable ra ON pa.id = ra.article_id

WHERE p.est_actif = true
ORDER BY pa.date_ajout DESC;







CREATE TABLE arrondissement (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    prix DECIMAL(10,2) NOT NULL
);



CREATE TABLE secteur (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    idarrondissement INTEGER NOT NULL,
    CONSTRAINT fk_secteur_arrondissement 
        FOREIGN KEY (idarrondissement) 
        REFERENCES arrondissement(id)
        ON DELETE CASCADE
);



CREATE TABLE livraison (
    id SERIAL PRIMARY KEY,
    idpannier INTEGER NOT NULL,
    idsecteur INTEGER NOT NULL,
    dateheure TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    statut VARCHAR(50) DEFAULT 'en attente',
    CONSTRAINT fk_livraison_secteur 
        FOREIGN KEY (idsecteur) 
        REFERENCES secteur(id)
        ON DELETE RESTRICT
);



CREATE OR REPLACE VIEW vue_livraison AS
SELECT 
    l.id,
    l.idpannier,
    l.dateheure,
    l.statut,
    s.nom AS secteur_nom,
    a.nom AS arrondissement_nom,
    a.prix AS prix_livraison
FROM livraison l
INNER JOIN secteur s ON l.idsecteur = s.id
INNER JOIN arrondissement a ON s.idarrondissement = a.id;












-- Fonction pour appliquer automatiquement les remises lors de l'ajout/modification
CREATE OR REPLACE FUNCTION appliquer_remise_automatique()
RETURNS TRIGGER AS $$
DECLARE
    pourcentage_remise DECIMAL(5,2);
BEGIN
    -- Chercher la remise applicable selon la quantité
    SELECT MAX(pourcentage_remise) INTO pourcentage_remise
    FROM parametre_remise pr
    WHERE NEW.quantite >= pr.quantite_min 
        AND (NEW.quantite <= pr.quantite_max OR pr.quantite_max IS NULL)
        AND pr.est_actif = true;
    
    -- Si une remise est trouvée, l'appliquer
    IF pourcentage_remise IS NOT NULL THEN
        NEW.remise_appliquee = pourcentage_remise;
    ELSE
        NEW.remise_appliquee = 0;
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Créer le trigger pour appliquer automatiquement les remises
DROP TRIGGER IF EXISTS trigger_remise_automatique ON panier_article;
CREATE TRIGGER trigger_remise_automatique
    BEFORE INSERT OR UPDATE ON panier_article
    FOR EACH ROW
    EXECUTE FUNCTION appliquer_remise_automatique();





    -- Fonction pour calculer le total du panier avec remises
CREATE OR REPLACE FUNCTION calculer_total_panier(id_panier INTEGER)
RETURNS TABLE (
    total_brut DECIMAL(10,2),
    total_remise DECIMAL(10,2),
    total_net DECIMAL(10,2),
    nombre_articles INTEGER
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        COALESCE(SUM(sous_total_brut), 0) as total_brut,
        COALESCE(SUM(montant_remise), 0) as total_remise,
        COALESCE(SUM(sous_total_net), 0) as total_net,
        COUNT(*) as nombre_articles
    FROM vue_panier_detail
    WHERE idpanier = id_panier;
END;
$$ LANGUAGE plpgsql;









-- Table des commandes validées
CREATE TABLE commande (
    id SERIAL PRIMARY KEY,
    idutilisateur INTEGER NOT NULL,
    idpanier INTEGER NOT NULL,
    date_commande TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    statut VARCHAR(50) DEFAULT 'validée',
    total_avant_remise DECIMAL(10,2) NOT NULL CHECK (total_avant_remise >= 0),
    total_remise DECIMAL(10,2) DEFAULT 0 CHECK (total_remise >= 0),
    total_final DECIMAL(10,2) NOT NULL CHECK (total_final >= 0),
    adresse_livraison TEXT,
    methode_paiement VARCHAR(50),
    FOREIGN KEY (idutilisateur) REFERENCES utilisateurs(id) ON DELETE CASCADE,
    FOREIGN KEY (idpanier) REFERENCES panier(id) ON DELETE CASCADE
);

-- Table des articles dans la commande
CREATE TABLE commande_article (
    id SERIAL PRIMARY KEY,
    idcommande INTEGER NOT NULL,
    idproduit INTEGER NOT NULL,
    idcouleur INTEGER,
    idpointure INTEGER,
    quantite INTEGER NOT NULL CHECK (quantite > 0),
    prix_unitaire DECIMAL(10,2) NOT NULL CHECK (prix_unitaire >= 0),
    remise_appliquee DECIMAL(5,2) DEFAULT 0 CHECK (remise_appliquee >= 0 AND remise_appliquee <= 100),
    sous_total_brut DECIMAL(10,2) NOT NULL CHECK (sous_total_brut >= 0),
    sous_total_net DECIMAL(10,2) NOT NULL CHECK (sous_total_net >= 0),
    date_ajout TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (idcommande) REFERENCES commande(id) ON DELETE CASCADE,
    FOREIGN KEY (idproduit) REFERENCES produit(id) ON DELETE CASCADE,
    FOREIGN KEY (idcouleur) REFERENCES couleur(id) ON DELETE CASCADE,
    FOREIGN KEY (idpointure) REFERENCES pointure(id) ON DELETE CASCADE
);


-- Supprimer la table si elle existe déjà
DROP TABLE IF EXISTS retour_article CASCADE;

-- Table des retours (sans la contrainte CHECK avec sous-requête)
CREATE TABLE retour_article (
    id SERIAL PRIMARY KEY,
    idcommande_article INTEGER NOT NULL,
    quantite_retournee INTEGER NOT NULL CHECK (quantite_retournee > 0),
    motif TEXT,
    statut VARCHAR(50) DEFAULT 'en_attente',
    date_demande TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    date_traitement TIMESTAMP,
    montant_rembourse DECIMAL(10,2),
    commentaire_admin TEXT,
    FOREIGN KEY (idcommande_article) REFERENCES commande_article(id) ON DELETE CASCADE
);

-- Créer une fonction pour vérifier la contrainte
CREATE OR REPLACE FUNCTION verifier_quantite_retour()
RETURNS TRIGGER AS $$
DECLARE
    quantite_commande INTEGER;
    quantite_deja_retournee INTEGER;
BEGIN
    -- Récupérer la quantité originale de la commande
    SELECT quantite INTO quantite_commande
    FROM commande_article
    WHERE id = NEW.idcommande_article;
    
    -- Récupérer la quantité déjà retournée (approuvée)
    SELECT COALESCE(SUM(quantite_retournee), 0) INTO quantite_deja_retournee
    FROM retour_article
    WHERE idcommande_article = NEW.idcommande_article
    AND statut = 'approuvé'
    AND id != COALESCE(NEW.id, -1); -- Exclure l'enregistrement courant lors d'une mise à jour
    
    -- Vérifier que la nouvelle quantité retournée ne dépasse pas la quantité disponible
    IF NEW.quantite_retournee > (quantite_commande - quantite_deja_retournee) THEN
        RAISE EXCEPTION 'Quantité retournée (%) dépasse la quantité disponible (%)', 
            NEW.quantite_retournee, (quantite_commande - quantite_deja_retournee);
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Créer le trigger pour vérifier la quantité
CREATE TRIGGER trigger_verifier_quantite_retour
    BEFORE INSERT OR UPDATE ON retour_article
    FOR EACH ROW
    EXECUTE FUNCTION verifier_quantite_retour();



    CREATE OR REPLACE VIEW vue_commande_detail AS
SELECT 
    c.id as commande_id,
    c.idutilisateur,
    c.idpanier,
    c.date_commande,
    c.statut as statut_commande,
    c.total_avant_remise,
    c.total_remise,
    c.total_final,
    c.adresse_livraison,
    c.methode_paiement,
    
    ca.id as article_id,
    ca.idproduit,
    ca.idcouleur,
    ca.idpointure,
    ca.quantite,
    ca.prix_unitaire,
    ca.remise_appliquee,
    ca.sous_total_brut,
    ca.sous_total_net,
    
    p.nom as produit_nom,
    p.reference,
    p.images,
    
    m.nom as marque_nom,
    
    cl.nom as couleur_nom,
    cl.code_hex as couleur_code,
    
    pt.pt as pointure_taille,
    
    -- Calcul des quantités retournées
    COALESCE(SUM(r.quantite_retournee), 0) as quantite_retournee_total,
    COALESCE(SUM(CASE WHEN r.statut = 'approuvé' THEN r.quantite_retournee ELSE 0 END), 0) as quantite_retournee_approuvee,
    COALESCE(SUM(CASE WHEN r.statut = 'approuvé' THEN r.montant_rembourse ELSE 0 END), 0) as montant_rembourse_total,
    
    -- Quantité restante après retours
    ca.quantite - COALESCE(SUM(CASE WHEN r.statut = 'approuvé' THEN r.quantite_retournee ELSE 0 END), 0) as quantite_finale
    
FROM commande c
JOIN commande_article ca ON c.id = ca.idcommande
JOIN produit p ON ca.idproduit = p.id
JOIN modele m2 ON p.idmodele = m2.id
JOIN marque m ON m2.idmarque = m.id
LEFT JOIN couleur cl ON ca.idcouleur = cl.id
LEFT JOIN pointure pt ON ca.idpointure = pt.id
LEFT JOIN retour_article r ON ca.id = r.idcommande_article
GROUP BY c.id, ca.id, p.id, m.nom, cl.nom, cl.code_hex, pt.pt, m2.id
ORDER BY c.date_commande DESC, ca.id;



ALTER TABLE retour_article 
ADD COLUMN IF NOT EXISTS id_admin_traitement INTEGER REFERENCES utilisateurs(id);







-- Version ultra-simple et testée
CREATE OR REPLACE FUNCTION appliquer_remise_automatique()
RETURNS TRIGGER AS $$
DECLARE
    remise_val DECIMAL(5,2);
BEGIN
    -- Debug: pour voir ce qui se passe
    -- RAISE NOTICE 'Calcul remise pour quantite: %', NEW.quantite;
    
    -- Valeur par défaut si NULL
    IF NEW.quantite IS NULL THEN
        NEW.remise_appliquee = 0;
        RETURN NEW;
    END IF;
    
    -- Trouver la remise applicable
    SELECT MAX(pourcentage_remise) INTO remise_val
    FROM parametre_remise
    WHERE NEW.quantite >= quantite_min 
      AND (quantite_max IS NULL OR NEW.quantite <= quantite_max)
      AND est_actif = true;
    
    -- Appliquer la remise (ou 0 si pas de remise trouvée)
    NEW.remise_appliquee = COALESCE(remise_val, 0);
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;





-- Recréez le trigger
CREATE TRIGGER trigger_remise_automatique
    BEFORE INSERT OR UPDATE OF quantite ON panier_article
    FOR EACH ROW
    EXECUTE FUNCTION appliquer_remise_automatique();




-- Testez la fonction avec différentes quantités
SELECT appliquer_remise_test(1);  -- Doit retourner 0
SELECT appliquer_remise_test(2);  -- Doit retourner 5.00
SELECT appliquer_remise_test(10); -- Doit retourner 10.00

-- Créez une fonction de test
CREATE OR REPLACE FUNCTION appliquer_remise_test(quantite_test INTEGER)
RETURNS DECIMAL(5,2) AS $$
DECLARE
    result DECIMAL(5,2);
BEGIN
    SELECT MAX(pourcentage_remise) INTO result
    FROM parametre_remise
    WHERE quantite_test >= quantite_min 
      AND (quantite_max IS NULL OR quantite_test <= quantite_max)
      AND est_actif = true;
    
    RETURN COALESCE(result, 0);
END;
$$ LANGUAGE plpgsql;